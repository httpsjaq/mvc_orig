<?php
require_once __DIR__ . '/../ApiBaseController.php';

class UsersApiController extends ApiBaseController {
    public function dispatch(string $action, int $id = 0): void {
        $this->requireAdminApi();
        try {
            if ($action === 'all' && $_SERVER['REQUEST_METHOD'] === 'GET') {
                $this->respond(['data' => $this->userModel->getManageableUsers()]);
            }
            if ($action === 'edit' && $_SERVER['REQUEST_METHOD'] === 'GET') {
                $user = $this->userModel->getManageableUserById($id);
                $user ? $this->respond($user) : $this->respond(['status' => 'error', 'message' => 'User not found.'], 404);
            }
            if (in_array($action, ['add', 'edit'], true) && $_SERVER['REQUEST_METHOD'] === 'POST') {
                $data = $this->requestData();
                if ($action === 'add' || empty($data['id'])) {
                    $email = trim($data['email'] ?? '');
                    $password = $data['password'] ?? '';
                    $confirm = $data['confirm_password'] ?? '';
                    $role = $data['account_type'] ?? '';
                    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 8 || $password !== $confirm || !in_array($role, ['student', 'teacher'], true)) {
                        $this->respond(['status' => 'error', 'message' => 'Provide a valid email, matching 8-character password, and account type.'], 422);
                    }
                    if ($this->userModel->findByEmail($email)) {
                        $this->respond(['status' => 'error', 'message' => 'An account with this email already exists.'], 409);
                    }
                    $otp = random_otp();
                    $created = $this->userModel->createPendingAccount($email, password_hash($password, PASSWORD_DEFAULT), $otp, otp_expiry_time(), $role);
                    if (!$created) $this->respond(['status' => 'error', 'message' => 'Unable to create the account.'], 400);
                    $mail = send_otp_email($email, $otp);
                    $message = !empty($mail['ok'])
                        ? 'Account created. The user must verify their email before signing in.'
                        : 'Account is pending, but the verification email could not be sent.';
                    $this->respond(['status' => 'success', 'message' => $message]);
                }
                $status = $data['status'] ?? '';
                $recordId = $id ?: (int) $data['id'];
                if (!in_array($status, ['verified', 'banned'], true)) {
                    $this->respond(['status' => 'error', 'message' => 'Choose a valid account status.'], 422);
                }
                $this->userModel->adminUpdateUser($recordId, $status)
                    ? $this->respond(['status' => 'success', 'message' => 'User updated successfully.'])
                    : $this->respond(['status' => 'error', 'message' => 'Unable to update user.'], 400);
            }
            if ($action === 'delete' && in_array($_SERVER['REQUEST_METHOD'], ['POST', 'DELETE'], true)) {
                $data = $this->requestData();
                $recordId = $id ?: (int) ($data['id'] ?? 0);
                $this->userModel->adminDeleteUser($recordId)
                    ? $this->respond(['status' => 'success', 'message' => 'User deleted successfully.'])
                    : $this->respond(['status' => 'error', 'message' => 'Unable to delete user.'], 400);
            }
            $this->respond(['status' => 'error', 'message' => 'Unsupported user API action or HTTP method.'], 405);
        } catch (Throwable $exception) {
            $this->respond(['status' => 'error', 'message' => 'User request failed.'], 500);
        }
    }
}
