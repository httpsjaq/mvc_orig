<?php
/** JSON API helpers and admin authorization for template-style API modules. */
require_once __DIR__ . '/../Core/Controller.php';

abstract class ApiBaseController extends Controller {
    protected function requireAdminApi(): array {
        if (empty($_SESSION['email'])) {
            $this->respond(['status' => 'error', 'message' => 'Authentication required.'], 401);
        }
        $user = $this->userModel->findByEmail((string) $_SESSION['email']);
        if (!$user || ($user['status'] ?? '') !== 'verified' || ($user['role'] ?? '') !== 'admin') {
            $this->respond(['status' => 'error', 'message' => 'Administrator access required.'], 403);
        }
        return $user;
    }

    protected function requestData(): array {
        $contentType = $_SERVER['CONTENT_TYPE'] ?? '';
        if (stripos($contentType, 'application/json') !== false) {
            $decoded = json_decode((string) file_get_contents('php://input'), true);
            return is_array($decoded) ? $decoded : [];
        }
        return $_POST;
    }

    protected function respond(array $payload, int $statusCode = 200): void {
        http_response_code($statusCode);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
        exit;
    }
}
