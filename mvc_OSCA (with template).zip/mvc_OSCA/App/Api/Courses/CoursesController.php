<?php
require_once __DIR__ . '/../ApiBaseController.php';
require_once __DIR__ . '/../../Models/courses/CourseCatalog.php';

class CoursesApiController extends ApiBaseController {
    public function dispatch(string $action, int $id = 0): void {
        $this->requireAdminApi();
        $catalog = new CourseCatalog();
        try {
            if ($action === 'all' && $_SERVER['REQUEST_METHOD'] === 'GET') {
                $this->respond(['data' => $catalog->all()]);
            }
            if ($action === 'edit' && $_SERVER['REQUEST_METHOD'] === 'GET') {
                foreach ($catalog->all() as $course) {
                    if ((int) $course['id'] === $id) $this->respond($course);
                }
                $this->respond(['status' => 'error', 'message' => 'Course not found.'], 404);
            }
            if (in_array($action, ['add', 'edit'], true) && $_SERVER['REQUEST_METHOD'] === 'POST') {
                $data = $this->requestData();
                $title = trim($data['title'] ?? '');
                if ($title === '' || (function_exists('mb_strlen') ? mb_strlen($title) : strlen($title)) > 55) {
                    $this->respond(['status' => 'error', 'message' => 'Title must contain 1 to 55 characters.'], 422);
                }
                $recordId = $id ?: (int) ($data['id'] ?? 0);
                $catalog->save($title, $recordId);
                $this->respond(['status' => 'success', 'message' => $recordId ? 'Course updated successfully.' : 'Course added successfully.']);
            }
            if ($action === 'delete' && in_array($_SERVER['REQUEST_METHOD'], ['POST', 'DELETE'], true)) {
                $data = $this->requestData();
                $recordId = $id ?: (int) ($data['id'] ?? 0);
                $catalog->delete($recordId)
                    ? $this->respond(['status' => 'success', 'message' => 'Course deleted successfully.'])
                    : $this->respond(['status' => 'error', 'message' => 'Unable to delete course.'], 400);
            }
            $this->respond(['status' => 'error', 'message' => 'Unsupported course API action or HTTP method.'], 405);
        } catch (Throwable $exception) {
            $this->respond(['status' => 'error', 'message' => 'Course request failed.'], 500);
        }
    }
}
