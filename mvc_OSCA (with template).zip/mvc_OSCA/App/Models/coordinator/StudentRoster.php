<?php
/** Shared student roster used by Coordinators and the Admin dashboard. */
require_once __DIR__ . '/../../Config/init.php';

class StudentRoster {
    private mysqli $db;

    public function __construct() {
        $this->db = db_connection();
        $this->db->query("CREATE TABLE IF NOT EXISTS coordinator_students (
            id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
            student_id VARCHAR(50) NOT NULL UNIQUE,
            full_name VARCHAR(180) NOT NULL,
            course VARCHAR(120) NOT NULL DEFAULT '',
            year_level VARCHAR(30) NOT NULL DEFAULT '',
            enrollment_year VARCHAR(10) NOT NULL DEFAULT '',
            jersey_number VARCHAR(20) NOT NULL DEFAULT '',
            sport_id INT DEFAULT NULL,
            dance_member TINYINT(1) NOT NULL DEFAULT 0,
            active TINYINT(1) NOT NULL DEFAULT 1,
            created_by INT DEFAULT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            CONSTRAINT fk_coordinator_students_creator FOREIGN KEY (created_by)
                REFERENCES users(id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $this->ensureColumn('jersey_number', "VARCHAR(20) NOT NULL DEFAULT ''");
        $this->ensureColumn('sport_id', 'INT DEFAULT NULL');
        $this->ensureColumn('dance_member', 'TINYINT(1) NOT NULL DEFAULT 0');
        $this->ensureColumn('active', 'TINYINT(1) NOT NULL DEFAULT 1');
        $this->db->query("CREATE TABLE IF NOT EXISTS coordinator_sports (
            id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL UNIQUE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $this->db->query("CREATE TABLE IF NOT EXISTS coordinator_schedules (
            id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
            group_type ENUM('Sport','Dance Troupe') NOT NULL,
            group_name VARCHAR(100) NOT NULL,
            practice_date DATE NOT NULL,
            practice_time TIME NOT NULL,
            location VARCHAR(150) NOT NULL,
            status ENUM('upcoming','cancelled') NOT NULL DEFAULT 'upcoming',
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }

    private function ensureColumn(string $column, string $definition): void {
        $columnName = $this->db->real_escape_string($column);
        $result = $this->db->query("SHOW COLUMNS FROM coordinator_students LIKE '{$columnName}'");
        if ($result && $result->num_rows === 0) {
            $this->db->query("ALTER TABLE coordinator_students ADD COLUMN {$column} {$definition}");
        }
    }

    public function all(): array {
        $result = $this->db->query("SELECT s.id, s.student_id, s.full_name, s.course, s.year_level,
                s.enrollment_year, s.jersey_number, s.dance_member, s.created_at, sp.name AS sport_name
            FROM coordinator_students s
            LEFT JOIN coordinator_sports sp ON sp.id = s.sport_id
            WHERE s.active = 1 ORDER BY s.full_name");
        return $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
    }

    public function stats(): array {
        $queries = [
            'athletes' => 'SELECT COUNT(*) n FROM coordinator_students WHERE active=1 AND sport_id IS NOT NULL',
            'dance' => 'SELECT COUNT(*) n FROM coordinator_students WHERE active=1 AND dance_member=1',
            'sports' => 'SELECT COUNT(*) n FROM coordinator_sports',
            'practices' => "SELECT COUNT(*) n FROM coordinator_schedules WHERE status='upcoming' AND practice_date>=CURDATE()"
        ];
        $stats = [];
        foreach ($queries as $key => $sql) {
            $result = $this->db->query($sql);
            $stats[$key] = $result ? (int) ($result->fetch_assoc()['n'] ?? 0) : 0;
        }
        return $stats;
    }

    public function sports(): array {
        $result = $this->db->query('SELECT id, name FROM coordinator_sports ORDER BY name');
        return $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
    }

    public function students(string $category = '', string $search = '', string $sport = '', string $year = ''): array {
        $sql = "SELECT s.*, sp.name AS sport_name FROM coordinator_students s
            LEFT JOIN coordinator_sports sp ON sp.id=s.sport_id WHERE s.active=1";
        $types = '';
        $values = [];
        if ($category === 'athletes') $sql .= ' AND s.sport_id IS NOT NULL';
        if ($category === 'dance') $sql .= ' AND s.dance_member=1';
        if ($search !== '') {
            $sql .= ' AND (s.full_name LIKE ? OR s.student_id LIKE ? OR s.jersey_number LIKE ?)';
            $like = "%{$search}%";
            $types .= 'sss';
            array_push($values, $like, $like, $like);
        }
        if ($sport !== '' && ctype_digit($sport)) {
            $sql .= ' AND s.sport_id=?';
            $types .= 'i';
            $values[] = (int) $sport;
        }
        if ($year !== '') {
            $sql .= ' AND s.enrollment_year=?';
            $types .= 's';
            $values[] = $year;
        }
        $sql .= ' ORDER BY s.full_name';
        $stmt = $this->db->prepare($sql);
        if ($types !== '') $stmt->bind_param($types, ...$values);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    public function student(int $id): ?array {
        $stmt = $this->db->prepare('SELECT s.*, sp.name AS sport_name FROM coordinator_students s LEFT JOIN coordinator_sports sp ON sp.id=s.sport_id WHERE s.id=?');
        $stmt->bind_param('i', $id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc() ?: null;
    }

    public function schedules(): array {
        $result = $this->db->query("SELECT * FROM coordinator_schedules WHERE status='upcoming' AND practice_date>=CURDATE() ORDER BY practice_date, practice_time");
        return $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
    }

    public function add(array $data, int $createdBy): bool {
        $sportId = !empty($data['sport_id']) ? (int) $data['sport_id'] : null;
        $dance = !empty($data['dance_member']) ? 1 : 0;
        $stmt = $this->db->prepare("INSERT INTO coordinator_students
            (student_id, full_name, course, year_level, enrollment_year, jersey_number, sport_id, dance_member, created_by)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param(
            'ssssssiii',
            $data['student_id'],
            $data['full_name'],
            $data['course'],
            $data['year_level'],
            $data['enrollment_year'],
            $data['jersey_number'],
            $sportId,
            $dance,
            $createdBy
        );
        return $stmt->execute();
    }

    public function update(int $id, array $data): bool {
        $sportId = !empty($data['sport_id']) ? (int) $data['sport_id'] : null;
        $dance = !empty($data['dance_member']) ? 1 : 0;
        $stmt = $this->db->prepare("UPDATE coordinator_students SET
            student_id=?, full_name=?, course=?, year_level=?, enrollment_year=?,
            jersey_number=?, sport_id=?, dance_member=? WHERE id=? AND active=1");
        $stmt->bind_param('ssssssiii', $data['student_id'], $data['full_name'], $data['course'],
            $data['year_level'], $data['enrollment_year'], $data['jersey_number'], $sportId, $dance, $id);
        return $stmt->execute();
    }

    public function deactivate(int $id): bool {
        $stmt = $this->db->prepare('UPDATE coordinator_students SET active=0 WHERE id=? AND active=1');
        $stmt->bind_param('i', $id);
        return $stmt->execute() && $stmt->affected_rows === 1;
    }
    public function addSport(string $name): bool {
        $stmt = $this->db->prepare('INSERT INTO coordinator_sports (name) VALUES (?)');
        $stmt->bind_param('s', $name);
        return $stmt->execute();
    }

    public function addSchedule(array $data): bool {
        $stmt = $this->db->prepare('INSERT INTO coordinator_schedules (group_type, group_name, practice_date, practice_time, location) VALUES (?, ?, ?, ?, ?)');
        $stmt->bind_param('sssss', $data['group_type'], $data['group_name'], $data['practice_date'], $data['practice_time'], $data['location']);
        return $stmt->execute();
    }

    public function cancelSchedule(int $id): bool {
        $stmt = $this->db->prepare("UPDATE coordinator_schedules SET status='cancelled' WHERE id=?");
        $stmt->bind_param('i', $id);
        return $stmt->execute();
    }
}



