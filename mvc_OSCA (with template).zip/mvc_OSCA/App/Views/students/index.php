<?php $students = $students ?? []; $courses = $courses ?? []; $sports = $sports ?? []; ?>
<div class="card card-primary card-outline">
  <div class="card-header">
    <h3 class="card-title">Student Management</h3>
    <div class="card-tools"><button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#student-modal" data-student-id="0" data-student-record="{}"><i class="fas fa-plus"></i> New Student</button></div>
  </div>
  <div class="card-body">
    <?php if (!empty($studentError)): ?><div class="alert alert-danger" role="alert"><?php echo e($studentError); ?></div><?php endif; ?>
    <?php if (!empty($studentSuccess)): ?><div class="alert alert-success" role="status"><?php echo e($studentSuccess); ?></div><?php endif; ?>
    <div class="table-responsive">
      <table id="students-table" class="table table-bordered table-striped table-hover w-100">
        <thead><tr><th>Student ID</th><th>Name</th><th>Course</th><th>Year</th><th class="text-center">Option</th></tr></thead>
        <tbody>
          <?php if (!$students): ?><tr><td colspan="5" class="text-center text-muted">No student records yet.</td></tr><?php endif; ?>
          <?php foreach ($students as $student): ?>
            <?php $record = ['id' => (int) $student['id'], 'student_id' => $student['student_id'], 'full_name' => $student['full_name'], 'course' => $student['course'], 'year_level' => $student['year_level'], 'enrollment_year' => $student['enrollment_year'], 'jersey_number' => $student['jersey_number'], 'sport_id' => $student['sport_id'], 'dance_member' => (int) $student['dance_member']]; ?>
            <tr>
              <td><?php echo e($student['student_id']); ?></td><td><?php echo e($student['full_name']); ?></td><td><?php echo e($student['course'] ?: '—'); ?></td><td><?php echo e($student['year_level'] ?: '—'); ?></td>
              <td class="text-center text-nowrap">
                <button type="button" class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#student-modal" data-student-id="<?php echo (int) $student['id']; ?>" data-student-record="<?php echo e((string) json_encode($record, JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_TAG | JSON_HEX_AMP)); ?>"><i class="fas fa-edit"></i> Edit</button>
                <form method="post" class="d-inline" onsubmit="return confirm('Remove this student from the active roster?');"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?php echo (int) $student['id']; ?>"><button class="btn btn-sm btn-outline-danger" type="submit"><i class="fas fa-trash"></i> Delete</button></form>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<div class="modal fade" id="student-modal" tabindex="-1" aria-labelledby="student-modal-title" aria-hidden="true">
  <div class="modal-dialog modal-lg"><form method="post" class="modal-content">
    <div class="modal-header"><h5 class="modal-title" id="student-modal-title">Add Student</h5><button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>
    <div class="modal-body">
      <div class="form-row"><div class="form-group col-md-6"><label for="student-id-number">Student ID</label><input class="form-control" id="student-id-number" name="student_id" maxlength="50" required></div><div class="form-group col-md-6"><label for="student-full-name">Full name</label><input class="form-control" id="student-full-name" name="full_name" maxlength="180" required></div></div>
      <div class="form-row"><div class="form-group col-md-6"><label for="student-course">Course</label><select class="form-control" id="student-course" name="course"><option value="">Select a course</option><?php foreach ($courses as $course): ?><option value="<?php echo e($course['title']); ?>"><?php echo e($course['title']); ?></option><?php endforeach; ?></select></div><div class="form-group col-md-6"><label for="student-year">Year level</label><input class="form-control" id="student-year" name="year_level" maxlength="30"></div></div>
      <div class="form-row"><div class="form-group col-md-4"><label for="student-enrollment-year">Enrollment year</label><input class="form-control" id="student-enrollment-year" name="enrollment_year" maxlength="10"></div><div class="form-group col-md-4"><label for="student-jersey">Jersey number</label><input class="form-control" id="student-jersey" name="jersey_number" maxlength="20"></div><div class="form-group col-md-4"><label for="student-sport">Sport</label><select class="form-control" id="student-sport" name="sport_id"><option value="">No sport</option><?php foreach ($sports as $sport): ?><option value="<?php echo (int) $sport['id']; ?>"><?php echo e($sport['name']); ?></option><?php endforeach; ?></select></div></div>
      <div class="form-check"><input class="form-check-input" type="checkbox" name="dance_member" id="student-dance" value="1"><label class="form-check-label" for="student-dance">Dance troupe member</label></div>
    </div>
    <div class="modal-footer"><input type="hidden" name="action" value="save"><input type="hidden" name="id" id="student-record-id" value="0"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-primary">Save Student</button></div>
  </form></div>
</div>
<script>
document.getElementById('student-modal').addEventListener('show.bs.modal', function (event) {
  const record = JSON.parse(event.relatedTarget.getAttribute('data-student-record') || '{}');
  document.getElementById('student-record-id').value = record.id || 0;
  document.getElementById('student-modal-title').textContent = record.id ? 'Edit Student' : 'Add Student';
  document.getElementById('student-id-number').value = record.student_id || '';
  document.getElementById('student-full-name').value = record.full_name || '';
  document.getElementById('student-course').value = record.course || '';
  document.getElementById('student-year').value = record.year_level || '';
  document.getElementById('student-enrollment-year').value = record.enrollment_year || '';
  document.getElementById('student-jersey').value = record.jersey_number || '';
  document.getElementById('student-sport').value = record.sport_id || '';
  document.getElementById('student-dance').checked = record.dance_member === 1;
});
</script>
