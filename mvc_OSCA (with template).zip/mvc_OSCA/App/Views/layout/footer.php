  </div></section>
  <footer class="main-footer"><strong><?php echo e(APP_NAME); ?></strong><div class="float-right d-none d-sm-inline-block">Student and activity management</div></footer>
</div>
</div>
<script src="plugins/jquery/jquery.min.js"></script>
<script src="bootstrap-5.0.2/bootstrap-5.0.2-dist/js/bootstrap.bundle.min.js"></script>
<script src="dist/js/adminlte.min.js"></script>
<script src="js/script.js"></script>
</body>
</html>
