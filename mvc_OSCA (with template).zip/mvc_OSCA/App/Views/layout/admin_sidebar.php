<?php
/** Admin-only navigation shell, matching the shared AdminLTE layout. */
$currentUser = isset($currentUser) && is_array($currentUser) ? $currentUser : [];
include __DIR__ . '/sidebar.php';
