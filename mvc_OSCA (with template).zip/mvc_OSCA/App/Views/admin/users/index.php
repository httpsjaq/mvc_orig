<?php $users = $users ?? []; ?>
<div class="card card-primary card-outline">
  <div class="card-header"><h3 class="card-title">User Management</h3><div class="card-tools"><a href="index.php?url=admin_new_user" class="btn btn-primary btn-sm"><i class="fas fa-user-plus"></i> New User</a></div></div>
  <div class="card-body">
    <?php if (!empty($adminError)): ?><div class="alert alert-danger" role="alert"><?php echo e($adminError); ?></div><?php endif; ?>
    <?php if (!empty($adminSuccess)): ?><div class="alert alert-success" role="status"><?php echo e($adminSuccess); ?></div><?php endif; ?>
    <div class="table-responsive"><table id="users-table" class="table table-bordered table-striped table-hover w-100">
      <thead><tr><th>Name</th><th>Email</th><th>Username</th><th>Student ID</th><th>Role</th><th>Status</th><th class="text-center">Option</th></tr></thead>
      <tbody>
        <?php if (!$users): ?><tr><td colspan="7" class="text-center text-muted">No user accounts found.</td></tr><?php endif; ?>
        <?php foreach ($users as $user): ?>
          <tr><td><?php echo e($user['full_name'] ?: 'N/A'); ?></td><td><?php echo e($user['email']); ?></td><td><?php echo e($user['username'] ?: 'N/A'); ?></td><td><?php echo e($user['student_id'] ?: 'N/A'); ?></td><td><?php echo e(ucfirst($user['role'])); ?></td><td><?php echo e($user['status'] === 'verified' ? 'Active' : ucfirst($user['status'])); ?></td>
            <td class="text-center text-nowrap"><a class="btn btn-sm btn-outline-primary" href="index.php?url=admin_edit_user&amp;id=<?php echo (int) $user['id']; ?>"><i class="fas fa-edit"></i> Edit</a>
              <form method="post" class="d-inline" onsubmit="return confirm('Delete this account?');"><input type="hidden" name="user_id" value="<?php echo (int) $user['id']; ?>"><button type="submit" name="delete_user" class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i> Delete</button></form></td></tr>
        <?php endforeach; ?>
      </tbody>
    </table></div>
  </div>
</div>

