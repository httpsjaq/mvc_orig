<div class="card card-primary card-outline">
  <div class="card-header"><h3 class="card-title">Create User Account</h3></div>
  <form method="post">
    <div class="card-body">
      <?php if (!empty($adminError)): ?><div class="alert alert-danger" role="alert"><?php echo e($adminError); ?></div><?php endif; ?>
      <?php if (!empty($adminSuccess)): ?><div class="alert alert-success" role="status"><?php echo e($adminSuccess); ?></div><?php endif; ?>
      <p class="text-muted">New accounts remain pending until their owner verifies the email address. Coordinator accounts still need admin approval after profile setup.</p>
      <div class="form-group"><label for="new-user-email">Email</label><input class="form-control" type="email" id="new-user-email" name="email" required maxlength="150"></div>
      <div class="form-row"><div class="form-group col-md-6"><label for="new-user-password">Temporary password</label><input class="form-control" type="password" id="new-user-password" name="password" required minlength="8" autocomplete="new-password"></div><div class="form-group col-md-6"><label for="new-user-confirm">Confirm password</label><input class="form-control" type="password" id="new-user-confirm" name="confirm_password" required minlength="8" autocomplete="new-password"></div></div>
      <div class="form-group"><label for="new-user-role">Account type</label><select class="form-control" id="new-user-role" name="account_type" required><option value="student">Student</option><option value="teacher">Coordinator</option></select></div>
    </div>
    <div class="card-footer"><button class="btn btn-primary" type="submit" name="create_user" value="1"><i class="fas fa-user-plus"></i> Create Account</button> <a class="btn btn-default" href="index.php?url=admin_users">Cancel</a></div>
  </form>
</div>
