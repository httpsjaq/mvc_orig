<?php
/**
 * Admin controller.
 * Handles the Student Management System admin dashboard:
 * - view students
 * - edit a student's status on a separate page
 * - delete students
 */
require_once __DIR__ . '/../../Core/Controller.php';
require_once __DIR__ . '/../../Models/coordinator/StudentRoster.php';

class AdminController extends Controller {
    /**
     * Render the admin dashboard and delete users.
     */
    public function dashboard(): void {
        $currentUser = $this->requireUser(false);

        if (($currentUser['role'] ?? '') !== 'admin') {
            redirect('index.php?url=home');
        }

        $adminError = flash_get('admin_error') ?? '';
        $adminSuccess = flash_get('admin_success') ?? '';

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (isset($_POST['review_coordinator'])) {
                $userId = (int) ($_POST['user_id'] ?? 0);
                $decision = $_POST['review_coordinator'];

                if ($this->userModel->reviewCoordinatorRequest($userId, $decision)) {
                    $adminSuccess = $decision === 'approve'
                        ? 'Coordinator account approved.'
                        : 'Coordinator account declined.';
                } else {
                    $adminError = 'This Coordinator request could not be updated. Refresh and try again.';
                }

                flash_set('admin_error', $adminError);
                flash_set('admin_success', $adminSuccess);
                redirect('index.php?url=admin_dashboard');
            } elseif (isset($_POST['delete_user'])) {
                $userId = (int) ($_POST['user_id'] ?? 0);

                if ($this->userModel->adminDeleteUser($userId)) {
                    $adminSuccess = 'User deleted successfully.';
                } else {
                    $adminError = 'Failed to delete user.';
                }
            }
        }

        $stats = $this->userModel->adminStats();
        $users = $this->userModel->getManageableUsers();
        $coordinators = $this->userModel->getManageableCoordinators();
        $rosterStudents = (new StudentRoster())->all();

        extract([
            'pageTitle' => 'Admin Dashboard',
            'currentUser' => $currentUser,
            'adminError' => $adminError,
            'adminSuccess' => $adminSuccess,
            'stats' => $stats,
            'users' => $users,
            'coordinators' => $coordinators,
            'rosterStudents' => $rosterStudents
        ]);

        include __DIR__ . '/../../Views/layout/header.php';
        include __DIR__ . '/../../Views/layout/sidebar.php';
        include __DIR__ . '/../../Views/admin/dashboard/index.php';
        include __DIR__ . '/../../Views/layout/footer.php';
    }

    /**
     * Edit a single student's status on a dedicated page.
     */
    /** Render the template-style user management table. */
    public function users(): void {
        $currentUser = $this->requireUser(false);
        if (($currentUser['role'] ?? '') !== 'admin') {
            redirect('index.php?url=home');
        }

        $adminError = '';
        $adminSuccess = '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_user'])) {
            $adminSuccess = $this->userModel->adminDeleteUser((int) ($_POST['user_id'] ?? 0))
                ? 'User deleted successfully.' : 'Failed to delete user.';
        }

        $this->renderApp('admin/users/index', [
            'pageTitle' => 'Users',
            'currentUser' => $currentUser,
            'users' => $this->userModel->getManageableUsers(),
            'adminError' => $adminError,
            'adminSuccess' => $adminSuccess
        ]);
    }
    /** Create a user through the same email-verification flow as public signup. */
    public function createUser(): void {
        $currentUser = $this->requireUser(false);
        if (($currentUser['role'] ?? '') !== 'admin') {
            redirect('index.php?url=home');
        }

        $adminError = '';
        $adminSuccess = '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_user'])) {
            $email = trim($_POST['email'] ?? '');
            $password = $_POST['password'] ?? '';
            $confirm = $_POST['confirm_password'] ?? '';
            $role = $_POST['account_type'] ?? '';
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $adminError = 'Enter a valid email address.';
            } elseif (strlen($password) < 8) {
                $adminError = 'Temporary password must contain at least 8 characters.';
            } elseif ($password !== $confirm) {
                $adminError = 'Passwords do not match.';
            } elseif (!in_array($role, ['student', 'teacher'], true)) {
                $adminError = 'Choose Student or Coordinator.';
            } elseif ($this->userModel->findByEmail($email)) {
                $adminError = 'An account with this email already exists.';
            } else {
                try {
                    $otp = random_otp();
                    $expires = otp_expiry_time();
                    $hash = password_hash($password, PASSWORD_DEFAULT);
                    if (!$this->userModel->createPendingAccount($email, $hash, $otp, $expires, $role)) {
                        $adminError = 'Account could not be created.';
                    } else {
                        $mailResult = send_otp_email($email, $otp);
                        $adminSuccess = !empty($mailResult['ok'])
                            ? 'Account created. The user must verify their email before signing in.'
                            : 'Account is pending, but the verification email could not be sent. Check the mail configuration before the user signs in.';
                    }
                } catch (Throwable $exception) {
                    $adminError = 'Account could not be created. Check that the email is not already in use.';
                }
            }
        }

        $this->renderApp('admin/users/create', [
            'pageTitle' => 'New User',
            'currentUser' => $currentUser,
            'adminError' => $adminError,
            'adminSuccess' => $adminSuccess
        ]);
    }
    public function editUser(): void {
        $currentUser = $this->requireUser(false);

        if (($currentUser['role'] ?? '') !== 'admin') {
            redirect('index.php?url=home');
        }

        $userId = (int) ($_GET['id'] ?? 0);
        $editableUser = $this->userModel->getManageableUserById($userId);

        if (!$editableUser) {
            flash_set('admin_error', 'User not found.');
            redirect('index.php?url=admin_dashboard');
        }

        $adminError = '';
        $adminSuccess = '';

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_user'])) {
            $status = trim($_POST['status'] ?? '');

            $allowedStatus = ['verified', 'banned'];

            if (!in_array($status, $allowedStatus, true)) {
                $adminError = 'Invalid status selected.';
            } elseif ($this->userModel->adminUpdateUser($userId, $status)) {
                flash_set('admin_success', 'User updated successfully.');
                redirect('index.php?url=admin_dashboard');
            } else {
                $adminError = 'Failed to update user.';
            }
        }

        extract([
            'pageTitle' => 'Edit User',
            'currentUser' => $currentUser,
            'editableUser' => $editableUser,
            'adminError' => $adminError,
            'adminSuccess' => $adminSuccess
        ]);

        include __DIR__ . '/../../Views/layout/header.php';
        include __DIR__ . '/../../Views/layout/sidebar.php';
        include __DIR__ . '/../../Views/admin/users/edit_user.php';
        include __DIR__ . '/../../Views/layout/footer.php';
    }
}



