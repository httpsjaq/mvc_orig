<?php
require_once __DIR__ . '/../../Core/Controller.php';
require_once __DIR__ . '/../../Models/coordinator/StudentRoster.php';
require_once __DIR__ . '/../../Models/courses/CourseCatalog.php';

class CoordinatorController extends Controller {
    public function show(string $page = 'home'): void {
        $user = $this->requireUser();
        if (
            ($user['role'] ?? '') !== 'teacher' ||
            !in_array(($user['teacher_approval_status'] ?? ''), ['', 'approved'], true)
        ) {
            redirect('login.php');
        }

        $validPages = ['home', 'athletes', 'dance', 'sports', 'schedule', 'reports'];
        if (!in_array($page, $validPages, true)) $page = 'home';

        $model = new StudentRoster();
        $notice = '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            try {
                if (isset($_POST['add_student'])) {
                    $student = [
                        'student_id' => trim($_POST['student_id'] ?? ''),
                        'full_name' => trim($_POST['full_name'] ?? ''),
                        'course' => trim($_POST['course'] ?? ''),
                        'year_level' => trim($_POST['year_level'] ?? ''),
                        'enrollment_year' => trim($_POST['enrollment_year'] ?? ''),
                        'jersey_number' => trim($_POST['jersey_number'] ?? ''),
                        'sport_id' => $_POST['sport_id'] ?? '',
                        'dance_member' => ($page === 'dance' || !empty($_POST['dance_member'])) ? '1' : ''
                    ];
                    $ok = $student['student_id'] !== '' && $student['full_name'] !== ''
                        && $model->add($student, (int) $user['id']);
                } elseif (isset($_POST['add_sport'])) {
                    $ok = $model->addSport(trim($_POST['sport_name'] ?? ''));
                } elseif (isset($_POST['add_schedule'])) {
                    $schedule = [
                        'group_type' => $_POST['group_type'] ?? '',
                        'group_name' => trim($_POST['group_name'] ?? ''),
                        'practice_date' => $_POST['practice_date'] ?? '',
                        'practice_time' => $_POST['practice_time'] ?? '',
                        'location' => trim($_POST['location'] ?? '')
                    ];
                    $ok = in_array($schedule['group_type'], ['Sport', 'Dance Troupe'], true)
                        && $schedule['group_name'] !== '' && $schedule['location'] !== ''
                        && $schedule['practice_date'] !== '' && $schedule['practice_time'] !== ''
                        && $model->addSchedule($schedule);
                } elseif (isset($_POST['cancel_schedule'])) {
                    $ok = $model->cancelSchedule((int) ($_POST['schedule_id'] ?? 0));
                } else {
                    $ok = false;
                }
                $notice = $ok ? 'Saved successfully.' : 'Could not save this record. Check required fields and try again.';
            } catch (Throwable $error) {
                $notice = 'Could not save this record. Check for duplicate IDs or names.';
            }
        }

        $category = in_array($page, ['athletes', 'dance'], true) ? $page : '';
        $selectedStudent = isset($_GET['student']) ? $model->student((int) $_GET['student']) : null;
        $this->renderApp('coordinator/page', [
            'pageTitle' => ucfirst(str_replace('_', ' ', $page)),
            'currentUser' => $user,
            'section' => $page,
            'stats' => $model->stats(),
            'sports' => $model->sports(),
            'courses' => (new CourseCatalog())->all(),
            'students' => $model->students($category, trim($_GET['q'] ?? ''), trim($_GET['sport'] ?? ''), trim($_GET['year'] ?? '')),
            'schedules' => $model->schedules(),
            'selectedStudent' => $selectedStudent,
            'notice' => $notice
        ]);
    }
}



