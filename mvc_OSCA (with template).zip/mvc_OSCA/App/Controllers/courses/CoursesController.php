<?php
/** Admin course catalog controller, following the template's Courses module. */
require_once __DIR__ . '/../../Core/Controller.php';
require_once __DIR__ . '/../../Models/courses/CourseCatalog.php';

class CoursesController extends Controller {
    public function index(): void {
        $currentUser = $this->requireUser(false);
        if (($currentUser['role'] ?? '') !== 'admin') {
            redirect('index.php?url=home');
        }

        $catalog = new CourseCatalog();
        $error = '';
        $success = '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $action = $_POST['action'] ?? '';
            if ($action === 'delete') {
                $success = $catalog->delete((int) ($_POST['id'] ?? 0))
                    ? 'Course deleted.' : 'Course could not be deleted.';
            } elseif ($action === 'save') {
                $title = trim($_POST['title'] ?? '');
                $id = (int) ($_POST['id'] ?? 0);
                if ($title === '' || mb_strlen($title) > 55) {
                    $error = 'Enter a course title with 1 to 55 characters.';
                } else {
                    try {
                        if ($catalog->save($title, $id)) {
                            $success = $id > 0 ? 'Course updated.' : 'Course added.';
                        } else {
                            $error = 'Course could not be saved.';
                        }
                    } catch (Throwable $exception) {
                        $error = 'That course title already exists, or could not be saved.';
                    }
                }
            }
        }

        $this->renderApp('courses/index', [
            'pageTitle' => 'Courses',
            'currentUser' => $currentUser,
            'courses' => $catalog->all(),
            'courseError' => $error,
            'courseSuccess' => $success
        ]);
    }
}
