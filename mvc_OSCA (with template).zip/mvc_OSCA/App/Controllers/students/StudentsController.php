<?php
/** Admin roster management, adapted from the template's Students module. */
require_once __DIR__ . '/../../Core/Controller.php';
require_once __DIR__ . '/../../Models/coordinator/StudentRoster.php';
require_once __DIR__ . '/../../Models/courses/CourseCatalog.php';

class StudentsController extends Controller {
    public function index(): void {
        $currentUser = $this->requireUser(false);
        if (($currentUser['role'] ?? '') !== 'admin') {
            redirect('index.php?url=home');
        }

        $roster = new StudentRoster();
        $catalog = new CourseCatalog();
        $error = '';
        $success = '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $action = $_POST['action'] ?? '';
            $id = (int) ($_POST['id'] ?? 0);
            if ($action === 'delete') {
                $success = $roster->deactivate($id) ? 'Student removed from the active roster.' : 'Student could not be removed.';
            } elseif ($action === 'save') {
                $student = [
                    'student_id' => trim($_POST['student_id'] ?? ''),
                    'full_name' => trim($_POST['full_name'] ?? ''),
                    'course' => trim($_POST['course'] ?? ''),
                    'year_level' => trim($_POST['year_level'] ?? ''),
                    'enrollment_year' => trim($_POST['enrollment_year'] ?? ''),
                    'jersey_number' => trim($_POST['jersey_number'] ?? ''),
                    'sport_id' => $_POST['sport_id'] ?? '',
                    'dance_member' => !empty($_POST['dance_member']) ? '1' : ''
                ];
                if ($student['student_id'] === '' || $student['full_name'] === '') {
                    $error = 'Student ID and full name are required.';
                } else {
                    try {
                        $saved = $id > 0
                            ? $roster->update($id, $student)
                            : $roster->add($student, (int) $currentUser['id']);
                        $success = $saved ? ($id > 0 ? 'Student updated.' : 'Student added.') : 'Student could not be saved.';
                    } catch (Throwable $exception) {
                        $error = 'Student could not be saved. Check for a duplicate student ID.';
                    }
                }
            }
        }

        $this->renderApp('students/index', [
            'pageTitle' => 'Students',
            'currentUser' => $currentUser,
            'students' => $roster->all(),
            'sports' => $roster->sports(),
            'courses' => $catalog->all(),
            'studentError' => $error,
            'studentSuccess' => $success
        ]);
    }
}
