<?php
/** API front controller: /api.php?resource=students&action=all */
session_start();
require_once __DIR__ . '/../App/Api/Students/StudentsController.php';
require_once __DIR__ . '/../App/Api/Courses/CoursesController.php';
require_once __DIR__ . '/../App/Api/Users/UsersController.php';

$resource = strtolower(trim($_GET['resource'] ?? ''));
$action = strtolower(trim($_GET['action'] ?? 'all'));
$id = max(0, (int) ($_GET['id'] ?? 0));

try {
    switch ($resource) {
        case 'students':
            (new StudentsApiController())->dispatch($action, $id);
            break;
        case 'courses':
            (new CoursesApiController())->dispatch($action, $id);
            break;
        case 'users':
            (new UsersApiController())->dispatch($action, $id);
            break;
        default:
            http_response_code(404);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['status' => 'error', 'message' => 'Unknown API resource.']);
    }
} catch (Throwable $exception) {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'error', 'message' => 'The request could not be completed.']);
}
