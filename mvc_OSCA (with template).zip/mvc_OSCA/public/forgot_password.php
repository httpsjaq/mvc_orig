<?php
/**
 * Public entry point for forgot-password requests.
 */
session_start();
require_once "../App/Controllers/password/PasswordController.php";
(new PasswordController())->forgotPassword();
