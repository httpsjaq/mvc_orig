<?php
/**
 * Public entry point for login.
 * Delegates work to AuthController to keep this file minimal.
 */
session_start();
require_once "../App/Controllers/auth/AuthController.php";
(new AuthController())->login();
