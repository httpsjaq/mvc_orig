<?php
/**
 * Main front controller, following the supplied MVC template.
 * Bootstrap and routing are centralized; feature logic stays in its controllers.
 */
require_once __DIR__ . '/../app/config/init.php';
require_once __DIR__ . '/../app/autoload.php';

try {
    $router = new \Core\Router();
    $router->dispatch();
} catch (Throwable $exception) {
    error_log('[OSCA MVC] ' . $exception);
    http_response_code(500);
    header('Content-Type: text/html; charset=utf-8');
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8">';
    echo '<meta name="viewport" content="width=device-width, initial-scale=1">';
    echo '<title>Application Error</title></head><body style="font-family:system-ui,sans-serif;padding:2rem">';
    echo '<h1>Something went wrong</h1><p>The request could not be completed. Check the application log and configuration.</p>';
    echo '</body></html>';
}
