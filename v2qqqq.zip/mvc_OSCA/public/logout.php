<?php
/** Compatibility endpoint; all application requests are dispatched by the MVC router. */
$_GET['url'] = 'logout';
require __DIR__ . '/index.php';
