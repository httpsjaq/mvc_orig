<?php
/** REST API entry point for the Flutter OSCA app. */
header('Access-Control-Allow-Origin: *'); // Restrict to trusted app origins in production.
header('Access-Control-Allow-Methods: GET, POST, PATCH, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json; charset=utf-8');

// Handle CORS preflight without creating a database connection.
if (strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET')) === 'OPTIONS') {
    http_response_code(204);
    exit;
}

require_once __DIR__ . '/../app/config/init.php';
require_once __DIR__ . '/../app/autoload.php';

try {
    (new MobilePortalApi())->handle();
} catch (Throwable $exception) {
    error_log('[OSCA Mobile API] ' . $exception);
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'The request could not be completed.']);
}
