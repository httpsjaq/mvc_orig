<?php
/** Compatibility endpoint; all application requests are dispatched by the MVC router. */
$_GET['url'] = 'reset_password';
require __DIR__ . '/index.php';
