<?php
/** Compatibility endpoint; all application requests are dispatched by the MVC router. */
$_GET['url'] = 'forgot_password';
require __DIR__ . '/index.php';
