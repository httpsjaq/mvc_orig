<?php
/** Compatibility endpoint; all application requests are dispatched by the MVC router. */
$_GET['url'] = 'register';
require __DIR__ . '/index.php';
