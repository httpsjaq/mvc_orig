<?php
/** Compatibility endpoint; all application requests are dispatched by the MVC router. */
$_GET['url'] = 'verify_forgot_otp';
require __DIR__ . '/index.php';
