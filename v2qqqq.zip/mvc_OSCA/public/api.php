<?php
/** JSON API entry point: /api.php?resource=students&action=all */
require_once __DIR__ . '/../app/config/init.php';
require_once __DIR__ . '/../app/autoload.php';

$resource = strtolower(trim((string) ($_GET['resource'] ?? '')));
$action = strtolower(trim((string) ($_GET['action'] ?? 'all')));
$id = max(0, (int) ($_GET['id'] ?? 0));

try {
    $controllers = [
        'students' => 'StudentsApiController',
        'courses' => 'CoursesApiController',
        'users' => 'UsersApiController',
    ];

    if (!isset($controllers[$resource])) {
        http_response_code(404);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['status' => 'error', 'message' => 'Unknown API resource.']);
        exit;
    }

    $controllerClass = $controllers[$resource];
    (new $controllerClass())->dispatch($action, $id);
} catch (Throwable $exception) {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'error', 'message' => 'The request could not be completed.']);
}
