# OSCA MVC Alignment Notes

This project has been reorganized around the supplied PHP MVC template while preserving its existing OSCA workflows, database schema file, front-end assets, uploaded profile images, and bundled PHPMailer library.

## Main structure

```text
mvc_OSCA/
├── app/
│   ├── config/
│   │   ├── init.php          # Session, paths, database settings, timezone, shared DB helper
│   │   ├── app.php           # Application, reCAPTCHA, and SMTP settings
│   │   └── dbconn.php        # Backwards-compatible database include
│   ├── Core/
│   │   ├── Auth.php          # Session and role guards
│   │   ├── BaseController.php# Shared rendering and guard methods
│   │   ├── Controller.php    # Compatibility base for the original controllers
│   │   ├── Database.php      # Shared MySQLi connection factory
│   │   ├── Model.php         # Shared model connection
│   │   ├── Router.php        # Central front-controller router
│   │   └── helpers.php       # Escaping, redirect, flash, OTP, email helpers
│   ├── Controllers/         # Auth, admin, coordinator, dashboard, password, profile, roster
│   ├── Models/              # Account, coordinator roster, and course catalog models
│   ├── Api/                 # Admin JSON APIs and Flutter/mobile portal API
│   ├── views/               # Feature views and reusable layouts
│   └── autoload.php         # Template-style namespace loader plus legacy class map
├── public/                  # Web entry point, CSS, JavaScript, libraries, and uploads
├── users.sql                # Existing database export (preserved)
└── PHPMailer/               # Existing bundled mail library (preserved)
```

## Routing

The router supports the current query-string routes used throughout the UI (for example `index.php?url=admin_dashboard`) and clean paths such as `/admin/dashboard`, `/coordinator/schedule`, `/profile/edit`, and `/auth/login`. The old public PHP endpoints remain as small compatibility wrappers, so existing form actions and redirects continue to work.

The JSON API remains available through `api.php?resource=students&action=all` and also supports `/api/students/all`. The Flutter API remains available through `mobile_api.php`.

## Application features preserved

- Registration, login, logout, email OTP verification, account setup, forgot-password OTP, password reset, and password change.
- Admin dashboard, account administration, coordinator approvals, course management, and student roster management.
- Coordinator home, athletes, dance troupe, sports categories, practice schedules, reports, profile, and password workflows.
- Student/activity records, course catalog, existing database interactions, and JSON CRUD API endpoints.
- Flutter/mobile portal endpoints, including the existing resource actions.
- Existing views, styles, scripts, AdminLTE/Bootstrap assets, profile uploads, and PHPMailer library.

## Database compatibility

The existing models use MySQLi and the current `osca_db` database. To avoid breaking their existing prepared statements and result handling, `Core\Database` centralizes a **MySQLi** connection rather than switching the project to PDO. Models now share that connection through `Core\Model` where appropriate. Existing tables are not renamed by this refactor.

## Layout correction: footer alignment

The shared layout now closes `.content-wrapper` before rendering `.main-footer`, keeping the footer as a sibling of the content area. This prevents AdminLTE from applying the sidebar offset twice and shifting the footer too far to the right. The same shared footer is used by coordinator and administrator pages.

## Before deployment

1. Import `users.sql` into MySQL if the database has not already been set up, and verify that the database name in `app/config/init.php` matches your local database.
2. Start Apache and MySQL, then open the project through its folder URL in the local web server (for example `http://localhost/mvc_OSCA/`).
3. Verify SMTP and reCAPTCHA settings in `app/config/app.php`. If any credentials in the original project are real, rotate them and move production secrets into environment variables before publishing or deploying the project.
4. Keep `public/` as the intended web-accessible directory when deploying to a server.

## Validation performed for this refactor

- PHP syntax checks passed for the application PHP files and the bundled PHP library.
- The MVC autoloader successfully loaded 20 core, controller, model, and API classes.
- 13 route aliases were checked to ensure they resolve to controller actions.

A full end-to-end login/API check still requires the configured MySQL database, a running web server, and working SMTP credentials.
