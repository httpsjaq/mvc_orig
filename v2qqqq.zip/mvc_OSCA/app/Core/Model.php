<?php

namespace Core;

use mysqli;

/** Base model providing the application's shared MySQLi connection. */
abstract class Model
{
    protected mysqli $db;

    public function __construct()
    {
        $this->db = Database::connect();
    }
}
