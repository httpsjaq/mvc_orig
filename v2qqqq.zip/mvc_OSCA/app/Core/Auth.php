<?php

namespace Core;

/** Shared session, identity, and role checks for web controllers. */
class Auth
{
    public static function check(): bool
    {
        return !empty($_SESSION['email']);
    }

    public static function user(): ?array
    {
        if (!self::check()) {
            return null;
        }

        return (new \User())->findByEmail((string) $_SESSION['email']);
    }

    public static function requireGuest(): void
    {
        if (self::check()) {
            \redirect('index.php?url=home');
        }
    }

    public static function requireLogin(): array
    {
        $user = self::user();
        if (!$user) {
            \redirect('login.php');
        }
        return $user;
    }

    public static function requireAdmin(): array
    {
        $user = self::requireLogin();
        if (($user['role'] ?? '') !== 'admin' || ($user['status'] ?? '') !== 'verified') {
            http_response_code(403);
            exit('Forbidden');
        }
        return $user;
    }

    /** Require a verified account and, by default, a completed profile. */
    public static function requireUser(\User $model, bool $requireProfileComplete = true): array
    {
        if (!self::check()) {
            \redirect('login.php');
        }

        $user = $model->findByEmail((string) $_SESSION['email']);
        if (!$user) {
            $_SESSION = [];
            if (session_status() === PHP_SESSION_ACTIVE) {
                session_destroy();
            }
            \redirect('login.php');
        }

        if (($user['status'] ?? '') !== 'verified') {
            $_SESSION['pending_email'] = $user['email'];
            \redirect('verify_otp.php');
        }

        if ($requireProfileComplete && empty($user['profile_completed'])) {
            $_SESSION['setup_email'] = $user['email'];
            \redirect('setup_account.php');
        }

        return $user;
    }
}
