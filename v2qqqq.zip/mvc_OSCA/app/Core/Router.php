<?php

namespace Core;

/**
 * Front-controller router modelled after the supplied MVC template.
 * It supports clean paths and all pre-existing ?url=... OSCA routes so old links remain valid.
 */
class Router
{
    /** Dispatch a request to a controller action. */
    public function dispatch(): void
    {
        [$route, $pathParameters] = $this->resolveRoute();
        $route = $this->normalizeRoute($route);
        $route = $this->mapCleanPath($route, $pathParameters);

        $this->applyRoleRestrictions($route);
        $_GET['url'] = $route;

        [$controllerClass, $action, $arguments] = $this->resolveTarget($route, $pathParameters);
        if (!$controllerClass || !class_exists($controllerClass)) {
            $this->notFound('Page not found.');
        }

        $controller = new $controllerClass();
        if (!is_callable([$controller, $action])) {
            $this->notFound('Page not found.');
        }

        $controller->{$action}(...$arguments);
    }

    /** Derive the route either from the legacy query string or from the requested path. */
    private function resolveRoute(): array
    {
        if (isset($_GET['url']) && is_string($_GET['url'])) {
            $parts = array_values(array_filter(explode('/', trim($_GET['url'], '/')), 'strlen'));
            return [$parts, []];
        }

        $requestPath = parse_url((string) ($_SERVER['REQUEST_URI'] ?? '/'), PHP_URL_PATH) ?: '/';
        $basePath = parse_url((string) BASE_URL, PHP_URL_PATH) ?: '';
        if ($basePath !== '' && str_starts_with($requestPath, rtrim($basePath, '/') . '/')) {
            $requestPath = substr($requestPath, strlen(rtrim($basePath, '/')));
        } elseif ($basePath !== '' && rtrim($requestPath, '/') === rtrim($basePath, '/')) {
            $requestPath = '/';
        }

        $requestPath = preg_replace('~/public(?:/|$)~', '/', $requestPath) ?? $requestPath;
        $parts = array_values(array_filter(explode('/', trim($requestPath, '/')), 'strlen'));

        // Ignore the filename when a front-controller URL is requested directly.
        if (isset($parts[0]) && $parts[0] === 'index.php') {
            array_shift($parts);
        }
        return [$parts, $parts];
    }

    private function normalizeRoute(array $parts): string
    {
        return strtolower(implode('/', array_map(static function ($part): string {
            return str_replace('_', '-', trim((string) $part));
        }, $parts)));
    }

    /** Translate clean URL paths into the same logical route keys used by legacy links. */
    private function mapCleanPath(string $route, array $pathParts): string
    {
        $exact = [
            '' => 'home',
            'dashboard' => 'home',
            'dashboard/index' => 'home',
            'auth' => 'login',
            'auth/login' => 'login',
            'auth/register' => 'register',
            'auth/logout' => 'logout',
            'auth/verify-otp' => 'verify_otp',
            'auth/setup-account' => 'setup_account',
            'auth/forgot-password' => 'forgot_password',
            'auth/verify-forgot-otp' => 'verify_forgot_otp',
            'auth/reset-password' => 'reset_password',
            'password/forgot-password' => 'forgot_password',
            'password/verify-forgot-otp' => 'verify_forgot_otp',
            'password/reset-password' => 'reset_password',
            'password/change' => 'change_password',
            'password/verify-change-password-otp' => 'verify_change_password_otp',
            'password/set-new-password' => 'set_new_password',
            'profile/edit' => 'edit_profile',
            'admin' => 'admin_dashboard',
            'admin/dashboard' => 'admin_dashboard',
            'admin/users' => 'admin_users',
            'admin/users/create' => 'admin_new_user',
            'admin/courses' => 'admin_courses',
            'admin/students' => 'admin_students',
            'courses' => 'admin_courses',
            'students' => 'admin_students',
            'users' => 'admin_users',
            'coordinator' => 'home',
            'coordinator/home' => 'home',
            'coordinator/athletes' => 'athletes',
            'coordinator/dance' => 'dance',
            'coordinator/sports' => 'sports',
            'coordinator/schedule' => 'schedule',
            'coordinator/reports' => 'reports',
            'coordinator/profile' => 'profile',
        ];

        if (isset($exact[$route])) {
            return $exact[$route];
        }

        if (preg_match('~^admin/users/edit/(\d+)$~', $route, $matches)) {
            $_GET['id'] = (int) $matches[1];
            return 'admin_edit_user';
        }

        // Legacy aliases keep existing menu and form actions working.
        $legacyAliases = [
            'edit-profile' => 'edit_profile',
            'change-password' => 'change_password',
            'verify-change-password-otp' => 'verify_change_password_otp',
            'set-new-password' => 'set_new_password',
            'forgot-password' => 'forgot_password',
            'verify-forgot-otp' => 'verify_forgot_otp',
            'reset-password' => 'reset_password',
            'verify-otp' => 'verify_otp',
            'setup-account' => 'setup_account',
            'admin-edit-user' => 'admin_edit_user',
            'admin-courses' => 'admin_courses',
            'admin-students' => 'admin_students',
            'admin-users' => 'admin_users',
            'admin-new-user' => 'admin_new_user',
            'admin-dashboard' => 'admin_dashboard',
        ];
        return $legacyAliases[$route] ?? str_replace('-', '_', $route);
    }

    /** Preserve the role-based defaults formerly implemented in public/index.php. */
    private function applyRoleRestrictions(string &$route): void
    {
        $role = (string) ($_SESSION['role'] ?? '');
        $guestRoutes = [
            'login', 'register', 'logout', 'forgot_password', 'verify_forgot_otp',
            'reset_password', 'verify_otp', 'setup_account'
        ];
        if (in_array($route, $guestRoutes, true)) {
            return;
        }

        $protectedRoutes = [
            'home', 'athletes', 'dance', 'sports', 'schedule', 'reports', 'profile',
            'edit_profile', 'change_password', 'verify_change_password_otp', 'set_new_password',
            'admin_dashboard', 'admin_edit_user', 'admin_courses', 'admin_students',
            'admin_users', 'admin_new_user'
        ];
        if (!in_array($route, $protectedRoutes, true)) {
            return;
        }

        if ($role === 'admin') {
            $allowed = ['admin_dashboard', 'admin_edit_user', 'admin_courses', 'admin_students', 'admin_users', 'admin_new_user'];
            if (!in_array($route, $allowed, true)) {
                $route = 'admin_dashboard';
            }
            return;
        }

        if ($role === 'teacher') {
            $allowed = ['home', 'athletes', 'dance', 'sports', 'schedule', 'reports', 'profile', 'edit_profile', 'change_password', 'verify_change_password_otp', 'set_new_password'];
            if (!in_array($route, $allowed, true)) {
                $route = 'home';
            }
            return;
        }

        if (in_array($route, ['athletes', 'dance', 'sports', 'schedule', 'reports'], true) || str_starts_with($route, 'admin_')) {
            $route = 'home';
        }
    }

    /** Route table: controller logic remains in its existing feature controllers. */
    private function resolveTarget(string $route, array $pathParameters): array
    {
        $targets = [
            'login' => ['AuthController', 'login', []],
            'register' => ['AuthController', 'register', []],
            'logout' => ['AuthController', 'logout', []],
            'verify_otp' => ['AuthController', 'verifyOtp', []],
            'setup_account' => ['AuthController', 'setupAccount', []],
            'forgot_password' => ['PasswordController', 'forgotPassword', []],
            'verify_forgot_otp' => ['PasswordController', 'verifyForgotOtp', []],
            'reset_password' => ['PasswordController', 'resetPassword', []],
            'change_password' => ['PasswordController', 'changePassword', []],
            'verify_change_password_otp' => ['PasswordController', 'verifyChangePasswordOtp', []],
            'set_new_password' => ['PasswordController', 'setNewPassword', []],
            'profile' => ['ProfileController', 'show', []],
            'edit_profile' => ['ProfileController', 'edit', []],
            'admin_dashboard' => ['AdminController', 'dashboard', []],
            'admin_edit_user' => ['AdminController', 'editUser', []],
            'admin_users' => ['AdminController', 'users', []],
            'admin_new_user' => ['AdminController', 'createUser', []],
            'admin_courses' => ['CoursesController', 'index', []],
            'admin_students' => ['StudentsController', 'index', []],
            'athletes' => ['CoordinatorController', 'show', ['athletes']],
            'dance' => ['CoordinatorController', 'show', ['dance']],
            'sports' => ['CoordinatorController', 'show', ['sports']],
            'schedule' => ['CoordinatorController', 'show', ['schedule']],
            'reports' => ['CoordinatorController', 'show', ['reports']],
        ];

        if ($route === 'home') {
            if (($_SESSION['role'] ?? '') === 'teacher') {
                return ['CoordinatorController', 'show', ['home']];
            }
            return ['DashboardController', 'show', []];
        }

        return $targets[$route] ?? ['', '', []];
    }

    private function notFound(string $message): never
    {
        http_response_code(404);
        header('Content-Type: text/plain; charset=utf-8');
        exit($message);
    }
}
