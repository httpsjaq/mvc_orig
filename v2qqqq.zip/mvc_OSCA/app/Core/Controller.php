<?php
/**
 * Backwards-compatible controller name used by the existing OSCA modules.
 * New code should extend Core\BaseController directly.
 */
require_once __DIR__ . '/BaseController.php';

class Controller extends \Core\BaseController
{
}
