<?php

namespace Core;

require_once __DIR__ . '/helpers.php';

/**
 * Shared MVC controller base.
 * Includes the template-style view/layout helpers and the OSCA-specific session guards.
 */
class BaseController
{
    protected \User $userModel;

    public function __construct()
    {
        $this->userModel = new \User();
    }

    /** Render a view with a layout, or with no layout when $layout is 'none'. */
    public function view(string $view, array $data = [], string $layout = 'default'): void
    {
        $viewFile = dirname(__DIR__) . '/views/' . trim($view, '/') . '.php';
        if (!is_file($viewFile)) {
            http_response_code(500);
            exit('View not found.');
        }

        extract($data, EXTR_SKIP);

        if ($layout === 'none') {
            require $viewFile;
            return;
        }

        ob_start();
        require $viewFile;
        $content = (string) ob_get_clean();

        $layoutFile = dirname(__DIR__) . '/views/Layout/' . $layout . '.php';
        if (!is_file($layoutFile)) {
            http_response_code(500);
            exit('Layout not found.');
        }

        require $layoutFile;
    }

    /** Render an authenticated OSCA page using the existing shared layout files. */
    protected function renderApp(string $viewPath, array $data = []): void
    {
        $viewFile = dirname(__DIR__) . '/views/' . trim($viewPath, '/') . '.php';
        if (!is_file($viewFile)) {
            http_response_code(500);
            exit('View not found.');
        }

        extract($data, EXTR_SKIP);
        include dirname(__DIR__) . '/views/layout/header.php';
        include dirname(__DIR__) . '/views/layout/sidebar.php';
        include $viewFile;
        include dirname(__DIR__) . '/views/layout/footer.php';
    }

    /** Render a guest-facing authentication page using the existing auth layout. */
    protected function renderAuth(string $viewPath, array $data = []): void
    {
        $viewFile = dirname(__DIR__) . '/views/' . trim($viewPath, '/') . '.php';
        if (!is_file($viewFile)) {
            http_response_code(500);
            exit('View not found.');
        }

        extract($data, EXTR_SKIP);
        include dirname(__DIR__) . '/views/layout/auth_header.php';
        include $viewFile;
        include dirname(__DIR__) . '/views/layout/auth_footer.php';
    }

    protected function requireGuest(): void
    {
        Auth::requireGuest();
    }

    protected function requireUser(bool $requireProfileComplete = true): array
    {
        return Auth::requireUser($this->userModel, $requireProfileComplete);
    }

    public function json(array $data, int $statusCode = 200): void
    {
        http_response_code($statusCode);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
        exit;
    }

    public function redirect(string $url): void
    {
        \redirect($url);
    }
}
