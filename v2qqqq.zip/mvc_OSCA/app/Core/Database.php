<?php

namespace Core;

use mysqli;
use RuntimeException;
use Throwable;

/** Centralized MySQLi connection factory shared by the OSCA models. */
class Database
{
    private static ?mysqli $connection = null;

    public static function connect(): mysqli
    {
        if (self::$connection instanceof mysqli) {
            return self::$connection;
        }

        try {
            mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
            $connection = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
            $connection->set_charset(DB_CHARSET);
            self::$connection = $connection;
            return self::$connection;
        } catch (Throwable $exception) {
            // Avoid exposing host names, user names, or connection details to visitors.
            throw new RuntimeException(
                'Database connection failed. Check the MySQL service and application configuration.',
                0,
                $exception
            );
        }
    }
}
