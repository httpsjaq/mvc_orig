<?php
/** Admin managed course catalog, based on the sample template's Courses model. */
require_once __DIR__ . '/../../config/init.php';

class CourseCatalog extends \Core\Model {
    public function __construct() {
        // Reuse the shared MVC model connection before ensuring the catalog table exists.
        parent::__construct();
        $this->db->query("CREATE TABLE IF NOT EXISTS courses (
            id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(55) NOT NULL UNIQUE,
            created DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            modified DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }

    public function all(): array {
        // Return every course with its creation and last-updated timestamps.
        $result = $this->db->query('SELECT id, title, created, modified FROM courses ORDER BY title');
        return $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
    }

    public function save(string $title, int $id = 0): bool {
        // Update the selected course when an ID is supplied, or insert a new course otherwise.
        if ($id > 0) {
            $stmt = $this->db->prepare('UPDATE courses SET title=? WHERE id=?');
            $stmt->bind_param('si', $title, $id);
        } else {
            $stmt = $this->db->prepare('INSERT INTO courses (title) VALUES (?)');
            $stmt->bind_param('s', $title);
        }
        return $stmt->execute();
    }

    public function delete(int $id): bool {
        // Remove one course by ID and report whether a row was deleted.
        $stmt = $this->db->prepare('DELETE FROM courses WHERE id=?');
        $stmt->bind_param('i', $id);
        return $stmt->execute() && $stmt->affected_rows === 1;
    }
}


