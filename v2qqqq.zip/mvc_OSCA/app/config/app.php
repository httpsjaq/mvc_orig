<?php
/**
 * Application-wide settings.
 * Keep environment-specific credentials here and never commit production secrets.
 */

if (!defined('APP_NAME')) {
    define('APP_NAME', 'Office of Sports, Culture, and Arts');
}

if (!defined('RECAPTCHA_SITE_KEY')) {
    define('RECAPTCHA_SITE_KEY', '6Lec9WksAAAAAGrezQR5SNp2krow4u0L_LTBNq2G');
}
if (!defined('RECAPTCHA_SECRET_KEY')) {
    define('RECAPTCHA_SECRET_KEY', '6Lec9WksAAAAAHEmnJQVB_I9dInOYz_iFvWdgAdM');
}

if (!defined('MAIL_FROM_ADDRESS')) {
    define('MAIL_FROM_ADDRESS', 'PHPMailerTest96@gmail.com');
}
if (!defined('MAIL_FROM_NAME')) {
    define('MAIL_FROM_NAME', 'Quiz System');
}
if (!defined('SMTP_HOST')) {
    define('SMTP_HOST', 'smtp.gmail.com');
}
if (!defined('SMTP_PORT')) {
    define('SMTP_PORT', 587);
}
if (!defined('SMTP_USERNAME')) {
    define('SMTP_USERNAME', 'PHPMailerTest96@gmail.com');
}
if (!defined('SMTP_PASSWORD')) {
    define('SMTP_PASSWORD', 'lvaclmsldrklbesl');
}
if (!defined('SMTP_SECURE')) {
    define('SMTP_SECURE', 'tls');
}
