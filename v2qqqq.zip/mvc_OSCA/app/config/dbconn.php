<?php
/**
 * Backwards-compatible database include.
 * Prefer Core\Database or Core\Model in newly written modules.
 */
require_once __DIR__ . '/init.php';
require_once dirname(__DIR__) . '/autoload.php';
$conn = \Core\Database::connect();
