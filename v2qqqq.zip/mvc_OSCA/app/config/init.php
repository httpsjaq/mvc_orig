<?php
/**
 * Shared application bootstrap.
 * Defines paths and configuration once, starts the session, and exposes the
 * existing MySQLi connection helper used by the application models.
 */

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

if (!defined('APP_ROOT')) {
    define('APP_ROOT', dirname(__DIR__, 2));
}
if (!defined('BASE_PATH')) {
    define('BASE_PATH', dirname(__DIR__));
}
if (!defined('PUBLIC_PATH')) {
    define('PUBLIC_PATH', APP_ROOT . DIRECTORY_SEPARATOR . 'public');
}

// Compute the project URL root for installations in a subfolder such as /mvc_OSCA.
if (!defined('BASE_URL')) {
    $scriptName = str_replace('\\', '/', (string) ($_SERVER['SCRIPT_NAME'] ?? '/'));
    $scriptDirectory = rtrim(str_replace('\\', '/', dirname($scriptName)), '/');
    $scriptDirectory = preg_replace('~/public(?:/.*)?$~', '', $scriptDirectory) ?? $scriptDirectory;
    $scriptDirectory = $scriptDirectory === '/' ? '' : $scriptDirectory;
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    define('BASE_URL', $scheme . '://' . $host . $scriptDirectory);
}

if (!defined('DB_HOST')) {
    define('DB_HOST', 'localhost');
}
if (!defined('DB_NAME')) {
    define('DB_NAME', 'osca_db');
}
if (!defined('DB_USER')) {
    define('DB_USER', 'root');
}
if (!defined('DB_PASS')) {
    define('DB_PASS', '');
}
if (!defined('DB_CHARSET')) {
    define('DB_CHARSET', 'utf8mb4');
}

date_default_timezone_set('Asia/Manila');
require_once __DIR__ . '/app.php';

/**
 * Backwards-compatible connection helper for existing application code.
 * New model code should use Core\Database through Core\Model.
 */
function db_connection(): mysqli
{
    return \Core\Database::connect();
}
