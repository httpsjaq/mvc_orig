<?php
/** Shared header for guest-facing authentication pages. */
?>
<!DOCTYPE html>
<!-- Shared document head for public login, signup, verification, and recovery pages. -->
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <base href="<?php echo e(rtrim(BASE_URL, '/') . '/'); ?>">
    <title><?php echo e(($pageTitle ?? APP_NAME) . ' - ' . APP_NAME); ?></title>
    <link rel="stylesheet" href="bootstrap-5.0.2/bootstrap-5.0.2-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
    <link rel="stylesheet" href="css/app.css">
    <?php if (!empty($showRecaptcha)): ?><script src="https://www.google.com/recaptcha/api.js" async defer></script><?php endif; ?>
</head>
<body class="auth-body">
