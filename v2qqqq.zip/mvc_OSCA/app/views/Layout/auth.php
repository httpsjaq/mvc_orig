<?php
/** Template-style authentication layout, reusing the existing shared auth header/footer. */
include __DIR__ . '/../layout/auth_header.php';
echo $content ?? '';
include __DIR__ . '/../layout/auth_footer.php';
