<?php
/** Template-style default layout, composed from the existing OSCA AdminLTE shell. */
include __DIR__ . '/../layout/header.php';
include __DIR__ . '/../layout/sidebar.php';
echo $content ?? '';
include __DIR__ . '/../layout/footer.php';
