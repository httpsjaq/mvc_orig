<?php
/**
 * REST API used by the Flutter OSCA mobile app.
 *
 * The web application and this API use the same db_connection() helper, so every
 * successful API change is saved into the same MySQL database as the PHP website.
 */
require_once __DIR__ . '/../config/init.php';

class MobilePortalApi {
    private mysqli $db;
    private ?array $user = null;

    public function __construct() {
        $this->db = db_connection();
    }

    /** Route a request using ?resource=name&action=name. */
    public function handle(): void {
        $resource = strtolower(trim($_GET['resource'] ?? ''));
        $action = strtolower(trim($_GET['action'] ?? ''));
        $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');

        if ($method === 'OPTIONS') {
            http_response_code(204);
            exit;
        }

        try {
            // A public health check helps verify that PHP can connect to MySQL.
            if ($resource === 'system' && $action === 'ping' && $method === 'GET') {
                $this->respond(['status' => 'success', 'message' => 'API and database are available.']);
            }

            if ($resource === 'auth' && $action === 'login' && $method === 'POST') {
                $this->login();
            }

            // Every other route requires a valid bearer token.
            $this->user = $this->requireUser();

            if ($resource === 'auth' && $action === 'me' && $method === 'GET') {
                $this->respond(['data' => $this->publicUser($this->user)]);
            }
            if ($resource === 'auth' && $action === 'logout' && $method === 'POST') {
                $this->logout();
            }

            switch ($resource) {
                case 'announcements': $this->announcements($action, $method); break;
                case 'concerns': $this->concerns($action, $method); break;
                case 'feedback': $this->feedback($action, $method); break;
                case 'achievements': $this->achievements($action, $method); break;
                case 'roster': $this->roster($action, $method); break;
                case 'schedules': $this->schedules($action, $method); break;
                default: $this->respond(['status' => 'error', 'message' => 'Unknown API resource.'], 404);
            }
        } catch (Throwable $error) {
            // Do not return SQL details, credentials, or stack traces to a mobile client.
            $this->respond(['status' => 'error', 'message' => 'The request could not be completed. Check the server configuration and database schema.'], 500);
        }
    }

    /** Verify credentials against the same users table the web login uses. */
    private function login(): void {
        $data = $this->requestData();
        $identity = trim((string) ($data['email'] ?? $data['username'] ?? ''));
        $password = (string) ($data['password'] ?? '');
        if ($identity === '' || $password === '') {
            $this->respond(['status' => 'error', 'message' => 'Enter your email/username and password.'], 422);
        }

        $stmt = $this->db->prepare('SELECT * FROM users WHERE email = ? OR username = ? LIMIT 1');
        $stmt->bind_param('ss', $identity, $identity);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();

        if (!$user || !password_verify($password, (string) $user['password'])) {
            $this->respond(['status' => 'error', 'message' => 'Invalid login credentials.'], 401);
        }
        if (($user['status'] ?? '') === 'banned') {
            $this->respond(['status' => 'error', 'message' => 'This account has been disabled. Contact an administrator.'], 403);
        }
        if (($user['status'] ?? '') !== 'verified') {
            $this->respond(['status' => 'error', 'message' => 'This account is not verified yet. Complete the verification step on the website.'], 403);
        }
        if (empty($user['profile_completed'])) {
            $this->respond(['status' => 'error', 'message' => 'Complete your profile on the website before using the mobile app.'], 403);
        }
        if (($user['role'] ?? '') === 'teacher' && !in_array(($user['teacher_approval_status'] ?? ''), ['', 'approved'], true)) {
            $this->respond(['status' => 'error', 'message' => 'Your Coordinator account has not been approved by the administrator.'], 403);
        }
        if (!in_array(($user['role'] ?? ''), ['admin', 'teacher', 'student'], true)) {
            $this->respond(['status' => 'error', 'message' => 'This account role is not supported.'], 403);
        }

        // Store only a SHA-256 hash in the database; return the raw token to the app once.
        $token = bin2hex(random_bytes(32));
        $tokenHash = hash('sha256', $token);
        $deleteOld = $this->db->prepare('DELETE FROM api_tokens WHERE user_id = ? AND expires_at < NOW()');
        $deleteOld->bind_param('i', $user['id']);
        $deleteOld->execute();

        $save = $this->db->prepare('INSERT INTO api_tokens (token_hash, user_id, expires_at) VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 30 DAY))');
        $userId = (int) $user['id'];
        $save->bind_param('si', $tokenHash, $userId);
        $save->execute();
        $expiryQuery = $this->db->prepare('SELECT expires_at FROM api_tokens WHERE token_hash=?');
        $expiryQuery->bind_param('s', $tokenHash);
        $expiryQuery->execute();
        $expiresAt = $expiryQuery->get_result()->fetch_assoc()['expires_at'] ?? null;

        $this->respond([
            'status' => 'success',
            'token' => $token,
            'expires_at' => $expiresAt,
            'data' => $this->publicUser($user),
        ]);
    }

    /** Load the signed-in user from a token sent in the Authorization header. */
    private function requireUser(): array {
        $header = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';
        if (!preg_match('/Bearer\s+(.+)/i', $header, $matches)) {
            $this->respond(['status' => 'error', 'message' => 'Authentication required. Please sign in.'], 401);
        }
        $tokenHash = hash('sha256', trim($matches[1]));
        $stmt = $this->db->prepare('SELECT u.*, t.token_hash FROM api_tokens t INNER JOIN users u ON u.id=t.user_id WHERE t.token_hash=? AND t.expires_at > NOW() LIMIT 1');
        $stmt->bind_param('s', $tokenHash);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        if (!$user || ($user['status'] ?? '') !== 'verified' || empty($user['profile_completed']) ||
            (($user['role'] ?? '') === 'teacher' && !in_array(($user['teacher_approval_status'] ?? ''), ['', 'approved'], true))) {
            $this->respond(['status' => 'error', 'message' => 'Your session has expired or your account is not active. Please sign in again.'], 401);
        }
        $touch = $this->db->prepare('UPDATE api_tokens SET last_used_at=NOW() WHERE token_hash=?');
        $touch->bind_param('s', $tokenHash);
        $touch->execute();
        return $user;
    }

    private function logout(): void {
        $header = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';
        if (preg_match('/Bearer\s+(.+)/i', $header, $matches)) {
            $tokenHash = hash('sha256', trim($matches[1]));
            $stmt = $this->db->prepare('DELETE FROM api_tokens WHERE token_hash=?');
            $stmt->bind_param('s', $tokenHash);
            $stmt->execute();
        }
        $this->respond(['status' => 'success', 'message' => 'Signed out.']);
    }

    /** Announcements: students can read; Admin/Coordinator can post. */
    private function announcements(string $action, string $method): void {
        if ($action === 'all' && $method === 'GET') {
            $result = $this->db->query('SELECT id, title, message, audience, created_by, created_at FROM osca_announcements ORDER BY created_at DESC, id DESC');
            $this->respond(['data' => $result->fetch_all(MYSQLI_ASSOC)]);
        }
        if ($action === 'add' && $method === 'POST') {
            $this->requireCoordinatorOrAdmin();
            $data = $this->requestData();
            $title = trim((string) ($data['title'] ?? ''));
            $message = trim((string) ($data['message'] ?? ''));
            $audience = (string) ($data['audience'] ?? 'All Members');
            if ($title === '' || $message === '' || !in_array($audience, ['All Members', 'Student-Athletes', 'Performers'], true)) {
                $this->respond(['status' => 'error', 'message' => 'Enter a title, message, and valid audience.'], 422);
            }
            $creator = (int) $this->user['id'];
            $stmt = $this->db->prepare('INSERT INTO osca_announcements (title, message, audience, created_by) VALUES (?, ?, ?, ?)');
            $stmt->bind_param('sssi', $title, $message, $audience, $creator);
            $stmt->execute();
            $this->respond(['status' => 'success', 'message' => 'Announcement saved.', 'id' => $this->db->insert_id], 201);
        }
        $this->methodNotAllowed();
    }

    /** Student owns their concerns; Coordinator/Admin can review and update all. */
    private function concerns(string $action, string $method): void {
        if ($action === 'all' && $method === 'GET') {
            if ($this->isCoordinatorOrAdmin()) {
                $result = $this->db->query('SELECT id, user_id, student_name, student_id, title, category, details, status, created_at, updated_at FROM osca_student_concerns ORDER BY created_at DESC, id DESC');
            } else {
                $stmt = $this->db->prepare('SELECT id, user_id, student_name, student_id, title, category, details, status, created_at, updated_at FROM osca_student_concerns WHERE user_id=? ORDER BY created_at DESC, id DESC');
                $uid = (int) $this->user['id'];
                $stmt->bind_param('i', $uid);
                $stmt->execute();
                $result = $stmt->get_result();
            }
            $this->respond(['data' => $result->fetch_all(MYSQLI_ASSOC)]);
        }
        if ($action === 'add' && $method === 'POST') {
            if (($this->user['role'] ?? '') !== 'student') {
                $this->respond(['status' => 'error', 'message' => 'Only students can submit concerns.'], 403);
            }
            $data = $this->requestData();
            $title = trim((string) ($data['title'] ?? ''));
            $category = (string) ($data['category'] ?? 'Other');
            $details = trim((string) ($data['details'] ?? ''));
            if ($title === '' || $details === '' || !in_array($category, ['Activity Record', 'Membership', 'Activity Schedule', 'Other'], true)) {
                $this->respond(['status' => 'error', 'message' => 'Enter a title, details, and valid category.'], 422);
            }
            $uid = (int) $this->user['id'];
            $studentName = (string) ($this->user['full_name'] ?? '');
            $studentId = (string) ($this->user['student_id'] ?? '');
            $stmt = $this->db->prepare('INSERT INTO osca_student_concerns (user_id, student_name, student_id, title, category, details) VALUES (?, ?, ?, ?, ?, ?)');
            $stmt->bind_param('isssss', $uid, $studentName, $studentId, $title, $category, $details);
            $stmt->execute();
            $this->respond(['status' => 'success', 'message' => 'Concern saved.', 'id' => $this->db->insert_id], 201);
        }
        if (in_array($action, ['status', 'update-status'], true) && in_array($method, ['POST', 'PATCH'], true)) {
            $this->requireCoordinatorOrAdmin();
            $data = $this->requestData();
            $id = (int) ($data['id'] ?? $_GET['id'] ?? 0);
            $status = (string) ($data['status'] ?? '');
            if ($id < 1 || !in_array($status, ['Open', 'In Progress', 'Resolved'], true)) {
                $this->respond(['status' => 'error', 'message' => 'Provide a valid concern ID and status.'], 422);
            }
            $stmt = $this->db->prepare('UPDATE osca_student_concerns SET status=? WHERE id=?');
            $stmt->bind_param('si', $status, $id);
            $stmt->execute();
            $this->respond(['status' => 'success', 'message' => 'Concern status updated.']);
        }
        $this->methodNotAllowed();
    }

    /** Students submit their own feedback; Coordinator/Admin can read the summary. */
    private function feedback(string $action, string $method): void {
        if ($action === 'all' && $method === 'GET') {
            if ($this->isCoordinatorOrAdmin()) {
                $result = $this->db->query('SELECT id, user_id, student_name, student_id, activity, rating, choice, created_at FROM osca_activity_feedback ORDER BY created_at DESC, id DESC');
            } else {
                $stmt = $this->db->prepare('SELECT id, user_id, student_name, student_id, activity, rating, choice, created_at FROM osca_activity_feedback WHERE user_id=? ORDER BY created_at DESC, id DESC');
                $uid = (int) $this->user['id'];
                $stmt->bind_param('i', $uid);
                $stmt->execute();
                $result = $stmt->get_result();
            }
            $this->respond(['data' => $result->fetch_all(MYSQLI_ASSOC)]);
        }
        if ($action === 'add' && $method === 'POST') {
            if (($this->user['role'] ?? '') !== 'student') {
                $this->respond(['status' => 'error', 'message' => 'Only students can submit feedback.'], 403);
            }
            $data = $this->requestData();
            $activity = trim((string) ($data['activity'] ?? ''));
            $choice = trim((string) ($data['choice'] ?? ''));
            $rating = (int) ($data['rating'] ?? 0);
            if ($activity === '' || $choice === '' || $rating < 1 || $rating > 5) {
                $this->respond(['status' => 'error', 'message' => 'Choose an activity, feedback option, and rating from 1 to 5.'], 422);
            }
            $uid = (int) $this->user['id'];
            $studentName = (string) ($this->user['full_name'] ?? '');
            $studentId = (string) ($this->user['student_id'] ?? '');
            $stmt = $this->db->prepare('INSERT INTO osca_activity_feedback (user_id, student_name, student_id, activity, rating, choice) VALUES (?, ?, ?, ?, ?, ?)');
            $stmt->bind_param('isssis', $uid, $studentName, $studentId, $activity, $rating, $choice);
            $stmt->execute();
            $this->respond(['status' => 'success', 'message' => 'Feedback saved.', 'id' => $this->db->insert_id], 201);
        }
        $this->methodNotAllowed();
    }

    /** Coordinator/Admin record achievements; students can only read their own records. */
    private function achievements(string $action, string $method): void {
        if ($action === 'all' && $method === 'GET') {
            if ($this->isCoordinatorOrAdmin()) {
                $result = $this->db->query('SELECT id, student_name, student_id, title, details, achievement_date, created_by, created_at FROM osca_achievements ORDER BY achievement_date DESC, id DESC');
            } else {
                $stmt = $this->db->prepare('SELECT id, student_name, student_id, title, details, achievement_date, created_by, created_at FROM osca_achievements WHERE student_id=? ORDER BY achievement_date DESC, id DESC');
                $studentId = (string) ($this->user['student_id'] ?? '');
                $stmt->bind_param('s', $studentId);
                $stmt->execute();
                $result = $stmt->get_result();
            }
            $this->respond(['data' => $result->fetch_all(MYSQLI_ASSOC)]);
        }
        if ($action === 'add' && $method === 'POST') {
            $this->requireCoordinatorOrAdmin();
            $data = $this->requestData();
            $studentName = trim((string) ($data['student_name'] ?? ''));
            $studentId = trim((string) ($data['student_id'] ?? ''));
            $title = trim((string) ($data['title'] ?? ''));
            $details = trim((string) ($data['details'] ?? ''));
            $date = trim((string) ($data['achievement_date'] ?? date('Y-m-d')));
            if ($studentName === '' || $studentId === '' || $title === '' || $details === '' || !$this->validDate($date)) {
                $this->respond(['status' => 'error', 'message' => 'Complete the student details, title, details, and date.'], 422);
            }
            $creator = (int) $this->user['id'];
            $stmt = $this->db->prepare('INSERT INTO osca_achievements (student_name, student_id, title, details, achievement_date, created_by) VALUES (?, ?, ?, ?, ?, ?)');
            $stmt->bind_param('sssssi', $studentName, $studentId, $title, $details, $date, $creator);
            $stmt->execute();
            $this->respond(['status' => 'success', 'message' => 'Achievement saved.', 'id' => $this->db->insert_id], 201);
        }
        $this->methodNotAllowed();
    }

    /** Read-only bridge to records already created by the PHP Coordinator workspace. */
    private function roster(string $action, string $method): void {
        if ($action !== 'all' || $method !== 'GET') $this->methodNotAllowed();
        if ($this->isCoordinatorOrAdmin()) {
            $result = $this->db->query("SELECT s.id, s.student_id, s.full_name, s.course, s.year_level, s.enrollment_year, s.jersey_number, s.sport_id, s.dance_member, s.profile_image, sp.name AS sport_name FROM coordinator_students s LEFT JOIN coordinator_sports sp ON sp.id=s.sport_id WHERE s.active=1 ORDER BY s.full_name");
            $this->respond(['data' => $result->fetch_all(MYSQLI_ASSOC)]);
        }
        $stmt = $this->db->prepare("SELECT s.id, s.student_id, s.full_name, s.course, s.year_level, s.enrollment_year, s.jersey_number, s.sport_id, s.dance_member, s.profile_image, sp.name AS sport_name FROM coordinator_students s LEFT JOIN coordinator_sports sp ON sp.id=s.sport_id WHERE s.active=1 AND s.student_id=? LIMIT 1");
        $studentId = (string) ($this->user['student_id'] ?? '');
        $stmt->bind_param('s', $studentId);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $this->respond(['data' => $rows]);
    }

    /** Read practice schedules created by the PHP Coordinator workspace. */
    private function schedules(string $action, string $method): void {
        if ($action !== 'all' || $method !== 'GET') $this->methodNotAllowed();
        $this->requireCoordinatorOrAdmin();
        $result = $this->db->query("SELECT id, group_type, group_name, practice_date, practice_time, location, status, created_at FROM coordinator_schedules ORDER BY practice_date DESC, practice_time DESC");
        $this->respond(['data' => $result->fetch_all(MYSQLI_ASSOC)]);
    }

    private function publicUser(array $user): array {
        $role = (string) ($user['role'] ?? 'student');
        $displayRole = $role === 'teacher' ? 'Coordinator' : ucfirst($role);
        return [
            'id' => (int) ($user['id'] ?? 0),
            'email' => (string) ($user['email'] ?? ''),
            'username' => (string) ($user['username'] ?? ''),
            'role' => $role,
            'display_role' => $displayRole,
            'full_name' => (string) ($user['full_name'] ?? ''),
            'student_id' => (string) ($user['student_id'] ?? ''),
            'teacher_id' => (string) ($user['teacher_id'] ?? ''),
            'course' => (string) ($user['course'] ?? ''),
            'year_level' => (string) ($user['year_level'] ?? ''),
            'section' => (string) ($user['section'] ?? ''),
            'profile_image' => (string) ($user['profile_image'] ?? 'default.png'),
        ];
    }

    private function isCoordinatorOrAdmin(): bool {
        return in_array(($this->user['role'] ?? ''), ['teacher', 'admin'], true);
    }

    private function requireCoordinatorOrAdmin(): void {
        if (!$this->isCoordinatorOrAdmin()) {
            $this->respond(['status' => 'error', 'message' => 'Coordinator or Admin access is required.'], 403);
        }
    }

    private function requestData(): array {
        $contentType = $_SERVER['CONTENT_TYPE'] ?? '';
        if (stripos($contentType, 'application/json') !== false) {
            $decoded = json_decode((string) file_get_contents('php://input'), true);
            return is_array($decoded) ? $decoded : [];
        }
        return $_POST;
    }

    private function validDate(string $value): bool {
        $date = DateTime::createFromFormat('Y-m-d', $value);
        return $date !== false && $date->format('Y-m-d') === $value;
    }

    private function methodNotAllowed(): void {
        $this->respond(['status' => 'error', 'message' => 'Unsupported API action or HTTP method.'], 405);
    }

    private function respond(array $payload, int $statusCode = 200): void {
        http_response_code($statusCode);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
        exit;
    }
}
