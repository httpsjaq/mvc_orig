<?php

/**
 * Lightweight autoloader based on the supplied MVC template, with a class map
 * for the OSCA modules that retain their existing global class names.
 */
$applicationRoot = __DIR__;

spl_autoload_register(static function (string $class) use ($applicationRoot): void {
    $prefixes = [
        'Core\\' => $applicationRoot . '/Core/',
        'Models\\' => $applicationRoot . '/Models/',
        'Controllers\\' => $applicationRoot . '/Controllers/',
        'Api\\' => $applicationRoot . '/Api/',
    ];

    foreach ($prefixes as $prefix => $directory) {
        if (!str_starts_with($class, $prefix)) {
            continue;
        }

        $relativeClass = substr($class, strlen($prefix));
        $file = $directory . str_replace('\\', '/', $relativeClass) . '.php';
        if (is_file($file)) {
            require_once $file;
        }
        return;
    }

    $legacyClassMap = [
        'Controller' => '/Core/Controller.php',
        'AuthController' => '/Controllers/auth/AuthController.php',
        'AdminController' => '/Controllers/admin/AdminController.php',
        'CoordinatorController' => '/Controllers/coordinator/CoordinatorController.php',
        'CoursesController' => '/Controllers/courses/CoursesController.php',
        'DashboardController' => '/Controllers/dashboard/DashboardController.php',
        'PasswordController' => '/Controllers/password/PasswordController.php',
        'ProfileController' => '/Controllers/profile/ProfileController.php',
        'StudentsController' => '/Controllers/students/StudentsController.php',
        'User' => '/Models/account/User.php',
        'StudentRoster' => '/Models/coordinator/StudentRoster.php',
        'CourseCatalog' => '/Models/courses/CourseCatalog.php',
        'ApiBaseController' => '/Api/ApiBaseController.php',
        'CoursesApiController' => '/Api/Courses/CoursesController.php',
        'StudentsApiController' => '/Api/Students/StudentsController.php',
        'UsersApiController' => '/Api/Users/UsersController.php',
        'MobilePortalApi' => '/Api/MobilePortalApi.php',
    ];

    if (isset($legacyClassMap[$class])) {
        $file = $applicationRoot . $legacyClassMap[$class];
        if (is_file($file)) {
            require_once $file;
        }
    }
});
