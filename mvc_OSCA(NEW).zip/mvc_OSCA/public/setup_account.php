<?php
/**
 * Public entry point for the post-verification profile setup page.
 */
// Start the session so profile setup can use the verified account email.
session_start();
require_once "../App/Controllers/auth/AuthController.php";
(new AuthController())->setupAccount();
