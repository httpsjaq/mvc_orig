<?php
/**
 * Front controller for authenticated pages.
 * Routes requests to the correct controller based on the url parameter.
 */
session_start();

require_once "../App/Controllers/dashboard/DashboardController.php";
require_once "../App/Controllers/coordinator/CoordinatorController.php";
require_once "../App/Controllers/profile/ProfileController.php";
require_once "../App/Controllers/password/PasswordController.php";
require_once "../App/Controllers/admin/AdminController.php";
require_once "../App/Controllers/courses/CoursesController.php";
require_once "../App/Controllers/students/StudentsController.php";
// The url query parameter selects a page; the session role limits which pages are reachable.
$page = $_GET['url'] ?? 'home';
$role = $_SESSION['role'] ?? '';

// Redirect unsupported pages to the home page allowed for this account role.
// Keep the original role-based default routing, while controllers enforce access too.
if ($role === 'admin') {
    $allowedPages = ['admin_dashboard', 'admin_edit_user', 'admin_courses', 'admin_students', 'admin_users', 'admin_new_user'];
    if (!in_array($page, $allowedPages, true)) {
        $page = 'admin_dashboard';
    }
} elseif ($role === 'teacher') {
    $allowedPages = ['home', 'athletes', 'dance', 'sports', 'schedule', 'reports', 'profile', 'edit_profile', 'change_password', 'verify_change_password_otp', 'set_new_password'];
    if (!in_array($page, $allowedPages, true)) {
        $page = 'home';
    }
} elseif (in_array($page, ['athletes', 'dance', 'sports', 'schedule', 'reports'], true) || str_starts_with($page, 'admin_')) {
    $page = 'home';
}

// Each case delegates page work to a controller, keeping routing separate from page logic.
switch ($page) {
    case 'athletes':
    case 'dance':
    case 'sports':
    case 'schedule':
    case 'reports':
        (new CoordinatorController())->show($page);
        break;

    case 'admin_dashboard':
        (new AdminController())->dashboard();
        break;

    case 'admin_edit_user':
        (new AdminController())->editUser();
        break;

    case 'admin_courses':
        (new CoursesController())->index();
        break;

    case 'admin_students':
        (new StudentsController())->index();
        break;

    case 'admin_users':
        (new AdminController())->users();
        break;

    case 'admin_new_user':
        (new AdminController())->createUser();
        break;

    case 'profile':
        (new ProfileController())->show();
        break;

    case 'edit_profile':
        (new ProfileController())->edit();
        break;

    case 'change_password':
        (new PasswordController())->changePassword();
        break;

    case 'verify_change_password_otp':
        (new PasswordController())->verifyChangePasswordOtp();
        break;

    case 'set_new_password':
        (new PasswordController())->setNewPassword();
        break;

    case 'home':
    default:
        // Controllers handle authentication and role checks.
        if (($_SESSION['role'] ?? '') === 'teacher') {
            (new CoordinatorController())->show('home');
        } else {
            (new DashboardController())->show();
        }
        break;
}




