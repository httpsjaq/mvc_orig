<?php
/**
 * Public entry point for login.
 * Delegates work to AuthController to keep this file minimal.
 */
// Start the session before the authentication controller reads or saves account state.
session_start();
require_once "../App/Controllers/auth/AuthController.php";
(new AuthController())->login();
