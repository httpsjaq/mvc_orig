<?php
/**
 * Public entry point for registration OTP verification.
 */
// Start the session so the controller can find the pending registration account.
session_start();
require_once "../App/Controllers/auth/AuthController.php";
(new AuthController())->verifyOtp();
