<?php
/**
 * Public entry point for forgot-password requests.
 */
// Start the session so the recovery controller can track its OTP flow.
session_start();
require_once "../App/Controllers/password/PasswordController.php";
(new PasswordController())->forgotPassword();
