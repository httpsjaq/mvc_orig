<?php
/**
 * Public entry point for logout.
 */
// Start the session so the logout controller can clear it.
session_start();
require_once "../App/Controllers/auth/AuthController.php";
(new AuthController())->logout();
