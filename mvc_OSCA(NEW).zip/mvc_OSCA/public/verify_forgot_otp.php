<?php
/**
 * Public entry point for forgot-password OTP verification.
 */
// Start the session so the controller can find the pending password recovery request.
session_start();
require_once "../App/Controllers/password/PasswordController.php";
(new PasswordController())->verifyForgotOtp();
