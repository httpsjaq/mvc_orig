<?php
/**
 * Public entry point for registration.
 */
// Start the session so signup and email verification can pass state between pages.
session_start();
require_once "../App/Controllers/auth/AuthController.php";
(new AuthController())->register();
