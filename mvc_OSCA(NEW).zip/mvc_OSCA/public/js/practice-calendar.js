(function () {
  'use strict';

  // Locate the calendar widgets, date field, and schedule data embedded by the PHP view.
  const calendarRoot = document.getElementById('practice-calendar');
  const scheduleRoot = document.getElementById('practice-schedule');
  const timelineRoot = document.getElementById('practice-timeline');
  const dateInput = document.querySelector('input[name="practice_date"]');
  const dataNode = document.getElementById('practice-calendar-data');

  // Stop safely when this page does not contain the required calendar markup or library.
  if (!calendarRoot || !scheduleRoot || !timelineRoot || !dateInput || !dataNode || !window.calendarjs ||
      !window.calendarjs.Calendar || !window.calendarjs.Schedule || !window.calendarjs.Timeline) {
    return;
  }

  // This array holds the practice records decoded from the page.
  let practices = [];
  try {
    practices = JSON.parse(dataNode.textContent || '[]');
  } catch (error) {
    console.error('Could not read the practice schedule data.', error);
  }

  // Format a JavaScript date as a local YYYY-MM-DD value without a timezone shift.
  const localDate = (date) => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  // Use the form's selected date, or today's local date, as the starting calendar date.
  const initialDate = dateInput.value || localDate(new Date());
  dateInput.value = initialDate;

  // Keep the date form and weekly schedule on the same valid calendar date.
  const updateSelectedDate = (value) => {
    const selectedDate = String(value || '').slice(0, 10);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(selectedDate)) return;

    dateInput.value = selectedDate;
    if (weeklySchedule) {
      weeklySchedule.value = selectedDate;
      weeklySchedule.render();
    }
  };

  // Convert practice records to the labels and colors expected by the timeline widget.
  const timelineItems = practices.map((practice) => {
    const dateValue = String(practice.date || '');
    const date = new Date(`${dateValue}T00:00:00`);
    const displayDate = Number.isNaN(date.getTime())
      ? dateValue
      : new Intl.DateTimeFormat(undefined, { month: 'short', day: 'numeric', year: 'numeric' }).format(date);
    const displayTime = practice.start
      ? new Intl.DateTimeFormat(undefined, { hour: 'numeric', minute: '2-digit' }).format(new Date(`2000-01-01T${practice.start}`))
      : '';

    return {
      date: dateValue,
      title: practice.title,
      subtitle: [practice.description, displayDate, displayTime].filter(Boolean).join(' · '),
      description: practice.location || '',
      borderColor: practice.color || '#287a68'
    };
  });

  // Keep a reference to the weekly view so date changes can update it.
  let weeklySchedule = null;
  // Create the weekly calendar and prevent unsaved calendar clicks from becoming saved practices.
  weeklySchedule = window.calendarjs.Schedule(scheduleRoot, {
    type: 'week',
    value: initialDate,
    data: practices,
    oncreate: function (self, createdEvents) {
      const events = Array.isArray(createdEvents) ? createdEvents : [createdEvents];
      events.filter(Boolean).forEach((event) => self.deleteEvents(event.guid));
      window.alert('Use the Add a practice form to save practices.');
    }
  });

  // Create the inline date picker and connect its selection to the shared date update.
  const dateCalendar = window.calendarjs.Calendar(calendarRoot, {
    type: 'inline',
    value: initialDate,
    startingDay: 1,
    data: practices.map((practice) => ({ date: practice.date })),
    onchange: function (self, value) {
      updateSelectedDate(value);
    }
  });

  // When a user types a date, update both calendar widgets to match.
  dateInput.addEventListener('change', function () {
    if (dateCalendar && dateInput.value) dateCalendar.setValue(dateInput.value);
    updateSelectedDate(dateInput.value);
  });

  // Render the upcoming practice list in chronological order.
  window.calendarjs.Timeline(timelineRoot, {
    data: timelineItems,
    order: 'asc',
    align: 'left',
    message: 'No upcoming practices are scheduled.',
    height: 320
  });
})();
