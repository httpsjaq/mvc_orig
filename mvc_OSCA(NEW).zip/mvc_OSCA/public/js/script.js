(function () {
  // This private module groups the page interactions and exposes one startup function.
  const AppModule = (function () {
    // Selectors and the storage key are kept together so the interface hooks are easy to find.
    const s = {
      selectors: {
        sidebar: '.side-bar',
        openSidebarButton: '.menu-btn',
        closeSidebarButton: '.close-btn',
        submenuButton: '.sub-btn',
        passwordToggle: '.password-toggle'
      },
      sidebarStorageKey: 'sidebar'
    };

    // These variables cache page elements after the document has loaded.
    let sidebar;
    let openSidebarButton;
    let closeSidebarButton;

    // Start the interface by finding controls, connecting clicks, and restoring the saved sidebar state.
    function init() {
      cacheElements();
      bindEvents();
      restoreSidebarState();
    }

    // Find the sidebar buttons once so the event handlers can reuse them.
    function cacheElements() {
      sidebar = document.querySelector(s.selectors.sidebar);
      openSidebarButton = document.querySelector(s.selectors.openSidebarButton);
      closeSidebarButton = document.querySelector(s.selectors.closeSidebarButton);
    }

    // Connect each visible control to the function that handles its click.
    function bindEvents() {
      if (openSidebarButton) {
        openSidebarButton.addEventListener('click', openSidebar);
      }

      if (closeSidebarButton) {
        closeSidebarButton.addEventListener('click', closeSidebar);
      }

      document.querySelectorAll(s.selectors.submenuButton).forEach(function (button) {
        button.addEventListener('click', toggleSubmenu);
      });

      document.querySelectorAll(s.selectors.passwordToggle).forEach(function (button) {
        button.addEventListener('click', togglePassword);
      });
    }

    // Read the user's saved sidebar choice and apply it to the page.
    function restoreSidebarState() {
      if (!sidebar) return;
      setSidebarOpen(localStorage.getItem(s.sidebarStorageKey) === 'open');
    }

    // Show the navigation sidebar.
    function openSidebar() {
      setSidebarOpen(true);
    }

    // Hide the navigation sidebar.
    function closeSidebar() {
      setSidebarOpen(false);
    }

    // Update the sidebar classes and save its open or closed state for the next visit.
    function setSidebarOpen(isOpen) {
      if (!sidebar) return;

      sidebar.classList.toggle('active', isOpen);

      if (openSidebarButton) {
        openSidebarButton.classList.toggle('hidden', isOpen);
      }

      localStorage.setItem(s.sidebarStorageKey, isOpen ? 'open' : 'closed');
    }

    // Show or hide the submenu next to the clicked navigation control.
    function toggleSubmenu(event) {
      event.preventDefault();

      const submenu = event.currentTarget.nextElementSibling;
      if (!submenu) return;

      submenu.style.display =
        submenu.style.display === 'block' ? 'none' : 'block';
    }

    // Switch a password field between hidden and visible text and update its eye icon.
    function togglePassword(event) {
      const button = event.currentTarget;
      const input = document.getElementById(button.dataset.target);
      if (!input) return;

      const showPassword = input.type === 'password';
      input.type = showPassword ? 'text' : 'password';

      const icon = button.querySelector('i');
      if (icon) {
        icon.classList.toggle('bi-eye-fill', !showPassword);
        icon.classList.toggle('bi-eye-slash-fill', showPassword);
      }
    }

    return {
      init: init
    };
  })();

  // Wait until the page elements exist before starting the module.
  document.addEventListener('DOMContentLoaded', AppModule.init);
})();