<?php
/**
 * Public entry point for saving a new password after forgot-password OTP verification.
 */
// Start the session so the controller can confirm the recovery OTP was verified.
session_start();
require_once "../App/Controllers/password/PasswordController.php";
(new PasswordController())->resetPassword();
