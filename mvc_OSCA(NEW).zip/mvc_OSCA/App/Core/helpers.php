<?php
/**
 * Global helper functions used across the MVC application.
 * These functions keep controllers small and avoid repeating common logic.
 */
require_once __DIR__ . '/../Config/init.php';

/**
 * Escape dynamic output for safe HTML rendering.
 */
function e(?string $value): string {
    // Convert a value to safe, escaped text before placing it in HTML.
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

/**
 * Redirect to another URL and stop script execution.
 */
function redirect(string $url): void {
    // Send the browser to another page and stop the current request.
    header("Location: {$url}");
    exit();
}

/**
 * Save a one-time message to the session.
 */
function flash_set(string $key, string $message): void {
    // Save a short-lived message in the session for the next page request.
    $_SESSION['_flash'][$key] = $message;
}

/**
 * Read and remove a one-time message from the session.
 */
function flash_get(string $key): ?string {
    // Return a saved one-time message and remove it so it is shown only once.
    if (!isset($_SESSION['_flash'][$key])) {
        return null;
    }

    $message = $_SESSION['_flash'][$key];
    unset($_SESSION['_flash'][$key]);
    return $message;
}

/**
 * Build a readable full name from separate name parts.
 */
function build_full_name(?string $first, ?string $middleInitial, ?string $last, ?string $suffix): string {
    // Join the non-empty name parts into one readable full name.
    $parts = [];

    $first = trim((string) $first);
    $middleInitial = trim((string) $middleInitial);
    $last = trim((string) $last);
    $suffix = trim((string) $suffix);

    if ($first !== '') {
        $parts[] = $first;
    }

    if ($middleInitial !== '') {
        $parts[] = strtoupper(substr($middleInitial, 0, 1)) . '.';
    }

    if ($last !== '') {
        $parts[] = $last;
    }

    if ($suffix !== '') {
        $parts[] = $suffix;
    }

    return trim(implode(' ', $parts));
}

/**
 * Generate a 6-digit OTP code.
 */
function random_otp(): string {
    // Generate a secure six-digit code, keeping leading zeroes when needed.
    return str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);
}

/**
 * Compute the OTP expiry timestamp string used by the database.
 */
function otp_expiry_time(): string {
    // Return the database timestamp for ten minutes from now.
    return date('Y-m-d H:i:s', strtotime('+10 minutes'));
}

/**
 * Check whether reCAPTCHA is fully configured.
 */
function recaptcha_enabled(): bool {
    // Tell the forms whether both reCAPTCHA keys have been configured.
    return !empty(RECAPTCHA_SITE_KEY) && !empty(RECAPTCHA_SECRET_KEY);
}

/**
 * Verify a Google reCAPTCHA token.
 * Returns an array with an ok flag and a message for the UI.
 */
function verify_recaptcha_token(?string $token): array {
    // Ask Google's verification service whether a submitted reCAPTCHA token is valid.
    if (!recaptcha_enabled()) {
        return ['ok' => true, 'message' => 'reCAPTCHA is disabled in development mode.'];
    }

    if (empty($token)) {
        return ['ok' => false, 'message' => 'Please complete the reCAPTCHA.'];
    }

    // Package the token and request IP in the format Google's verification endpoint expects.
    $postData = http_build_query([
        'secret'   => RECAPTCHA_SECRET_KEY,
        'response' => $token,
        'remoteip' => $_SERVER['REMOTE_ADDR'] ?? ''
    ]);

    $context = stream_context_create([
        'http' => [
            'method'  => 'POST',
            'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
            'content' => $postData,
            'timeout' => 10
        ]
    ]);

    $response = @file_get_contents('https://www.google.com/recaptcha/api/siteverify', false, $context);
    if ($response === false) {
        return ['ok' => false, 'message' => 'Unable to verify reCAPTCHA right now.'];
    }

    $result = json_decode($response, true);
    return !empty($result['success'])
        ? ['ok' => true, 'message' => 'reCAPTCHA verified.']
        : ['ok' => false, 'message' => 'reCAPTCHA verification failed.'];
}

/**
 * Send an OTP email through PHPMailer.
 * Falls back to PHP mail() if PHPMailer cannot be found.
 */
function send_otp_email(string $toEmail, string $otp, string $subject = 'Your OTP Code', string $intro = 'Your verification code is'): array {
    // Send an OTP with PHPMailer when available, then try PHP mail as a fallback.
    // Locate the bundled mail library before choosing the SMTP or PHP mail transport.
    $src = dirname(__DIR__, 2) . '/PHPMailer/src';

    $exceptionFile = $src . '/Exception.php';
    $phpmailerFile = $src . '/PHPMailer.php';
    $smtpFile = $src . '/SMTP.php';

    if (file_exists($exceptionFile) && file_exists($phpmailerFile) && file_exists($smtpFile)) {
        require_once $exceptionFile;
        require_once $phpmailerFile;
        require_once $smtpFile;

        $mail = new \PHPMailer\PHPMailer\PHPMailer(true);

        try {
            $mail->isSMTP();
            $mail->Host       = SMTP_HOST;
            $mail->SMTPAuth   = true;
            $mail->Username   = SMTP_USERNAME;
            $mail->Password   = SMTP_PASSWORD;
            $mail->SMTPSecure = SMTP_SECURE;
            $mail->Port       = SMTP_PORT;

            $mail->SMTPOptions = [
                'ssl' => [
                    'verify_peer'       => false,
                    'verify_peer_name'  => false,
                    'allow_self_signed' => true
                ]
            ];

            $mail->setFrom(MAIL_FROM_ADDRESS, MAIL_FROM_NAME);
            $mail->addAddress($toEmail);
            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body    = '<p>' . e($intro) . ': <strong>' . e($otp) . '</strong></p><p>This code expires in 10 minutes.</p>';
            $mail->AltBody = "{$intro}: {$otp}. This code expires in 10 minutes.";

            $mail->send();
            return ['ok' => true, 'message' => 'OTP sent successfully.'];
        } catch (Throwable $e) {
            return ['ok' => false, 'message' => 'PHPMailer failed to send the OTP.'];
        }
    }

    $headers = 'From: ' . MAIL_FROM_NAME . ' <' . MAIL_FROM_ADDRESS . '>';
    $message = "{$intro}: {$otp}\nThis code expires in 10 minutes.";

    if (@mail($toEmail, $subject, $message, $headers)) {
        return ['ok' => true, 'message' => 'OTP sent successfully.'];
    }

    return ['ok' => false, 'message' => 'No mail transport is available.'];
}

