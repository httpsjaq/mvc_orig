<?php
require_once __DIR__ . '/../../Core/helpers.php';
/**
 * User model containing all database operations related to accounts.
 */
class User {
    /** @var mysqli Database connection used by every model method. */
    private mysqli $conn;

    public function __construct() {
        // Connect this account model to the application's shared database connection.
        require_once __DIR__ . '/../../Config/init.php';
        $this->conn = db_connection();
    }

    /**
     * Find a user by email.
     */
    public function findByEmail(string $email): ?array {
        // Look up and return the account with this email, or null when it does not exist.
        $stmt = $this->conn->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->num_rows ? $result->fetch_assoc() : null;
    }

    /**
     * Find a user by ID.
     */
    public function findById(int $id): ?array {
        // Look up and return the account with this numeric database ID.
        $stmt = $this->conn->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->num_rows ? $result->fetch_assoc() : null;
    }


    /**
     * Create an email/password account that still needs OTP verification.
     */
    public function createPendingAccount(string $email, string $passwordHash, string $otp, string $otpExpiry, string $role = 'student'): bool {
        // Insert a new account in pending status so it must verify its email first.
        if (!in_array($role, ['student', 'teacher'], true)) {
            return false;
        }

        // A new account cannot sign in until its email address has been verified.
        $status = 'pending';
        $profileCompleted = 0;

        $stmt = $this->conn->prepare("
            INSERT INTO users (email, password, role, otp_code, otp_expiry, status, profile_completed)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->bind_param("ssssssi", $email, $passwordHash, $role, $otp, $otpExpiry, $status, $profileCompleted);
        return $stmt->execute();
    }

    /**
     * Complete the profile setup after email verification.
     */
    public function completeProfile(string $email, array $data, string $role = 'student'): bool {
        // Save the profile fields that depend on whether the account is a student or coordinator.
        // Store both the separate name fields and a combined name used in page headings.
        $fullName = build_full_name(
            $data['first_name'] ?? '',
            $data['middle_initial'] ?? '',
            $data['last_name'] ?? '',
            $data['suffix'] ?? ''
        );
        $profileCompleted = 1;

        if ($role === 'teacher') {
            $academicRole = 'Coordinator';
            $approvalStatus = 'pending';
            $stmt = $this->conn->prepare("
                UPDATE users
                SET first_name = ?, middle_initial = ?, last_name = ?, suffix = ?, full_name = ?,
                    username = ?, teacher_id = ?, student_id = NULL, year_level = NULL, section = NULL,
                    academic_role = ?, profile_completed = ?, teacher_approval_status = ?
                WHERE email = ? AND role = 'teacher'
            ");
            $stmt->bind_param(
                'ssssssssiss',
                $data['first_name'],
                $data['middle_initial'],
                $data['last_name'],
                $data['suffix'],
                $fullName,
                $data['username'],
                $data['teacher_id'],
                $academicRole,
                $profileCompleted,
                $approvalStatus,
                $email
            );

            return $stmt->execute();
        }

        $academicRole = 'Student';

        $stmt = $this->conn->prepare("
            UPDATE users
            SET first_name = ?, middle_initial = ?, last_name = ?, suffix = ?, full_name = ?,
                username = ?, student_id = ?, year_level = ?, section = ?, academic_role = ?, profile_completed = ?
            WHERE email = ?
        ");

        $stmt->bind_param(
            "ssssssssssis",
            $data['first_name'],
            $data['middle_initial'],
            $data['last_name'],
            $data['suffix'],
            $fullName,
            $data['username'],
            $data['student_id'],
            $data['year_level'],
            $data['section'],
            $academicRole,
            $profileCompleted,
            $email
        );

        return $stmt->execute();
    }

    /**
     * Check if another account is using the same username or student ID.
     */
    public function profileIdentityExists(string $username, string $studentId, ?int $ignoreId = null): bool {
        // Check whether another account already uses this username or student ID.
        if ($ignoreId) {
            $stmt = $this->conn->prepare("
                SELECT id FROM users
                WHERE (username = ? OR student_id = ?) AND id != ?
            ");
            $stmt->bind_param("ssi", $username, $studentId, $ignoreId);
        } else {
            $stmt = $this->conn->prepare("
                SELECT id FROM users
                WHERE username = ? OR student_id = ?
            ");
            $stmt->bind_param("ss", $username, $studentId);
        }

        $stmt->execute();
        $result = $stmt->get_result();
        return $result->num_rows > 0;
    }

    /**
     * Check whether a coordinator username or coordinator ID is already used.
     */
    public function coordinatorIdentityExists(string $username, string $teacherId, ?int $ignoreId = null): bool {
        // Check whether another account already uses this username or coordinator ID.
        if ($ignoreId !== null) {
            $stmt = $this->conn->prepare('SELECT id FROM users WHERE (username = ? OR teacher_id = ?) AND id != ?');
            $stmt->bind_param('ssi', $username, $teacherId, $ignoreId);
        } else {
            $stmt = $this->conn->prepare('SELECT id FROM users WHERE username = ? OR teacher_id = ?');
            $stmt->bind_param('ss', $username, $teacherId);
        }
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->num_rows > 0;
    }

    /**
     * Save a new OTP and expiry for a specific email.
     */
    public function updateOtp(string $email, string $otp, string $otpExpiry): bool {
        // Replace the account's one-time code and its expiry timestamp.
        $stmt = $this->conn->prepare("UPDATE users SET otp_code = ?, otp_expiry = ? WHERE email = ?");
        $stmt->bind_param("sss", $otp, $otpExpiry, $email);
        return $stmt->execute();
    }

    /**
     * Mark a user as verified after OTP validation.
     */
    public function markVerified(string $email): bool {
        // Mark the email as verified and clear the registration code from the account.
        $status = 'verified';
        $stmt = $this->conn->prepare("UPDATE users SET status = ?, otp_code = NULL, otp_expiry = NULL WHERE email = ?");
        $stmt->bind_param("ss", $status, $email);
        return $stmt->execute();
    }

    /**
     * Validate a registration OTP for a pending user.
     */
    public function canVerifyOtp(string $email, string $otp): array {
        // Check that a pending registration has the matching, unexpired OTP.
        // Check account state before accepting the submitted registration code.
        $user = $this->findByEmail($email);

        if (!$user) {
            return ['ok' => false, 'message' => 'Account not found.'];
        }

        if (($user['status'] ?? '') !== 'pending') {
            return ['ok' => false, 'message' => 'This account is no longer waiting for verification.'];
        }

        if (($user['otp_code'] ?? '') !== $otp) {
            return ['ok' => false, 'message' => 'Invalid OTP code.'];
        }

        if (empty($user['otp_expiry']) || strtotime($user['otp_expiry']) < time()) {
            return ['ok' => false, 'message' => 'OTP has expired.'];
        }

        return ['ok' => true, 'user' => $user];
    }

    /**
     * Update editable profile details for the logged-in user.
     */
    public function updateProfile(int $id, array $data): bool {
        // Save the editable profile fields that match the user's account role.
        $fullName = build_full_name(
            $data['first_name'] ?? '',
            $data['middle_initial'] ?? '',
            $data['last_name'] ?? '',
            $data['suffix'] ?? ''
        );

        $user = $this->findById($id);
        if (($user['role'] ?? '') === 'teacher') {
            $stmt = $this->conn->prepare("
                UPDATE users
                SET first_name = ?, middle_initial = ?, last_name = ?, suffix = ?, full_name = ?, username = ?, teacher_id = ?
                WHERE id = ? AND role = 'teacher'
            ");
            $stmt->bind_param(
                'sssssssi',
                $data['first_name'],
                $data['middle_initial'],
                $data['last_name'],
                $data['suffix'],
                $fullName,
                $data['username'],
                $data['teacher_id'],
                $id
            );
            return $stmt->execute();
        }

        $stmt = $this->conn->prepare("
            UPDATE users
            SET first_name = ?, middle_initial = ?, last_name = ?, suffix = ?, full_name = ?,
                username = ?, student_id = ?, year_level = ?, section = ?
            WHERE id = ?
        ");

        $stmt->bind_param(
            "sssssssssi",
            $data['first_name'],
            $data['middle_initial'],
            $data['last_name'],
            $data['suffix'],
            $fullName,
            $data['username'],
            $data['student_id'],
            $data['year_level'],
            $data['section'],
            $id
        );

        return $stmt->execute();
    }

    /** Save the uploaded profile image filename for one account. */
    public function updateProfileImage(int $id, string $filename): bool {
        // Store the filename of the user's profile image in the account record.
        $stmt = $this->conn->prepare('UPDATE users SET profile_image = ? WHERE id = ?');
        $stmt->bind_param('si', $filename, $id);
        return $stmt->execute();
    }

    /**
     * Start a password reset or password change operation.
     */
    public function beginPasswordReset(string $email, string $otp, string $otpExpiry): bool {
        // Save a new OTP and mark the account as having a password change in progress.
        $pending = 1;
        $stmt = $this->conn->prepare("
            UPDATE users
            SET otp_code = ?, otp_expiry = ?, password_reset_pending = ?
            WHERE email = ?
        ");
        $stmt->bind_param("ssis", $otp, $otpExpiry, $pending, $email);
        return $stmt->execute();
    }

    /**
     * Validate an OTP used for password reset/change flows.
     */
    public function canUsePasswordOtp(string $email, string $otp): array {
        // Check that a password request is pending and its OTP is correct and unexpired.
        $stmt = $this->conn->prepare("
            SELECT * FROM users
            WHERE email = ? AND password_reset_pending = 1
        ");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if (!$result->num_rows) {
            return ['ok' => false, 'message' => 'No pending password reset request was found.'];
        }

        $user = $result->fetch_assoc();

        if (($user['otp_code'] ?? '') !== $otp) {
            return ['ok' => false, 'message' => 'Invalid OTP code.'];
        }

        if (empty($user['otp_expiry']) || strtotime($user['otp_expiry']) < time()) {
            return ['ok' => false, 'message' => 'OTP has expired.'];
        }

        return ['ok' => true, 'user' => $user];
    }

    /**
     * Update the stored password and clear temporary OTP flags.
     */
    public function updatePassword(string $email, string $passwordHash): bool {
        // Save the new password hash and clear the temporary reset code and status.
        $resetPending = 0;
        $stmt = $this->conn->prepare("
            UPDATE users
            SET password = ?, otp_code = NULL, otp_expiry = NULL, password_reset_pending = ?
            WHERE email = ?
        ");
        $stmt->bind_param("sis", $passwordHash, $resetPending, $email);
        return $stmt->execute();
    }

    /**
     * Return dashboard stats for the admin panel.
     */
    public function adminStats(): array {
        // Count student and coordinator accounts by their current status for the dashboard cards.
        // Start every dashboard count at zero so a failed query still has a safe display value.
        $stats = [
            'students' => 0,
            'students_active' => 0,
            'students_pending' => 0,
            'students_banned' => 0,
            'coordinators' => 0,
            'coordinators_approved' => 0,
            'coordinators_pending' => 0,
            'coordinators_declined' => 0
        ];

        // Each query counts one account group shown by the dashboard statistics.
        $queries = [
            'students' => "SELECT COUNT(*) AS total FROM users WHERE role = 'student'",
            'students_active' => "SELECT COUNT(*) AS total FROM users WHERE role = 'student' AND status = 'verified'",
            'students_pending' => "SELECT COUNT(*) AS total FROM users WHERE role = 'student' AND status = 'pending'",
            'students_banned' => "SELECT COUNT(*) AS total FROM users WHERE role = 'student' AND status = 'banned'",
            'coordinators' => "SELECT COUNT(*) AS total FROM users WHERE role = 'teacher' AND profile_completed = 1",
            'coordinators_approved' => "SELECT COUNT(*) AS total FROM users WHERE role = 'teacher' AND profile_completed = 1 AND COALESCE(NULLIF(teacher_approval_status, ''), 'approved') = 'approved'",
            'coordinators_pending' => "SELECT COUNT(*) AS total FROM users WHERE role = 'teacher' AND profile_completed = 1 AND teacher_approval_status = 'pending'",
            'coordinators_declined' => "SELECT COUNT(*) AS total FROM users WHERE role = 'teacher' AND profile_completed = 1 AND teacher_approval_status = 'declined'",
        ];

        foreach ($queries as $key => $query) {
            $result = $this->conn->query($query);
            if ($result) {
                $row = $result->fetch_assoc();
                $stats[$key] = (int) ($row['total'] ?? 0);
            }
        }

        return $stats;
    }

    /**
     * Get coordinator accounts for the admin dashboard.
     * Coordinators are stored with the teacher role in the current schema.
     */
    public function getManageableCoordinators(): array {
        // Return completed coordinator accounts for the administrator review table.
        $result = $this->conn->query(" 
            SELECT id, full_name, email, username, teacher_id, status, profile_completed,
                   teacher_approval_status, created_at
            FROM users
            WHERE role = 'teacher' AND profile_completed = 1
            ORDER BY created_at DESC
        ");

        return $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
    }

    /**
     * Approve or decline a completed coordinator account request.
     */
    public function reviewCoordinatorRequest(int $userId, string $decision): bool {
        // Approve or decline a pending coordinator account request.
        // Only the two displayed review choices may update a coordinator request.
        if ($decision === 'approve') {
            $stmt = $this->conn->prepare("
                UPDATE users
                SET teacher_approval_status = 'approved', teacher_approved_at = NOW(), teacher_declined_at = NULL
                WHERE id = ? AND role = 'teacher' AND status = 'verified'
                  AND profile_completed = 1 AND teacher_approval_status = 'pending'
            ");
        } elseif ($decision === 'decline') {
            $stmt = $this->conn->prepare("
                UPDATE users
                SET teacher_approval_status = 'declined', teacher_declined_at = NOW(), teacher_approved_at = NULL
                WHERE id = ? AND role = 'teacher' AND status = 'verified'
                  AND profile_completed = 1 AND teacher_approval_status = 'pending'
            ");
        } else {
            return false;
        }

        $stmt->bind_param('i', $userId);
        return $stmt->execute() && $stmt->affected_rows === 1;
    }

    /**
     * Get all student accounts for admin management.
     */
    public function getManageableUsers(): array {
        // Return student account details used by the admin user list.
        $result = $this->conn->query("
            SELECT id, full_name, email, username, student_id, year_level, section, role, status, created_at, profile_image
            FROM users
            WHERE role = 'student'
            ORDER BY created_at DESC
        ");

        return $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
    }


    /**
     * Get one student account by ID for admin editing.
     */
    public function getManageableUserById(int $userId): ?array {
        // Return one student account for the administrator edit form.
        $stmt = $this->conn->prepare("
            SELECT id, email, username, role, status, created_at
            FROM users
            WHERE id = ? AND role = 'student'
            LIMIT 1
        ");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result && $result->num_rows ? $result->fetch_assoc() : null;
    }

    /**
     * Update a student's status from the admin dashboard.
     */
    public function adminUpdateUser(int $userId, string $status): bool {
        // Change a student's account status from the administrator tools.
        $stmt = $this->conn->prepare("
            UPDATE users
            SET status = ?
            WHERE id = ? AND role = 'student'
        ");
        $stmt->bind_param("si", $status, $userId);
        return $stmt->execute();
    }

    /**
     * Delete a student account from the system.
     */
    public function adminDeleteUser(int $userId): bool {
        // Delete a student account selected by an administrator.
        $stmt = $this->conn->prepare("DELETE FROM users WHERE id = ? AND role = 'student'");
        $stmt->bind_param("i", $userId);
        return $stmt->execute();
    }
}



