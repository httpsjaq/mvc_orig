<?php
/**
 * Logged-in start page for changing the password.
 */
?>

<!-- This page starts the signed-in password change by requesting an OTP. -->
<div class="main-content profile-page">
    <div class="profile-container">
        <div class="profile-header">
            <div>
                <h1>Change Password</h1>
            </div>

            <a href="index.php?url=profile" class="edit-btn">
                <i class="bi bi-arrow-left"></i> Back to Profile
            </a>
        </div>

        <?php if (!empty($changeError)): ?>
            <div class="error-box"><?php echo e($changeError); ?></div>
        <?php endif; ?>

        <?php if (!empty($changeSuccess)): ?>
            <div class="success-box"><?php echo e($changeSuccess); ?></div>
        <?php endif; ?>

        <!-- Submitting this form asks the controller to send a code to the account email. -->
        <form method="POST">
            <div class="profile-section single-form-block">
                <h3>Password Verification</h3>
                <div class="info-grid">
                    <div class="info-item">
                        <label>Account Email</label>
                        <p><?php echo e($currentUser['email']); ?></p>
                    </div>
                    <div class="info-item">
                        <label>Security</label>
                        <p>An OTP will be sent to your email before you can set a new password.</p>
                    </div>
                </div>

                <div class="action-row">
                    <button type="submit" name="send_change_otp" class="edit-btn">
                        <i class="bi bi-envelope-fill"></i> Send OTP
                    </button>

                    <a href="index.php?url=profile" class="edit-btn">Cancel</a>
                </div>
            </div>
        </form>
    </div>
</div>
