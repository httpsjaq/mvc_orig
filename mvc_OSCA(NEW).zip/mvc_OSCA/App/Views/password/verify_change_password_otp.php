<?php
/**
 * Logged-in OTP verification view for password changes.
 */
?>

<!-- This page collects the OTP required before changing a signed-in user's password. -->
<div class="main-content profile-page">
    <div class="profile-container">
        <div class="profile-header">
            <div>
                <h1>Verify OTP</h1>
            </div>

            <a href="index.php?url=change_password" class="edit-btn">
                <i class="bi bi-arrow-left"></i> Back
            </a>
        </div>

        <?php if (!empty($changeError)): ?>
            <div class="error-box"><?php echo e($changeError); ?></div>
        <?php endif; ?>

        <?php if (!empty($changeSuccess)): ?>
            <div class="success-box"><?php echo e($changeSuccess); ?></div>
        <?php endif; ?>

        <!-- Submitting this form asks the controller to validate the six-digit code. -->
        <form method="POST">
            <div class="profile-section single-form-block">
                <h3>Enter OTP</h3>

                <div class="info-grid">
                    <div class="info-item">
                        <label>OTP Code</label>
                        <input type="text" name="otp" maxlength="6" placeholder="Enter 6-digit OTP" required>
                    </div>
                </div>

                <div class="action-row">
                    <button type="submit" name="verify_change_otp" class="edit-btn">
                        <i class="bi bi-check-circle-fill"></i> Verify OTP
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
