<?php
// This display value uses the full name when available and otherwise falls back to the account email.
$welcomeName = ($currentUser['full_name'] ?? $currentUser['email']) . '!';
?>
<!-- The home page combines a welcome panel with a compact account summary. -->
<div class="main-content home-page">
    <div class="dashboard-container">
        <?php if (!empty($messageError)): ?>
            <div class="alert-message error"><?php echo e($messageError); ?></div>
        <?php endif; ?>
        <?php if (!empty($messageSuccess)): ?>
            <div class="alert-message success"><?php echo e($messageSuccess); ?></div>
        <?php endif; ?>

        <section class="glass-hero">
            <div class="hero-text">
                <span class="welcome-tag">Overview</span>
                <h1>Welcome, <?php echo e($welcomeName); ?></h1>
                <p>Here's your account at a glance.</p>
                <a class="glass-btn" href="index.php?url=profile">View your profile</a>
            </div>

            <div class="floating-cube">
                <i class="bi bi-box-fill"></i>
            </div>
        </section>

        <!-- The snapshot displays the student's identifying and academic details. -->
        <section class="profile-section single-form-block">
            <h3>Account Snapshot</h3>
            <div class="info-grid">
                <div class="info-item">
                    <label>Student ID</label>
                    <p><?php echo e($currentUser['student_id'] ?? 'Not set'); ?></p>
                </div>
                <div class="info-item">
                    <label>Year Level</label>
                    <p><?php echo e($currentUser['year_level'] ?? 'Not set'); ?></p>
                </div>
                <div class="info-item">
                    <label>Section</label>
                    <p><?php echo e($currentUser['section'] ?? 'Not set'); ?></p>
                </div>
                <div class="info-item">
                    <label>Status</label>
                    <p><?php echo e(($currentUser['status'] ?? '') === 'verified' ? 'Active' : ucfirst((string) ($currentUser['status'] ?? 'unknown'))); ?></p>
                </div>
            </div>
        </section>
    </div>
</div>
