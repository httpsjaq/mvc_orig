<?php
/**
 * View for choosing a new password after forgot-password OTP verification.
 */
?>
<!-- The page explains password recovery and presents the new-password form. -->
<div class="auth-shell">
    <section class="auth-hero glass-panel">
        <span class="welcome-tag"><?php echo e($heroTag ?? 'Reset your password'); ?></span>
        <h1><?php echo e($heroTitle ?? 'Reset your password'); ?></h1>
        <p><?php echo e($heroDescription ?? 'Choose a strong new password to secure your account.'); ?></p>
    </section>

    <section class="auth-panel glass-panel">
        <div class="brand"><i class="bi bi-shield-lock-fill"></i> <?php echo e(APP_NAME); ?></div>
        <h2><?php echo e($formTitle ?? 'Reset your password'); ?></h2>
        <p class="auth-subtext">Create a new password to regain access to your account.</p>

        <?php if (!empty($messageError)): ?>
            <div class="error-box"><?php echo e($messageError); ?></div>
        <?php endif; ?>

        <?php if (!empty($messageSuccess)): ?>
            <div class="success-box"><?php echo e($messageSuccess); ?></div>
        <?php endif; ?>

        <!-- The two password fields must match before the controller saves the new password. -->
        <form method="POST" class="auth-form">
            <div class="field">
                <label>New Password</label>
                <div class="password-wrap"><input id="reset_password" type="password" name="password" placeholder="New password" required><button type="button" class="password-toggle" data-target="reset_password" aria-label="Show password"><i class="bi bi-eye-fill"></i></button></div>
            </div>

            <div class="field">
                <label>Confirm Password</label>
                <div class="password-wrap"><input id="reset_confirm_password" type="password" name="confirm_password" placeholder="Confirm password" required><button type="button" class="password-toggle" data-target="reset_confirm_password" aria-label="Show password"><i class="bi bi-eye-fill"></i></button></div>
            </div>

            <button class="glass-btn auth-submit" type="submit">Update Password <i class="bi bi-arrow-right"></i></button>
        </form>

        <div class="auth-links">
            <a href="login.php">Back to login</a>
        </div>
    </section>
</div>
