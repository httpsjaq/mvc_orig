<?php
/**
 * Login view. Processing happens in AuthController::login().
 */
?>
<!-- The sign-in panel collects the account credentials and shows controller messages. -->
<div class="auth-shell auth-shell-wide">
    <section class="auth-panel glass-panel">
        <div class="brand"><i class="bi bi-mortarboard-fill"></i> <?php echo e(APP_NAME); ?></div>
        <h2><?php echo e($formTitle ?? 'Login'); ?></h2>
        <p class="auth-subtext">Use your registered account to enter the dashboard.</p>

        <?php if (!empty($messageError)): ?>
            <div class="error-box"><?php echo e($messageError); ?></div>
        <?php endif; ?>

        <?php if (!empty($messageSuccess)): ?>
            <div class="success-box"><?php echo e($messageSuccess); ?></div>
        <?php endif; ?>

        <!-- This form sends the email, password, and optional reCAPTCHA response to the login controller. -->
        <form method="POST" class="auth-form">
            <div class="field">
                <label>Email</label>
                <input type="email" name="email" placeholder="Enter your email" required>
            </div>

            <div class="field">
                <label>Password</label>
                <div class="password-wrap"><input id="login_password" type="password" name="password" placeholder="Enter your password" required><button type="button" class="password-toggle" data-target="login_password" aria-label="Show password"><i class="bi bi-eye-fill"></i></button></div>
            </div>

            <?php if (!empty($showRecaptcha)): ?>
                <div class="captcha-wrap">
                    <div class="g-recaptcha" data-sitekey="<?php echo e(RECAPTCHA_SITE_KEY); ?>"></div>
                </div>
            <?php endif; ?>

            <button class="glass-btn auth-submit" type="submit">Login now <i class="bi bi-arrow-right"></i></button>
        </form>

        <!-- These links let visitors register or start password recovery. -->
        <div class="auth-links">
            <a href="register.php">Create account</a>
            <a href="forgot_password.php">Forgot password?</a>
        </div>
    </section>
</div>
