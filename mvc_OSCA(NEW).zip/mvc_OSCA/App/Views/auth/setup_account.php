<?php
/**
 * Post-verification profile setup view.
 */
// These defaults let the same template display student and coordinator profile setup.
$form = $formData ?? [];
$heroTag = $heroTag ?? 'Welcome';
$heroTitle = $heroTitle ?? 'Set up your account';
$heroDescription = $heroDescription ?? 'Complete your profile to get started.';
$currentEmail = $currentEmail ?? '';
$formTitle = $formTitle ?? 'Account setup';
$isCoordinator = ($accountRole ?? 'student') === 'teacher';
?>
<!-- The page shows the verified email and the fields needed to complete the profile. -->
<div class="auth-shell auth-shell-wide">
    <section class="auth-hero glass-panel">
        <span class="welcome-tag"><?php echo e($heroTag); ?></span>
        <h1><?php echo e($heroTitle); ?></h1>
        <p><?php echo e($heroDescription); ?></p>
        <div class="auth-email-pill">
            <i class="bi bi-person-vcard-fill"></i>
            <span><?php echo e($currentEmail); ?></span>
        </div>
    </section>

    <section class="auth-panel glass-panel">
        <div class="brand"><i class="bi bi-person-lines-fill"></i> <?php echo e(APP_NAME); ?></div>
        <h2><?php echo e($formTitle); ?></h2>
        <p class="auth-subtext">
            <?php echo $isCoordinator
                ? 'Complete your details. An admin must approve your Coordinator request before you can sign in.'
                : 'Fill in the details that will appear on your dashboard and profile.'; ?>
        </p>

        <?php if (!empty($messageError)): ?>
            <div class="error-box"><?php echo e($messageError); ?></div>
        <?php endif; ?>

        <?php if (!empty($messageSuccess)): ?>
            <div class="success-box"><?php echo e($messageSuccess); ?></div>
        <?php endif; ?>

        <!-- The form collects shared name details before showing fields specific to the account role. -->
        <form method="POST" class="auth-form">
            <div class="field-grid field-grid-3">
                <div class="field">
                    <label>First Name</label>
                    <input type="text" name="first_name" value="<?php echo e($form['first_name'] ?? ''); ?>" placeholder="First Name" required>
                </div>

                <div class="field">
                    <label>Middle Initial</label>
                    <input type="text" name="middle_initial" value="<?php echo e($form['middle_initial'] ?? ''); ?>" maxlength="1" placeholder="M.I.">
                </div>

                <div class="field">
                    <label>Last Name</label>
                    <input type="text" name="last_name" value="<?php echo e($form['last_name'] ?? ''); ?>" placeholder="Last Name" required>
                </div>
            </div>

            <div class="field-grid field-grid-2">
                <div class="field">
                    <label>Suffix</label>
                    <select name="suffix">
                        <option value="">Select Suffix</option>
                        <?php foreach (['Jr.','Sr.','II','III','IV'] as $suffixOption): ?>
                            <option value="<?php echo e($suffixOption); ?>" <?php echo (($form['suffix'] ?? '') === $suffixOption) ? 'selected' : ''; ?>><?php echo e($suffixOption); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="field">
                    <label>Username</label>
                    <input type="text" name="username" value="<?php echo e($form['username'] ?? ''); ?>" placeholder="Username" required>
                </div>
            </div>

            <!-- Coordinator accounts need a coordinator ID, while student accounts need student academic details. -->
            <?php if ($isCoordinator): ?>
                <div class="field">
                    <label>Coordinator ID</label>
                    <input type="text" name="teacher_id" value="<?php echo e($form['teacher_id'] ?? ''); ?>" placeholder="Coordinator ID" required>
                </div>
            <?php else: ?>
            <div class="field-grid field-grid-2">
                <div class="field">
                    <label>Student ID</label>
                    <input type="text" name="student_id" value="<?php echo e($form['student_id'] ?? ''); ?>" placeholder="Student ID" required>
                </div>

                <div class="field">
                    <label>Section</label>
                    <input type="text" name="section" value="<?php echo e($form['section'] ?? ''); ?>" placeholder="Section" required>
                </div>
            </div>

            <div class="field">
                <label>Year Level</label>
                <select name="year_level" required>
                    <option value="">Select Year Level</option>
                    <?php foreach (['1st Year','2nd Year','3rd Year','4th Year'] as $year): ?>
                        <option value="<?php echo e($year); ?>" <?php echo (($form['year_level'] ?? '') === $year) ? 'selected' : ''; ?>><?php echo e($year); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php endif; ?>

            <button class="glass-btn auth-submit" type="submit">
                <?php echo $isCoordinator ? 'Submit for approval' : 'Complete setup'; ?> <i class="bi bi-arrow-right"></i>
            </button>
        </form>
    </section>
</div>
