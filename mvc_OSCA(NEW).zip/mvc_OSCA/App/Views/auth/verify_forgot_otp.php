<?php
/**
 * View for verifying an OTP during forgot-password flow.
 */
?>
<!-- The page displays the recovery email and explains the OTP check. -->
<div class="auth-shell">
    <section class="auth-hero glass-panel">
        <span class="welcome-tag"><?php echo e($heroTag ?? 'Verify your identity'); ?></span>
        <h1><?php echo e($heroTitle ?? 'Verify your identity'); ?></h1>
        <p><?php echo e($heroDescription ?? 'Enter the OTP sent to your email address.'); ?></p>
        <div class="auth-email-pill">
            <i class="bi bi-envelope-paper-fill"></i>
            <span><?php echo e($currentEmail ?? ''); ?></span>
        </div>
    </section>

    <section class="auth-panel glass-panel">
        <div class="brand"><i class="bi bi-key-fill"></i> <?php echo e(APP_NAME); ?></div>
        <h2><?php echo e($formTitle ?? 'Verify OTP'); ?></h2>
        <p class="auth-subtext">Enter the OTP we sent before choosing a new password.</p>

        <?php if (!empty($messageError)): ?>
            <div class="error-box"><?php echo e($messageError); ?></div>
        <?php endif; ?>

        <?php if (!empty($messageSuccess)): ?>
            <div class="success-box"><?php echo e($messageSuccess); ?></div>
        <?php endif; ?>

        <!-- This form submits the six-digit recovery code for validation. -->
        <form method="POST" class="auth-form">
            <div class="field">
                <label>OTP Code</label>
                <input type="text" name="otp" placeholder="Enter 6-digit OTP" maxlength="6" required>
            </div>

            <button class="glass-btn auth-submit" type="submit">Verify OTP <i class="bi bi-arrow-right"></i></button>
        </form>

        <!-- The links allow a fresh code to be sent or let the visitor return to recovery. -->
        <div class="auth-links">
            <a href="verify_forgot_otp.php?resend=1">Resend OTP</a>
            <a href="forgot_password.php">Back</a>
        </div>
    </section>
</div>
