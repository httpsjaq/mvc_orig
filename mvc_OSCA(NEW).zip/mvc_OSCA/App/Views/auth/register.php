<?php
/**
 * Register view. Processing happens in AuthController::register().
 */
?>
<!-- The page explains the signup steps and presents the registration form. -->
<div class="auth-shell">
    <section class="auth-hero glass-panel">
        <span class="welcome-tag"><?php echo e($heroTag ?? 'Create your account'); ?></span>
        <h1><?php echo e($heroTitle ?? 'Create your account'); ?></h1>
        <p><?php echo e($heroDescription ?? 'Create your account and get started with the quiz.'); ?></p>

        <!-- These cards explain email verification and the profile step that follows. -->
        <div class="auth-stat-grid">
            <div class="auth-stat-card">
                <i class="bi bi-envelope-check-fill"></i>
                <strong>Email first</strong>
                <span>We verify your account before profile setup.</span>
            </div>
            <div class="auth-stat-card">
                <i class="bi bi-person-badge-fill"></i>
                <strong>Student ready</strong>
                <span>Complete your student details after OTP verification.</span>
            </div>
        </div>
    </section>

    <section class="auth-panel glass-panel">
        <div class="brand"><i class="bi bi-person-plus-fill"></i> <?php echo e(APP_NAME); ?></div>
        <h2><?php echo e($formTitle ?? 'Create your account'); ?></h2>
        <p class="auth-subtext">Start with your email and password. You will finish the rest after OTP verification.</p>

        <?php if (!empty($messageError)): ?>
            <div class="error-box"><?php echo e($messageError); ?></div>
        <?php endif; ?>

        <?php if (!empty($messageSuccess)): ?>
            <div class="success-box"><?php echo e($messageSuccess); ?></div>
        <?php endif; ?>

        <!-- This form collects the account type, email, and password before email verification. -->
        <form method="POST" class="auth-form">
            <div class="field">
                <label for="account_type">Account type</label>
                <select id="account_type" name="account_type" required>
                    <option value="student">Student</option>
                    <option value="teacher">Coordinator</option>
                </select>
            </div>

            <div class="field">
                <label>Email</label>
                <input type="email" name="email" placeholder="Enter your email" required>
            </div>

            <div class="field">
                <label>Password</label>
                <div class="password-wrap"><input id="register_password" type="password" name="password" placeholder="Create a password" required><button type="button" class="password-toggle" data-target="register_password" aria-label="Show password"><i class="bi bi-eye-fill"></i></button></div>
            </div>

            <div class="field">
                <label>Confirm Password</label>
                <div class="password-wrap"><input id="register_confirm_password" type="password" name="confirm_password" placeholder="Confirm your password" required><button type="button" class="password-toggle" data-target="register_confirm_password" aria-label="Show password"><i class="bi bi-eye-fill"></i></button></div>
            </div>

            <?php if (!empty($showRecaptcha)): ?>
                <div class="captcha-wrap">
                    <div class="g-recaptcha" data-sitekey="<?php echo e(RECAPTCHA_SITE_KEY); ?>"></div>
                </div>
            <?php endif; ?>

            <button class="glass-btn auth-submit" type="submit">Register now <i class="bi bi-arrow-right"></i></button>
        </form>

        <div class="auth-links">
            <a href="login.php">Already have an account?</a>
        </div>
    </section>
</div>
