<?php
/**
 * Edit profile view.
 */
// These values select the correct account fields and image source for the edit form.
$isCoordinator = ($currentUser['role'] ?? '') === 'teacher';
$profileImage = (string) ($currentUser['profile_image'] ?? 'default.png');
$profileImageUrl = $profileImage !== '' && $profileImage !== 'default.png'
    ? 'uploads/profiles/' . rawurlencode(basename($profileImage))
    : 'dist/img/default-150x150.png';
?>

<div class="main-content profile-page">
    <div class="profile-container">
        <div class="profile-header">
            <div>
                <h1>Edit Profile</h1>
            </div>

            <a href="index.php?url=profile" class="edit-btn">
                <i class="bi bi-arrow-left"></i> Back to Profile
            </a>
        </div>

        <?php if (!empty($editError)): ?>
            <div class="error-box"><?php echo e($editError); ?></div>
        <?php endif; ?>

        <?php if (!empty($editSuccess)): ?>
            <div class="success-box"><?php echo e($editSuccess); ?></div>
        <?php endif; ?>

        <!-- The form sends profile fields and an optional image file to the profile controller. -->
        <form method="POST" enctype="multipart/form-data">
            <div class="profile-section single-form-block">
                <!-- The photo control accepts supported image formats and keeps the current photo when left empty. -->
                <h3>Profile Photo</h3>
                <div class="info-item" style="margin-bottom: 1rem;">
                    <img src="<?php echo e($profileImageUrl); ?>" alt="Current profile photo" class="img-circle elevation-2" style="width: 96px; height: 96px; object-fit: cover; display: block; margin-bottom: .75rem;">
                    <label for="profile_image">Choose a photo</label>
                    <input id="profile_image" type="file" name="profile_image" accept="image/jpeg,image/png,image/webp,.jpg,.jpeg,.png,.webp">
                    <small>JPG, PNG, or WebP; maximum 5 MB. Leave empty to keep the current photo.</small>
                </div>

                <!-- These fields collect the user's name, username, and role-specific ID. -->
                <h3>Account Information</h3>

                <div class="info-grid">
                    <div class="info-item">
                        <label>First Name</label>
                        <input type="text" name="first_name" value="<?php echo e($currentUser['first_name'] ?? ''); ?>" required>
                    </div>

                    <div class="info-item">
                        <label>Middle Initial</label>
                        <input type="text" name="middle_initial" value="<?php echo e($currentUser['middle_initial'] ?? ''); ?>" maxlength="1">
                    </div>

                    <div class="info-item">
                        <label>Last Name</label>
                        <input type="text" name="last_name" value="<?php echo e($currentUser['last_name'] ?? ''); ?>" required>
                    </div>

                    <div class="info-item">
                        <label>Suffix</label>
                        <select name="suffix">
                            <option value="">Select Suffix</option>
                            <?php foreach (['Jr.','Sr.','II','III','IV'] as $suffixOption): ?>
                                <option value="<?php echo e($suffixOption); ?>" <?php echo (($currentUser['suffix'] ?? '') === $suffixOption) ? 'selected' : ''; ?>>
                                    <?php echo e($suffixOption); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="info-item">
                        <label>Username</label>
                        <input type="text" name="username" value="<?php echo e($currentUser['username'] ?? ''); ?>" required>
                    </div>

                    <div class="info-item">
                        <label><?php echo $isCoordinator ? 'Coordinator ID' : 'Student ID'; ?></label>
                        <input type="text" name="<?php echo $isCoordinator ? 'teacher_id' : 'student_id'; ?>" value="<?php echo e($isCoordinator ? ($currentUser['teacher_id'] ?? '') : ($currentUser['student_id'] ?? '')); ?>" required>
                    </div>
                </div>

                <hr class="inner-divider">

                <!-- Students can edit their year and section; coordinators see an explanatory note instead. -->
                <h3>Academic Information</h3>

                <?php if (!$isCoordinator): ?>
                <div class="info-grid">
                    <div class="info-item">
                        <label>Year Level</label>
                        <select name="year_level" required>
                            <option value="">Select Year Level</option>
                            <?php foreach (['1st Year','2nd Year','3rd Year','4th Year'] as $year): ?>
                                <option value="<?php echo e($year); ?>" <?php echo (($currentUser['year_level'] ?? '') === $year) ? 'selected' : ''; ?>>
                                    <?php echo e($year); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="info-item">
                        <label>Section</label>
                        <input type="text" name="section" value="<?php echo e($currentUser['section'] ?? ''); ?>" required>
                    </div>
                </div>
                <?php else: ?>
                    <p class="profile-readonly-note">Coordinator accounts do not have student year or section details.</p>
                <?php endif; ?>

                <div class="action-row">
                    <button type="submit" class="edit-btn">
                        <i class="bi bi-save2-fill"></i> Save Changes
                    </button>

                    <a href="index.php?url=profile" class="edit-btn">Cancel</a>
                </div>
            </div>
        </form>
    </div>
</div>
