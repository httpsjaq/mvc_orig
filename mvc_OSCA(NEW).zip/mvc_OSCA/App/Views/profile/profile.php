<?php
/**
 * Profile display view.
 */
// These display values provide readable fallbacks for missing profile fields.
$fullName = !empty($currentUser['full_name']) ? $currentUser['full_name'] : 'No Name';
$isCoordinator = ($currentUser['role'] ?? '') === 'teacher';
$identityId = $isCoordinator ? ($currentUser['teacher_id'] ?? '') : ($currentUser['student_id'] ?? '');
$identityId = $identityId !== '' ? $identityId : (string) $currentUser['id'];
$username = !empty($currentUser['username']) ? $currentUser['username'] : 'No Username';
$statusText = (($currentUser['status'] ?? '') === 'verified') ? 'Active' : ucfirst((string) ($currentUser['status'] ?? 'unknown'));
$dateCreated = !empty($currentUser['created_at']) ? date('Y-m-d', strtotime($currentUser['created_at'])) : 'N/A';
$profileImage = (string) ($currentUser['profile_image'] ?? 'default.png');
$profileImageUrl = $profileImage !== '' && $profileImage !== 'default.png'
    ? 'uploads/profiles/' . rawurlencode(basename($profileImage))
    : 'dist/img/default-150x150.png';
?>
<!-- The profile page groups account, academic, and system information for the signed-in user. -->
<div class="main-content profile-page">
    <div class="profile-container">
        <div class="profile-header">
            <div class="profile-title-row">
                <img src="<?php echo e($profileImageUrl); ?>" alt="Profile photo" class="img-circle elevation-2" style="width: 88px; height: 88px; object-fit: cover;">
                <h1><?php echo e($fullName); ?></h1>
                <span class="profile-role-badge"><?php echo e($currentUser['academic_role'] ?? ($isCoordinator ? 'Coordinator' : 'Student')); ?></span>
            </div>

            <a href="index.php?url=edit_profile" class="edit-btn">
                <i class="bi bi-pencil-square"></i> Edit Profile
            </a>
        </div>

        <?php if (!empty($changeSuccess)): ?>
            <div class="success-box"><?php echo e($changeSuccess); ?></div>
        <?php endif; ?>

        <div class="profile-section">
            <!-- This section shows the user's identifiers, email, username, and status. -->
            <h3>Account Information</h3>

            <div class="info-grid">
                <div class="info-item"><label><?php echo $isCoordinator ? 'Coordinator ID' : 'Student ID'; ?></label><p><?php echo e($identityId); ?></p></div>
                <div class="info-item"><label>Username</label><p><?php echo e($username); ?></p></div>
                <div class="info-item"><label>Email</label><p><?php echo e($currentUser['email'] ?? 'No Email'); ?></p></div>
                <div class="info-item"><label>Status</label><p><?php echo e($statusText); ?></p></div>
            </div>
        </div>

        <div class="profile-section">
            <!-- This section shows the academic details available for the current account. -->
            <h3>Academic Information</h3>

            <div class="info-grid">
                <div class="info-item"><label>Year</label><p><?php echo e($currentUser['year_level'] ?? 'Not Set'); ?></p></div>
                <div class="info-item"><label>Section</label><p><?php echo e($currentUser['section'] ?? 'Not Set'); ?></p></div>
                <div class="info-item"><label>Role</label><p><?php echo e($currentUser['academic_role'] ?? 'Student'); ?></p></div>
            </div>
        </div>

        <div class="profile-section">
            <!-- This section shows when the account was created. -->
            <h3>System Information</h3>

            <div class="info-grid">
                <div class="info-item"><label>Date Created</label><p><?php echo e($dateCreated); ?></p></div>
            </div>
        </div>
    </div>
</div>
