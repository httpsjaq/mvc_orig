<?php
/** AdminLTE application shell; page views are rendered after the sidebar. */
$title = ($pageTitle ?? APP_NAME) . ' - ' . APP_NAME;
?>
<!DOCTYPE html>
<!-- Shared authenticated page shell: load styles, show the account bar, then let the sidebar open the content area. -->
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php echo e($title); ?></title>
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <link rel="stylesheet" href="bootstrap-5.0.2/bootstrap-5.0.2-dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <link rel="stylesheet" href="css/app.css">
  <link rel="stylesheet" href="css/adminlte-app.css">
  <!-- Calendar-only styles are loaded only on the practice schedule page. -->
  <?php if (($section ?? '') === 'schedule'): ?>
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@calendarjs/ce/dist/style.min.css">
  <?php endif; ?>
</head>
<body class="hold-transition sidebar-mini layout-fixed app-body">
<div class="wrapper">
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <ul class="navbar-nav"><li class="nav-item"><a class="nav-link" data-widget="pushmenu" href="#" role="button" aria-label="Toggle navigation"><i class="fas fa-bars"></i></a></li></ul>
    <span class="navbar-text d-none d-sm-inline"><?php echo e(APP_NAME); ?></span>
    <ul class="navbar-nav ms-auto">
      <li class="nav-item dropdown">
        <a class="nav-link" data-bs-toggle="dropdown" href="#" aria-expanded="false"><i class="far fa-user"></i> <?php echo e($currentUser['full_name'] ?? $currentUser['username'] ?? $currentUser['email'] ?? 'Account'); ?></a>
        <div class="dropdown-menu dropdown-menu-right"><a class="dropdown-item" href="<?php echo ($currentUser['role'] ?? '') === 'admin' ? 'index.php?url=admin_dashboard' : 'index.php?url=profile'; ?>"><i class="fas fa-id-card mr-2"></i> <?php echo ($currentUser['role'] ?? '') === 'admin' ? 'Dashboard' : 'My profile'; ?></a><div class="dropdown-divider"></div><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt mr-2"></i> Logout</a></div>
      </li>
    </ul>
  </nav>


