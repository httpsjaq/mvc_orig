  </div></section>
  <footer class="main-footer"><strong><?php echo e(APP_NAME); ?></strong><div class="float-right d-none d-sm-inline-block">Student and activity management</div></footer>
</div>
</div>
<!-- Shared browser libraries and interactions are loaded after the page content. -->
<script src="plugins/jquery/jquery.min.js"></script>
<script src="bootstrap-5.0.2/bootstrap-5.0.2-dist/js/bootstrap.bundle.min.js"></script>
<script src="dist/js/adminlte.min.js"></script>
<script src="js/script.js"></script>
<!-- Calendar libraries are needed only when the coordinator opens the schedule page. -->
<?php if (($section ?? '') === 'schedule'): ?>
<script src="https://cdn.jsdelivr.net/npm/lemonadejs/dist/lemonade.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@calendarjs/ce/dist/index.min.js"></script>
<script src="js/practice-calendar.js"></script>
<?php endif; ?>
</body>
</html>
