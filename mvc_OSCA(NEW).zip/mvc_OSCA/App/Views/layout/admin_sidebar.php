<?php
/** Admin-only navigation shell, matching the shared AdminLTE layout. */
$currentUser = isset($currentUser) && is_array($currentUser) ? $currentUser : [];
// Reuse the normal role-aware navigation inside the AdminLTE application shell.
include __DIR__ . '/sidebar.php';
