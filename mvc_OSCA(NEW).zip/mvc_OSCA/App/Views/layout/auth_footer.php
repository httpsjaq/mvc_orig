<!-- Load the shared form and password-toggle interactions before closing the page. -->
<script src="bootstrap-5.0.2/bootstrap-5.0.2-dist/js/bootstrap.bundle.min.js"></script>
<script src="js/script.js"></script>
</body>
</html>
