<?php
// Prepare the current page, role, and display name used by the navigation.
$user = isset($currentUser) && is_array($currentUser) ? $currentUser : [];
$activePage = $_GET['url'] ?? 'home';
$isAdmin = ($user['role'] ?? '') === 'admin';
$displayName = $user['full_name'] ?? $user['username'] ?? $user['email'] ?? 'User';
$navLink = static function (string $page, string $label, string $icon) use ($activePage): void {
    // Build one link and mark it active when it matches the current page.
    $active = $activePage === $page || ($page === 'admin_dashboard' && $activePage === 'admin_edit_user');
    echo '<li class="nav-item"><a class="nav-link' . ($active ? ' active' : '') . '" href="index.php?url=' . e($page) . '"><i class="nav-icon ' . e($icon) . '"></i><p>' . e($label) . '</p></a></li>';
};
?>
<!-- Role-aware navigation shows only the tools available to this account type. -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">
  <a href="index.php?url=home" class="brand-link"><img src="dist/img/AdminLTELogo.png" alt="OSCA" class="brand-image img-circle elevation-3"><span class="brand-text font-weight-light">OSCA Portal</span></a>
  <div class="sidebar">
    <?php $sidebarImage = (string) ($user['profile_image'] ?? 'default.png'); ?>
    <?php $sidebarImageUrl = $sidebarImage !== '' && $sidebarImage !== 'default.png' ? 'uploads/profiles/' . rawurlencode(basename($sidebarImage)) : 'dist/img/default-150x150.png'; ?>
    <div class="user-panel mt-3 pb-3 mb-3 d-flex"><div class="image"><img src="<?php echo e($sidebarImageUrl); ?>" class="img-circle elevation-2" alt="User" style="width: 34px; height: 34px; object-fit: cover;"></div><div class="info"><span class="d-block text-white"><?php echo e($displayName); ?></span><small class="text-muted"><?php echo e(ucfirst($user['role'] ?? 'user')); ?></small></div></div>
    <nav class="mt-2"><ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
      <!-- The menu links change by role; the same helper marks the active page. -->
      <?php if ($isAdmin): ?>
        <?php $navLink('admin_dashboard', 'Dashboard', 'fas fa-tachometer-alt'); ?>
        <li class="nav-header">MANAGEMENT</li>
        <?php $navLink('admin_students', 'Students', 'fas fa-user-graduate'); ?>
        <?php $navLink('admin_courses', 'Courses', 'fas fa-book'); ?>
        <?php $navLink('admin_users', 'Users', 'fas fa-users'); ?>
      <?php elseif (($user['role'] ?? '') === 'teacher'): ?>
        <?php $navLink('home', 'Dashboard', 'fas fa-tachometer-alt'); ?>
        <li class="nav-header">COORDINATOR</li>
        <?php $navLink('athletes', 'Athletes', 'fas fa-running'); ?>
        <?php $navLink('sports', 'Sports Categories', 'fas fa-trophy'); ?>
        <?php $navLink('dance', 'Dance Troupe', 'fas fa-music'); ?>
        <?php $navLink('schedule', 'Practice Schedule', 'far fa-calendar-alt'); ?>
        <?php $navLink('reports', 'Reports', 'fas fa-chart-bar'); ?>
        <li class="nav-header">ACCOUNT</li>
        <?php $navLink('profile', 'Profile', 'fas fa-user-circle'); ?>
        <?php $navLink('edit_profile', 'Update Details', 'fas fa-user-edit'); ?>
        <?php $navLink('change_password', 'Change Password', 'fas fa-key'); ?>
      <?php else: ?>
        <?php $navLink('home', 'Home', 'fas fa-home'); ?>
        <?php $navLink('profile', 'Profile', 'fas fa-user-circle'); ?>
        <?php $navLink('edit_profile', 'Update Details', 'fas fa-user-edit'); ?>
        <?php $navLink('change_password', 'Change Password', 'fas fa-key'); ?>
      <?php endif; ?>
      <li class="nav-header">SESSION</li><li class="nav-item"><a class="nav-link" href="logout.php"><i class="nav-icon fas fa-sign-out-alt"></i><p>Logout</p></a></li>
    </ul></nav>
  </div>
</aside>
<!-- The shared page title and content container surround each authenticated view. -->
<div class="content-wrapper">
  <section class="content-header"><div class="container-fluid"><div class="row mb-2"><div class="col-sm-6"><h1><?php echo e($pageTitle ?? 'Dashboard'); ?></h1></div></div></div></section>
  <section class="content"><div class="container-fluid">
