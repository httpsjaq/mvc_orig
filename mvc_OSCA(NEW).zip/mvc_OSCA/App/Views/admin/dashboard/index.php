<?php
/**
 * Admin dashboard view.
 * Admin is intentionally not listed in the user table to avoid accidental edits.
 */
?>
<div class="main-content home-page admin-dashboard">
    <div class="dashboard-container">
        <!-- The hero introduces the administrator's dashboard and its main purpose. -->
        <section class="glass-hero">
            <div class="hero-text">
                <span class="welcome-tag">Admin Dashboard</span>
                <h1>Welcome, Admin!</h1>
                <p>Manage student accounts and review Coordinator requests.</p>
            </div>

            <div class="floating-cube">
                <i class="bi bi-shield-lock-fill"></i>
            </div>
        </section>

        <?php if (!empty($adminError)): ?>
            <div class="error-box"><?php echo e($adminError); ?></div>
        <?php endif; ?>

        <?php if (!empty($adminSuccess)): ?>
            <div class="success-box"><?php echo e($adminSuccess); ?></div>
        <?php endif; ?>

        <!-- These cards summarize student account totals by status. -->
        <h2>Student Statistics</h2>
        <section class="stats-grid">
            <?php foreach ([
                'Students' => ['students', 'bi-people-fill'],
                'Active Students' => ['students_active', 'bi-person-check-fill'],
                'Pending Students' => ['students_pending', 'bi-clock-history'],
                'Banned Students' => ['students_banned', 'bi-slash-circle-fill']
            ] as $label => [$key, $icon]): ?>
                <div class="glass-card">
                    <i class="bi <?php echo e($icon); ?>"></i>
                    <h3><?php echo e($label); ?></h3>
                    <div class="stat-number"><?php echo e((string) ($stats[$key] ?? 0)); ?></div>
                </div>
            <?php endforeach; ?>
        </section>

        <!-- These cards summarize completed coordinator requests by approval status. -->
        <h2>Coordinator Statistics</h2>
        <section class="stats-grid">
            <?php foreach ([
                'Coordinators' => ['coordinators', 'bi-person-badge-fill'],
                'Approved Coordinators' => ['coordinators_approved', 'bi-person-check-fill'],
                'Pending Approval' => ['coordinators_pending', 'bi-clock-history'],
                'Declined Requests' => ['coordinators_declined', 'bi-slash-circle-fill']
            ] as $label => [$key, $icon]): ?>
                <div class="glass-card">
                    <i class="bi <?php echo e($icon); ?>"></i>
                    <h3><?php echo e($label); ?></h3>
                    <div class="stat-number"><?php echo e((string) ($stats[$key] ?? 0)); ?></div>
                </div>
            <?php endforeach; ?>
        </section>

        <!-- This table lists student accounts and provides edit and delete actions. -->
        <section id="student-management" class="profile-section single-form-block">
            <h3>Student Management</h3>

            <?php if (empty($users)): ?>
                <p>No students found.</p>
            <?php else: ?>
                <div style="overflow-x:auto;">
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>Photo</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Username</th>
                                <th>Student ID</th>
                                <th>Year / Section</th>
                                <th>Status</th>
                                <th>Created</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                                <?php foreach ($users as $userRow): ?>
                                <tr>
                                    <?php $userPhoto = (string) ($userRow['profile_image'] ?? 'default.png'); $userPhotoUrl = $userPhoto !== '' && $userPhoto !== 'default.png' ? 'uploads/profiles/' . rawurlencode(basename($userPhoto)) : 'dist/img/default-150x150.png'; ?>
                                    <td><img src="<?php echo e($userPhotoUrl); ?>" alt="" class="img-circle elevation-2" style="width:38px; height:38px; object-fit:cover;"></td>
                                    <td><?php echo e($userRow['full_name'] ?: 'N/A'); ?></td>
                                    <td><?php echo e($userRow['email']); ?></td>
                                    <td><?php echo e($userRow['username'] ?: 'N/A'); ?></td>
                                    <td><?php echo e($userRow['student_id'] ?: 'N/A'); ?></td>
                                    <td><?php echo e(trim(($userRow['year_level'] ?? '') . ' / ' . ($userRow['section'] ?? ''), ' /') ?: 'N/A'); ?></td>
                                    <td><?php echo e($userRow['status'] === 'verified' ? 'Active' : ucfirst($userRow['status'])); ?></td>
                                    <td><?php echo e(date('Y-m-d', strtotime($userRow['created_at']))); ?></td>
                                    <td>
                                        <div class="admin-action-row">
                                            <a href="index.php?url=admin_edit_user&id=<?php echo (int) $userRow['id']; ?>" class="edit-btn">
                                                <i class="bi bi-pencil-square"></i> Edit
                                            </a>

                                            <form method="POST" onsubmit="return confirm('Delete this user?');">
                                                <input type="hidden" name="user_id" value="<?php echo (int) $userRow['id']; ?>">
                                                <button type="submit" name="delete_user" class="edit-btn danger-btn" style="border:none; cursor:pointer;">
                                                    <i class="bi bi-trash-fill"></i> Delete
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </section>

        <section class="profile-section single-form-block">
            <!-- This table shows coordinator requests and offers approval controls for pending requests. -->
            <h3>Coordinator Accounts</h3>

            <?php if (empty($coordinators)): ?>
                <p>No completed Coordinator requests yet.</p>
            <?php else: ?>
                <div style="overflow-x:auto;">
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Coordinator ID</th>
                                <th>Approval</th>
                                <th>Created</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($coordinators as $coordinator): ?>
                                <tr>
                                    <td><?php echo e($coordinator['full_name'] ?: $coordinator['username'] ?: 'N/A'); ?></td>
                                    <td><?php echo e($coordinator['email']); ?></td>
                                    <td><?php echo e($coordinator['teacher_id'] ?: 'N/A'); ?></td>
                                    <td><?php echo e(ucwords(str_replace('_', ' ', $coordinator['teacher_approval_status'] ?: 'approved'))); ?></td>
                                    <td><?php echo e(date('Y-m-d', strtotime($coordinator['created_at']))); ?></td>
                                    <td>
                                        <?php if (($coordinator['teacher_approval_status'] ?? '') === 'pending'): ?>
                                            <div class="admin-action-row">
                                                <form method="POST" onsubmit="return confirm('Approve this Coordinator account?');">
                                                    <input type="hidden" name="user_id" value="<?php echo (int) $coordinator['id']; ?>">
                                                    <button type="submit" name="review_coordinator" value="approve" class="edit-btn">Approve</button>
                                                </form>
                                                <form method="POST" onsubmit="return confirm('Decline this Coordinator account?');">
                                                    <input type="hidden" name="user_id" value="<?php echo (int) $coordinator['id']; ?>">
                                                    <button type="submit" name="review_coordinator" value="decline" class="edit-btn danger-btn">Decline</button>
                                                </form>
                                            </div>
                                        <?php else: ?>
                                            —
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </section>

        <!-- This read-only table shows activity roster records entered by coordinators. -->
        <section id="coordinator-roster" class="profile-section single-form-block">
            <?php $rosterStudents = $rosterStudents ?? []; ?>
            <h3>Coordinator Student Roster (<?php echo count($rosterStudents); ?>)</h3>
            <?php if (empty($rosterStudents)): ?>
                <p>No roster records yet. Students added by a Coordinator will appear here.</p>
            <?php else: ?>
                <div style="overflow-x:auto;">
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>Photo</th>
                                <th>Student ID</th>
                                <th>Name</th>
                                <th>Course / Program</th>
                                <th>Year Level</th>
                                <th>Enrollment Year</th>
                                <th>Sport</th>
                                <th>Jersey</th>
                                <th>Dance Troupe</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($rosterStudents as $student): ?>
                                <tr>
                                    <?php $studentPhoto = (string) ($student['profile_image'] ?? 'default.png'); $studentPhotoUrl = $studentPhoto !== '' && $studentPhoto !== 'default.png' ? 'uploads/profiles/' . rawurlencode(basename($studentPhoto)) : 'dist/img/default-150x150.png'; ?>
                                    <td><img src="<?php echo e($studentPhotoUrl); ?>" alt="" class="img-circle elevation-2" style="width:38px; height:38px; object-fit:cover;"></td>
                                    <td><?php echo e($student['student_id']); ?></td>
                                    <td><?php echo e($student['full_name']); ?></td>
                                    <td><?php echo e($student['course'] ?: '—'); ?></td>
                                    <td><?php echo e($student['year_level'] ?: '—'); ?></td>
                                    <td><?php echo e($student['enrollment_year'] ?: '—'); ?></td>
                                    <td><?php echo e($student['sport_name'] ?: '—'); ?></td>
                                    <td><?php echo e($student['jersey_number'] ?: '—'); ?></td>
                                    <td><?php echo !empty($student['dance_member']) ? 'Member' : '—'; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </section>
    </div>
</div>



