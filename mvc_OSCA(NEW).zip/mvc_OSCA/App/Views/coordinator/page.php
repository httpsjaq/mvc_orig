<?php
// These values choose the coordinator page, title, and photo shown for the current request.
$section = $section ?? 'home';
$sports = $sports ?? [];
$selectedStudent = $selectedStudent ?? null;
$titles = [
    'home' => 'Dashboard',
    'athletes' => 'Athletes',
    'dance' => 'Dance Troupe',
    'sports' => 'Sports Categories',
    'schedule' => 'Practice Schedule',
    'reports' => 'Reports'
];
$title = $titles[$section] ?? 'Dashboard';
$studentPhoto = (string) ($selectedStudent['profile_image'] ?? 'default.png');
$studentPhotoUrl = $studentPhoto !== '' && $studentPhoto !== 'default.png'
    ? 'uploads/profiles/' . rawurlencode(basename($studentPhoto))
    : 'dist/img/default-150x150.png';
?>
<!-- The coordinator workspace changes its content according to the selected section. -->
<main class="main-content coordinator-page">
  <div class="coordinator-container">
    <header class="page-heading">
      <div>
        <span class="welcome-tag">Coordinator workspace</span>
        <h1><?php echo e($title); ?></h1>
        <p>Manage student activities and practice details in one place.</p>
      </div>
    </header>

    <?php if ($notice !== ''): ?>
      <div class="<?php echo str_starts_with($notice, 'Saved') ? 'success-box' : 'error-box'; ?>" role="status"><?php echo e($notice); ?></div>
    <?php endif; ?>

    <!-- When a student is selected, show the profile summary and its edit form. -->
    <?php if ($selectedStudent): ?>
      <section class="simple-panel student-profile">
        <div style="display:flex; align-items:center; gap:1rem;"><img src="<?php echo e($studentPhotoUrl); ?>" alt="Student profile photo" class="img-circle elevation-2" style="width:80px; height:80px; object-fit:cover;"><div><span class="welcome-tag">Student profile</span><h2><?php echo e($selectedStudent['full_name']); ?></h2></div></div>
        <div class="simple-grid">
          <div><small>Student ID</small><strong><?php echo e($selectedStudent['student_id']); ?></strong></div>
          <div><small>Course / Program</small><strong><?php echo e($selectedStudent['course'] ?: '—'); ?></strong></div>
          <div><small>Year level</small><strong><?php echo e($selectedStudent['year_level'] ?: '—'); ?></strong></div>
          <div><small>Enrollment year</small><strong><?php echo e($selectedStudent['enrollment_year'] ?: '—'); ?></strong></div>
          <div><small>Sport</small><strong><?php echo e($selectedStudent['sport_name'] ?: '—'); ?></strong></div>
          <div><small>Jersey number</small><strong><?php echo e($selectedStudent['jersey_number'] ?: '—'); ?></strong></div>
          <div><small>Dance troupe</small><strong><?php echo !empty($selectedStudent['dance_member']) ? 'Member' : 'No'; ?></strong></div>
        </div>
        <details class="add-record" style="margin-top: 1.25rem;">
          <summary>Edit student profile</summary>
          <form method="post" enctype="multipart/form-data" action="index.php?url=<?php echo e($section); ?>&amp;student=<?php echo (int) $selectedStudent['id']; ?>" class="simple-form">
            <input type="hidden" name="roster_id" value="<?php echo (int) $selectedStudent['id']; ?>">
            <label>Student ID<input name="student_id" value="<?php echo e($selectedStudent['student_id']); ?>" required></label>
            <label>Student name<input name="full_name" value="<?php echo e($selectedStudent['full_name']); ?>" required></label>
            <label>Course / Program<select name="course"><option value="">Select a course</option><?php foreach (($courses ?? []) as $courseRow): ?><option value="<?php echo e($courseRow['title']); ?>" <?php echo (($selectedStudent['course'] ?? '') === $courseRow['title']) ? 'selected' : ''; ?>><?php echo e($courseRow['title']); ?></option><?php endforeach; ?></select></label>
            <label>Year level<input name="year_level" value="<?php echo e($selectedStudent['year_level'] ?? ''); ?>"></label>
            <label>Enrollment year<input name="enrollment_year" inputmode="numeric" value="<?php echo e($selectedStudent['enrollment_year'] ?? ''); ?>"></label>
            <label>Jersey number<input name="jersey_number" value="<?php echo e($selectedStudent['jersey_number'] ?? ''); ?>"></label>
            <label>Sport<select name="sport_id"><option value="">No sport</option><?php foreach ($sports as $sportRow): ?><option value="<?php echo (int) $sportRow['id']; ?>" <?php echo ((int) ($selectedStudent['sport_id'] ?? 0) === (int) $sportRow['id']) ? 'selected' : ''; ?>><?php echo e($sportRow['name']); ?></option><?php endforeach; ?></select></label>
            <label>Profile photo<input type="file" name="profile_image" accept="image/jpeg,image/png,image/webp,.jpg,.jpeg,.png,.webp"><small>JPG, PNG, or WebP; maximum 5 MB. Leave empty to keep the current photo.</small></label>
            <label class="check-field"><input type="checkbox" name="dance_member" value="1" <?php echo !empty($selectedStudent['dance_member']) ? 'checked' : ''; ?>> Dance troupe member</label>
            <button class="primary-button" name="update_student" value="1">Save student profile</button>
          </form>
        </details>
        <a class="text-link" href="index.php?url=<?php echo e($section); ?>">Back to students</a>
      </section>
    <!-- The home branch shows summary counts, shortcut links, and upcoming practices. -->
    <?php elseif ($section === 'home'): ?>
      <section class="coordinator-stats">
        <?php foreach ([
            ['Athletes', 'athletes', 'bi-trophy', 'athletes'],
            ['Dance troupe', 'dance', 'bi-music-note-beamed', 'dance'],
            ['Sports', 'sports', 'bi-dribbble', 'sports'],
            ['Upcoming practices', 'practices', 'bi-calendar-event', 'schedule']
        ] as [$label, $key, $icon, $link]): ?>
          <a class="stat-tile" href="index.php?url=<?php echo e($link); ?>">
            <span class="stat-icon"><i class="bi <?php echo e($icon); ?>"></i></span>
            <span><small><?php echo e($label); ?></small><strong><?php echo (int) ($stats[$key] ?? 0); ?></strong></span>
          </a>
        <?php endforeach; ?>
      </section>

      <section class="simple-panel">
        <div class="panel-heading"><div><h2>Quick access</h2><p>Go straight to a coordinator task.</p></div></div>
        <div class="quick-links">
          <a href="index.php?url=athletes"><i class="bi bi-people"></i><span><strong>Athletes</strong><small>Browse students and profiles</small></span></a>
          <a href="index.php?url=sports"><i class="bi bi-dribbble"></i><span><strong>Sports categories</strong><small>View available sports</small></span></a>
          <a href="index.php?url=dance"><i class="bi bi-music-note-beamed"></i><span><strong>Dance troupe</strong><small>Browse members</small></span></a>
          <a href="index.php?url=schedule"><i class="bi bi-calendar3"></i><span><strong>Practice schedule</strong><small>Add or review practices</small></span></a>
          <a href="index.php?url=reports"><i class="bi bi-file-earmark-bar-graph"></i><span><strong>Reports</strong><small>Review student records</small></span></a>
        </div>
      </section>

      <section class="simple-panel">
        <div class="panel-heading"><div><h2>Upcoming practices</h2><p>Next scheduled team sessions.</p></div><a class="text-link" href="index.php?url=schedule">View schedule</a></div>
        <?php $showCancel = false; include __DIR__ . '/schedule_table.php'; ?>
      </section>
    <!-- The sports branch lets coordinators add and browse sports categories. -->
    <?php elseif ($section === 'sports'): ?>
      <section class="simple-panel">
        <div class="panel-heading"><div><h2>Sports categories</h2><p>Select a sport to view its athletes.</p></div></div>
        <form method="post" class="inline-form">
          <label for="sport_name">Add a sport</label>
          <input id="sport_name" name="sport_name" placeholder="e.g. Basketball" required>
          <button class="primary-button" name="add_sport" value="1">Add sport</button>
        </form>
        <div class="category-list">
          <?php if (!$sports): ?><p class="empty-state">No sports have been added yet.</p><?php endif; ?>
          <?php foreach ($sports as $sportRow): ?>
            <a href="index.php?url=athletes&amp;sport=<?php echo (int) $sportRow['id']; ?>"><i class="bi bi-dribbble"></i><?php echo e($sportRow['name']); ?><span>View athletes →</span></a>
          <?php endforeach; ?>
        </div>
      </section>
    <!-- The schedule branch prepares calendar events from database rows. -->
    <?php elseif ($section === 'schedule'): ?>
      <?php
      $calendarEvents = [];
      foreach (($schedules ?? []) as $practice) {
          $groupType = (string) ($practice['group_type'] ?? 'Sport');
          $calendarEvents[] = [
              'guid' => 'practice-' . (int) ($practice['id'] ?? 0),
              'title' => (string) ($practice['group_name'] ?? ''),
              'date' => substr((string) ($practice['practice_date'] ?? ''), 0, 10),
              'start' => substr((string) ($practice['practice_time'] ?? ''), 0, 5),
              'location' => (string) ($practice['location'] ?? ''),
              'description' => $groupType,
              'color' => $groupType === 'Dance Troupe' ? '#8056a8' : '#287a68',
              'readonly' => true
          ];
      }
      ?>
      <section class="simple-panel">
        <!-- This form collects all fields needed to save a new practice. -->
        <div class="panel-heading"><div><h2>Add a practice</h2><p>Set the group, date, time, and location.</p></div></div>
        <form method="post" class="simple-form">
          <label>Group type<select name="group_type"><option>Sport</option><option>Dance Troupe</option></select></label>
          <label>Sport / team name<input name="group_name" required placeholder="e.g. Basketball"></label>
          <label>Date<input type="date" name="practice_date" required></label>
          <label>Time<input type="time" name="practice_time" required></label>
          <label class="wide-field">Location<input name="location" required placeholder="Practice venue"></label>
          <button class="primary-button" name="add_schedule" value="1">Save practice</button>
        </form>
      </section>
      <section class="simple-panel">
        <div class="panel-heading"><div><h2>Practice calendar</h2><p>Choose a date to move the weekly schedule and fill in the practice form.</p></div></div>
        <script type="application/json" id="practice-calendar-data"><?php echo json_encode($calendarEvents, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE) ?: '[]'; ?></script>
        <!-- The calendar picker and weekly calendar share the selected practice date. -->
        <div class="practice-calendar-layout">
          <aside class="practice-calendar-picker">
            <h3>Choose a date</h3>
            <div id="practice-calendar" aria-label="Choose a practice date"></div>
            <p class="calendar-help">Selecting a date updates the form and the weekly view.</p>
          </aside>
          <div class="practice-calendar-week">
            <div id="practice-schedule" aria-label="Weekly practice schedule"></div>
          </div>
        </div>
      </section>
      <section class="simple-panel">
        <div class="panel-heading"><div><h2>Practice timeline</h2><p>Upcoming practices in date order.</p></div></div>
        <!-- The timeline provides a date-ordered view of upcoming practices. -->
        <div id="practice-timeline" aria-label="Upcoming practice timeline"></div>
      </section>
      <section class="simple-panel">
        <div class="panel-heading"><div><h2>Manage upcoming practices</h2><p>Cancel a practice if plans change.</p></div></div>
        <?php $showCancel = true; include __DIR__ . '/schedule_table.php'; ?>
      </section>
    <?php else: ?>
      <!-- The student and report branches provide roster lists, filters, and add-record controls. -->
      <?php if (in_array($section, ['athletes', 'dance'], true)): ?>
        <section class="simple-panel">
          <details class="add-record">
            <summary>Add a student record</summary>
            <form method="post" class="simple-form">
              <label>Student ID<input name="student_id" required></label>
              <label>Student name<input name="full_name" required></label>
              <label>Course / Program<select name="course"><option value="">Select a course</option><?php foreach (($courses ?? []) as $courseRow): ?><option value="<?php echo e($courseRow['title']); ?>"><?php echo e($courseRow['title']); ?></option><?php endforeach; ?></select></label>
              <label>Year level<input name="year_level"></label>
              <label>Enrollment year<input name="enrollment_year" inputmode="numeric" placeholder="2026"></label>
              <label>Jersey number<input name="jersey_number"></label>
              <label>Sport<select name="sport_id"><option value="">No sport</option><?php foreach ($sports as $sportRow): ?><option value="<?php echo (int) $sportRow['id']; ?>"><?php echo e($sportRow['name']); ?></option><?php endforeach; ?></select></label>
              <label class="check-field"><input type="checkbox" name="dance_member" value="1"> Dance troupe member</label>
              <button class="primary-button" name="add_student" value="1">Save student</button>
            </form>
          </details>
        </section>
      <?php endif; ?>

      <section class="simple-panel">
        <div class="panel-heading">
          <div>
            <h2><?php echo e($section === 'dance' ? 'Dance troupe members' : ($section === 'reports' ? 'Student report' : 'Student athletes')); ?></h2>
          </div>
          <?php if ($section === 'reports'): ?><button class="secondary-button" type="button" onclick="window.print()">Print report</button><?php endif; ?>
        </div>
        <?php $years = array_unique(array_filter(array_column($students, 'enrollment_year'))); ?>
        <!-- These filters narrow the student list by search term, sport, and enrollment year. -->
        <form method="get" class="filter-form">
          <input type="hidden" name="url" value="<?php echo e($section); ?>">
          <label>Search<input name="q" value="<?php echo e($_GET['q'] ?? ''); ?>" placeholder="Name, student ID, jersey"></label>
          <label>Sport<select name="sport"><option value="">All sports</option><?php foreach ($sports as $sportRow): ?><option value="<?php echo (int) $sportRow['id']; ?>" <?php echo (($_GET['sport'] ?? '') == $sportRow['id']) ? 'selected' : ''; ?>><?php echo e($sportRow['name']); ?></option><?php endforeach; ?></select></label>
          <label>Enrollment year<input name="year" value="<?php echo e($_GET['year'] ?? ''); ?>" placeholder="All years"></label>
          <button class="secondary-button">Apply filters</button>
        </form>
        <div class="table-wrap">
          <!-- The roster table displays matching student details and links to each student's profile. -->
          <table class="simple-table">
            <thead><tr><th>Photo</th><th>Student</th><th>Student ID</th><th>Course</th><th>Year</th><th>Sport</th><th>Jersey</th><th>Dance</th></tr></thead>
            <tbody>
              <?php if (!$students): ?><tr><td colspan="8" class="empty-state">No matching student records. Add a student record to get started.</td></tr><?php endif; ?>
              <?php foreach ($students as $row): ?>
                <tr>
                  <?php $photo = (string) ($row['profile_image'] ?? 'default.png'); $photoUrl = $photo !== '' && $photo !== 'default.png' ? 'uploads/profiles/' . rawurlencode(basename($photo)) : 'dist/img/default-150x150.png'; ?>
                  <td><img src="<?php echo e($photoUrl); ?>" alt="" class="img-circle elevation-2" style="width:38px; height:38px; object-fit:cover;"></td>
                  <td><a class="student-name" href="index.php?url=<?php echo e($section); ?>&amp;student=<?php echo (int) $row['id']; ?>"><?php echo e($row['full_name']); ?></a></td>
                  <td><?php echo e($row['student_id']); ?></td><td><?php echo e($row['course'] ?: '—'); ?></td>
                  <td><?php echo e($row['enrollment_year'] ?: '—'); ?></td><td><?php echo e($row['sport_name'] ?: '—'); ?></td>
                  <td><?php echo e($row['jersey_number'] ?: '—'); ?></td><td><?php echo !empty($row['dance_member']) ? 'Member' : '—'; ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </section>
    <?php endif; ?>
  </div>
</main>
