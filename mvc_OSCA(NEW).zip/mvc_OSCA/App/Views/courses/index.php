<!-- The course list defaults to an empty array so the view can safely render no results. -->
<?php $courses = $courses ?? []; ?>
<!-- The page contains the course catalog table and the shared add/edit dialog. -->
<div class="course-page">
  <section class="content-header">
    <div class="container-fluid"><h1>Course Management</h1></div>
  </section>
  <section class="content">
    <div class="container-fluid">
      <?php if (!empty($courseError)): ?><div class="alert alert-danger" role="alert"><?php echo e($courseError); ?></div><?php endif; ?>
      <?php if (!empty($courseSuccess)): ?><div class="alert alert-success" role="status"><?php echo e($courseSuccess); ?></div><?php endif; ?>
      <div class="card card-primary card-outline">
        <div class="card-header">
          <h3 class="card-title">Courses</h3>
          <div class="card-tools"><button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#course-modal" data-course-id="0" data-course-title=""><i class="fas fa-plus"></i> New Course</button></div>
        </div>
        <div class="card-body table-responsive">
          <!-- The table displays course names, timestamps, and edit or delete actions. -->
          <table class="table table-bordered table-striped table-hover">
            <thead><tr><th>Title</th><th>Created</th><th>Last updated</th><th class="text-center">Actions</th></tr></thead>
            <tbody>
              <?php if (!$courses): ?><tr><td colspan="4" class="text-center text-muted">No courses have been added.</td></tr><?php endif; ?>
              <?php foreach ($courses as $course): ?>
                <tr>
                  <td><?php echo e($course['title']); ?></td>
                  <td><?php echo e($course['created']); ?></td>
                  <td><?php echo e($course['modified']); ?></td>
                  <td class="text-center text-nowrap">
                    <button type="button" class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#course-modal" data-course-id="<?php echo (int) $course['id']; ?>" data-course-title="<?php echo e($course['title']); ?>"><i class="fas fa-edit"></i> Edit</button>
                    <form method="post" class="d-inline" onsubmit="return confirm('Delete this course?');">
                      <input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?php echo (int) $course['id']; ?>">
                      <button class="btn btn-sm btn-outline-danger" type="submit"><i class="fas fa-trash"></i> Delete</button>
                    </form>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </section>
</div>
<!-- The dialog is reused for both adding a course and editing an existing one. -->
<div class="modal fade" id="course-modal" tabindex="-1" role="dialog" aria-labelledby="course-modal-title" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <form method="post" class="modal-content">
      <div class="modal-header"><h5 class="modal-title" id="course-modal-title">Add Course</h5><button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>
      <div class="modal-body"><label for="course-title">Title</label><input type="text" class="form-control" id="course-title" name="title" maxlength="55" required></div>
      <div class="modal-footer"><input type="hidden" name="action" value="save"><input type="hidden" name="id" id="course-id" value="0"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-primary">Save Course</button></div>
    </form>
  </div>
</div>
<!-- This listener fills the course dialog using values stored on the button that opened it. -->
<script>
document.getElementById('course-modal').addEventListener('show.bs.modal', function (event) {
  const button = event.relatedTarget;
  const id = button.getAttribute('data-course-id') || '0';
  document.getElementById('course-id').value = id;
  document.getElementById('course-title').value = button.getAttribute('data-course-title') || '';
  document.getElementById('course-modal-title').textContent = id === '0' ? 'Add Course' : 'Edit Course';
});
</script>

