<?php
/** JSON API helpers and admin authorization for template-style API modules. */
require_once __DIR__ . '/../Core/Controller.php';

abstract class ApiBaseController extends Controller {
    protected function requireAdminApi(): array {

        // Confirm the signed-in account is a verified administrator before allowing an API change.
        // Check the session first, then confirm the database still marks this account as a verified admin.

        if (empty($_SESSION['email'])) {
            $this->respond(['status' => 'error', 'message' => 'Authentication required.'], 401);
        }
        $user = $this->userModel->findByEmail((string) $_SESSION['email']);
        if (!$user || ($user['status'] ?? '') !== 'verified' || ($user['role'] ?? '') !== 'admin') {
            $this->respond(['status' => 'error', 'message' => 'Administrator access required.'], 403);
        }
        return $user;
    }

    protected function requestData(): array {

        // Read request fields from JSON when sent that way, or from a normal HTML form otherwise.
        // JSON callers send a raw request body; browser forms are available through $_POST.
        
        $contentType = $_SERVER['CONTENT_TYPE'] ?? '';
        if (stripos($contentType, 'application/json') !== false) {
            $decoded = json_decode((string) file_get_contents('php://input'), true);
            return is_array($decoded) ? $decoded : [];
        }
        return $_POST;
    }

    protected function respond(array $payload, int $statusCode = 200): void {
        // Send a JSON response with its HTTP status, then stop so no extra page output is added.
        http_response_code($statusCode);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
        exit;
    }
}
