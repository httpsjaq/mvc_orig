<?php
require_once __DIR__ . '/../ApiBaseController.php';
require_once __DIR__ . '/../../Models/coordinator/StudentRoster.php';

// Provides JSON actions for reading and maintaining the student activity roster.
class StudentsApiController extends ApiBaseController {
    public function dispatch(string $action, int $id = 0): void {
        
        // Match the requested student action to a roster operation and return its result as JSON.
        // Keep the administrator record because new roster entries record who created them.

        $admin = $this->requireAdminApi();
        $roster = new StudentRoster();
        try {
            if ($action === 'all' && $_SERVER['REQUEST_METHOD'] === 'GET') {
                $this->respond(['data' => $roster->all()]);
            }
            if ($action === 'edit' && $_SERVER['REQUEST_METHOD'] === 'GET') {
                $student = $roster->student($id);
                $student ? $this->respond($student) : $this->respond(['status' => 'error', 'message' => 'Student not found.'], 404);
            }
            if (in_array($action, ['add', 'edit'], true) && $_SERVER['REQUEST_METHOD'] === 'POST') {
                $data = $this->requestData();

                // Normalize submitted form fields into the shape expected by the roster model.
                
                $student = [
                    'student_id' => trim($data['student_id'] ?? ''),
                    'full_name' => trim($data['full_name'] ?? ''),
                    'course' => trim($data['course'] ?? ''),
                    'year_level' => trim($data['year_level'] ?? ''),
                    'enrollment_year' => trim($data['enrollment_year'] ?? ''),
                    'jersey_number' => trim($data['jersey_number'] ?? ''),
                    'sport_id' => $data['sport_id'] ?? '',
                    'dance_member' => !empty($data['dance_member']) ? '1' : ''
                ];
                if ($student['student_id'] === '' || $student['full_name'] === '') {
                    $this->respond(['status' => 'error', 'message' => 'Student ID and full name are required.'], 422);
                }
                $recordId = $id ?: (int) ($data['id'] ?? 0);
                $saved = $recordId > 0
                    ? $roster->update($recordId, $student)
                    : $roster->add($student, (int) $admin['id']);
                $saved ? $this->respond(['status' => 'success', 'message' => $recordId ? 'Student updated successfully.' : 'Student added successfully.'])
                    : $this->respond(['status' => 'error', 'message' => 'Unable to save student.'], 400);
            }
            if ($action === 'delete' && in_array($_SERVER['REQUEST_METHOD'], ['POST', 'DELETE'], true)) {
                $data = $this->requestData();
                $recordId = $id ?: (int) ($data['id'] ?? 0);
                $recordId > 0 && $roster->deactivate($recordId)
                    ? $this->respond(['status' => 'success', 'message' => 'Student removed from the active roster.'])
                    : $this->respond(['status' => 'error', 'message' => 'Unable to remove student.'], 400);
            }
            $this->respond(['status' => 'error', 'message' => 'Unsupported student API action or HTTP method.'], 405);
        } catch (Throwable $exception) {
            $this->respond(['status' => 'error', 'message' => 'Student request failed.'], 500);
        }
    }
}
