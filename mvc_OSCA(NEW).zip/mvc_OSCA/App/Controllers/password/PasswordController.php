<?php
/**
 * Handles both public password recovery and logged-in password changes.
 */
require_once __DIR__ . '/../../Core/Controller.php';

class PasswordController extends Controller {
    /**
     * Forgot-password request page.
     */
    public function forgotPassword(): void {
        // Start a public password recovery request and send an OTP when the email belongs to an account.
        $this->requireGuest();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = trim($_POST['email'] ?? '');

            if ($email === '') {
                flash_set('auth_error', 'Please enter your email.');
                redirect('forgot_password.php');
            }

            $captcha = verify_recaptcha_token($_POST['g-recaptcha-response'] ?? null);
            if (!$captcha['ok']) {
                flash_set('auth_error', $captcha['message']);
                redirect('forgot_password.php');
            }

            // Keep the response general to avoid revealing whether an email has an account.
            $user = $this->userModel->findByEmail($email);

            if ($user) {
                $otp = random_otp();
                $otpExpiry = otp_expiry_time();
                $this->userModel->beginPasswordReset($email, $otp, $otpExpiry);
                send_otp_email($email, $otp, 'Password Reset OTP', 'Your password reset code is');
                $_SESSION['forgot_email'] = $email;
            }

            flash_set('auth_success', 'If the email exists, an OTP has been sent.');
            redirect('verify_forgot_otp.php');
        }

        $this->renderAuth('auth/forgot_password', [
            'pageTitle' => 'Forgot Password',
            'heroTag' => 'Password Recovery',
            'heroTitle' => 'Recover your account',
            'heroDescription' => 'Request an OTP and reset your password securely.',
            'formTitle' => 'Forgot password',
            'messageError' => flash_get('auth_error'),
            'messageSuccess' => flash_get('auth_success'),
            'showRecaptcha' => recaptcha_enabled()
        ]);
    }

    /**
     * Verify the OTP for a public forgot-password request.
     */
    public function verifyForgotOtp(): void {
        // Check the password-recovery OTP and allow a verified request to continue to reset.
        $this->requireGuest();

        $email = $_SESSION['forgot_email'] ?? '';
        if ($email === '') {
            redirect('forgot_password.php');
        }

        if (isset($_GET['resend'])) {
            $otp = random_otp();
            $otpExpiry = otp_expiry_time();
            $this->userModel->beginPasswordReset($email, $otp, $otpExpiry);
            $mail = send_otp_email($email, $otp, 'Password Reset OTP', 'Your password reset code is');
            flash_set($mail['ok'] ? 'auth_success' : 'auth_error', $mail['ok'] ? 'New OTP sent.' : 'Failed to send OTP.');
            redirect('verify_forgot_otp.php');
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $otp = trim($_POST['otp'] ?? '');
            $check = $this->userModel->canUsePasswordOtp($email, $otp);

            if (!$check['ok']) {
                flash_set('auth_error', $check['message']);
                redirect('verify_forgot_otp.php');
            }

            $_SESSION['forgot_verified'] = true;
            redirect('reset_password.php');
        }

        $this->renderAuth('auth/verify_forgot_otp', [
            'pageTitle' => 'Verify Reset OTP',
            'heroTag' => 'Security Check',
            'heroTitle' => 'Verify your reset code',
            'heroDescription' => 'Enter the OTP sent to your email to continue.',
            'formTitle' => 'Verify OTP',
            'currentEmail' => $email,
            'messageError' => flash_get('auth_error'),
            'messageSuccess' => flash_get('auth_success'),
            'showRecaptcha' => false
        ]);
    }

    /**
     * Public page to save a new password after forgot-password OTP verification.
     */
    public function resetPassword(): void {
        // Save a new password only after the recovery OTP has been verified.
        $this->requireGuest();

        $email = $_SESSION['forgot_email'] ?? '';
        if ($email === '' || empty($_SESSION['forgot_verified'])) {
            redirect('forgot_password.php');
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $password = $_POST['password'] ?? '';
            $confirm = $_POST['confirm_password'] ?? '';

            if ($password === '' || $confirm === '') {
                flash_set('auth_error', 'Please fill in both password fields.');
                redirect('reset_password.php');
            }

            if ($password !== $confirm) {
                flash_set('auth_error', 'Passwords do not match.');
                redirect('reset_password.php');
            }

            // Store only a one-way password hash, never the submitted plain-text password.
            $passwordHash = password_hash($password, PASSWORD_DEFAULT);

            if (!$this->userModel->updatePassword($email, $passwordHash)) {
                flash_set('auth_error', 'Failed to reset password.');
                redirect('reset_password.php');
            }

            unset($_SESSION['forgot_email'], $_SESSION['forgot_verified']);
            flash_set('auth_success', 'Password reset successful. You can now log in.');
            redirect('login.php');
        }

        $this->renderAuth('auth/reset_password', [
            'pageTitle' => 'Reset Password',
            'heroTag' => 'New Password',
            'heroTitle' => 'Choose a new password',
            'heroDescription' => 'Set a new password for your account and return to login.',
            'formTitle' => 'Reset password',
            'messageError' => flash_get('auth_error'),
            'messageSuccess' => flash_get('auth_success'),
            'showRecaptcha' => false
        ]);
    }

    /**
     * Logged-in page that starts a password change by sending an OTP.
     */
    public function changePassword(): void {
        // Start a signed-in password change by sending an OTP to the current account email.
        $currentUser = $this->requireUser();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $otp = random_otp();
            $otpExpiry = otp_expiry_time();

            if (!$this->userModel->beginPasswordReset($currentUser['email'], $otp, $otpExpiry)) {
                flash_set('change_error', 'Failed to start password change.');
                redirect('index.php?url=change_password');
            }

            $mail = send_otp_email($currentUser['email'], $otp, 'Change Password OTP', 'Your change-password code is');

            flash_set($mail['ok'] ? 'change_success' : 'change_error', $mail['ok'] ? 'OTP sent to your email.' : 'Failed to send OTP.');
            if ($mail['ok']) {
                redirect('index.php?url=verify_change_password_otp');
            }

            redirect('index.php?url=change_password');
        }

        $this->renderApp('password/change_password', [
            'pageTitle' => 'Change Password',
            'currentUser' => $currentUser,
            'changeError' => flash_get('change_error'),
            'changeSuccess' => flash_get('change_success')
        ]);
    }

    /**
     * Logged-in page that checks the OTP for password changes.
     */
    public function verifyChangePasswordOtp(): void {
        // Check the signed-in user's OTP before allowing the password to be changed.
        $currentUser = $this->requireUser();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $otp = trim($_POST['otp'] ?? '');
            $check = $this->userModel->canUsePasswordOtp($currentUser['email'], $otp);

            if (!$check['ok']) {
                flash_set('change_error', $check['message']);
                redirect('index.php?url=verify_change_password_otp');
            }

            $_SESSION['change_password_verified'] = true;
            redirect('index.php?url=set_new_password');
        }

        $this->renderApp('password/verify_change_password_otp', [
            'pageTitle' => 'Verify Change OTP',
            'currentUser' => $currentUser,
            'changeError' => flash_get('change_error')
        ]);
    }

    /**
     * Logged-in page that stores the new password after OTP verification.
     */
    public function setNewPassword(): void {
        // Save the replacement password after the signed-in OTP check succeeds.
        $currentUser = $this->requireUser();

        if (empty($_SESSION['change_password_verified'])) {
            redirect('index.php?url=change_password');
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $password = $_POST['password'] ?? '';
            $confirm = $_POST['confirm_password'] ?? '';

            if ($password === '' || $confirm === '') {
                flash_set('change_error', 'Please fill in both password fields.');
                redirect('index.php?url=set_new_password');
            }

            if ($password !== $confirm) {
                flash_set('change_error', 'Passwords do not match.');
                redirect('index.php?url=set_new_password');
            }

            $passwordHash = password_hash($password, PASSWORD_DEFAULT);

            if (!$this->userModel->updatePassword($currentUser['email'], $passwordHash)) {
                flash_set('change_error', 'Failed to update password.');
                redirect('index.php?url=set_new_password');
            }

            unset($_SESSION['change_password_verified']);
            flash_set('change_success', 'Password changed successfully.');
            redirect('index.php?url=profile');
        }

        $this->renderApp('password/set_new_password', [
            'pageTitle' => 'Set New Password',
            'currentUser' => $currentUser,
            'changeError' => flash_get('change_error')
        ]);
    }
}
