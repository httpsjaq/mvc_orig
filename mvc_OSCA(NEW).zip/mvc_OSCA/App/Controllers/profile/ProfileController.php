<?php
/**
 * Handles profile display and profile editing for logged-in users.
 */
require_once __DIR__ . '/../../Core/Controller.php';

class ProfileController extends Controller {
    /**
     * Display the current user's profile.
     */
    public function show(): void {
        // Load and display the profile belonging to the signed-in user.
        $currentUser = $this->requireUser();

        $this->renderApp('profile/profile', [
            'pageTitle' => 'Profile',
            'currentUser' => $currentUser,
            'changeSuccess' => flash_get('change_success')
        ]);
    }

    /**
     * Render and process the edit profile form.
     */
    public function edit(): void {
        // Validate profile fields and an optional photo, save changes, and show the result.
        $currentUser = $this->requireUser();
        $error = null;
        $success = null;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $imageError = $this->validateProfileImage($_FILES['profile_image'] ?? null);
            // Gather submitted identity and academic fields for validation and saving.
            $formData = [
                'first_name' => trim($_POST['first_name'] ?? ''),
                'middle_initial' => trim($_POST['middle_initial'] ?? ''),
                'last_name' => trim($_POST['last_name'] ?? ''),
                'suffix' => trim($_POST['suffix'] ?? ''),
                'username' => trim($_POST['username'] ?? ''),
                'teacher_id' => trim($_POST['teacher_id'] ?? ''),
                'student_id' => trim($_POST['student_id'] ?? ''),
                'year_level' => trim($_POST['year_level'] ?? ''),
                'section' => trim($_POST['section'] ?? '')
            ];

            $isCoordinator = ($currentUser['role'] ?? '') === 'teacher';
            $missingFields =
                $formData['first_name'] === '' ||
                $formData['last_name'] === '' ||
                $formData['username'] === '' ||
                ($isCoordinator
                    ? $formData['teacher_id'] === ''
                    : ($formData['student_id'] === '' || $formData['year_level'] === '' || $formData['section'] === ''));

            if ($imageError !== null) {
                $error = $imageError;
            } elseif ($missingFields) {
                $error = 'Please fill in all required fields.';
            } elseif (
                $isCoordinator
                    ? $this->userModel->coordinatorIdentityExists($formData['username'], $formData['teacher_id'], (int) $currentUser['id'])
                    : $this->userModel->profileIdentityExists($formData['username'], $formData['student_id'], (int) $currentUser['id'])
            ) {
                $error = $isCoordinator ? 'Username or Coordinator ID already exists.' : 'Username or Student ID already exists.';
            } else {
                $formData['middle_initial'] = $formData['middle_initial'] !== '' ? strtoupper(substr($formData['middle_initial'], 0, 1)) : null;

                if ($this->userModel->updateProfile((int) $currentUser['id'], $formData)) {
                    // Save the photo only after the text fields have been accepted.
                    $imageFile = $_FILES['profile_image'] ?? null;
                    $hasNewImage = is_array($imageFile) && ($imageFile['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_OK;
                    if ($hasNewImage) {
                        $newFilename = $this->storeProfileImage($imageFile);
                        if ($newFilename === null) {
                            $error = 'Could not save the profile photo. Check that the uploads folder is writable.';
                        } elseif (!$this->userModel->updateProfileImage((int) $currentUser['id'], $newFilename)) {
                            @unlink($this->profileImagePath($newFilename));
                            $error = 'Could not save the profile photo to your account.';
                        } else {
                            $oldFilename = (string) ($currentUser['profile_image'] ?? '');
                            if ($oldFilename !== '' && $oldFilename !== 'default.png' && basename($oldFilename) === $oldFilename) {
                                @unlink($this->profileImagePath($oldFilename));
                            }
                        }
                    }
                    $currentUser = $this->userModel->findById((int) $currentUser['id']);
                    if ($error === null) {
                        $success = 'Profile updated successfully.';
                    }
                } else {
                    $error = 'Failed to update profile.';
                }
            }
        }

        $this->renderApp('profile/edit_profile', [
            'pageTitle' => 'Edit Profile',
            'currentUser' => $currentUser,
            'editError' => $error,
            'editSuccess' => $success
        ]);
    }

    /** Check the upload before storing it; only common raster image formats are allowed. */
    private function validateProfileImage(?array $file): ?string {
        // Check upload status, size, and actual image format before accepting a profile photo.
        if ($file === null || ($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
            return null;
        }
        if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            return 'The profile photo upload failed. Please try again.';
        }
        if (($file['size'] ?? 0) > 5 * 1024 * 1024 || !is_uploaded_file($file['tmp_name'] ?? '')) {
            return 'Choose an image smaller than 5 MB.';
        }

        $imageInfo = @getimagesize($file['tmp_name']);
        $mime = $imageInfo['mime'] ?? '';
        if (!in_array($mime, ['image/jpeg', 'image/png', 'image/webp'], true)) {
            return 'Use a JPG, PNG, or WebP image.';
        }
        return null;
    }

    /** Store the image under a generated name so user filenames are never trusted. */
    private function storeProfileImage(array $file): ?string {
        // Save an accepted profile image under a random filename and return that filename.
        $imageInfo = @getimagesize($file['tmp_name']);
        $extensions = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
        $extension = $extensions[$imageInfo['mime'] ?? ''] ?? null;
        if ($extension === null) {
            return null;
        }

        $filename = bin2hex(random_bytes(16)) . '.' . $extension;
        $directory = dirname(__DIR__, 3) . '/public/uploads/profiles';
        if (!is_dir($directory) && !mkdir($directory, 0755, true) && !is_dir($directory)) {
            return null;
        }
        return move_uploaded_file($file['tmp_name'], $directory . '/' . $filename) ? $filename : null;
    }

    private function profileImagePath(string $filename): string {
        // Build the local path for a profile image using only its safe filename.
        return dirname(__DIR__, 3) . '/public/uploads/profiles/' . basename($filename);
    }
}
