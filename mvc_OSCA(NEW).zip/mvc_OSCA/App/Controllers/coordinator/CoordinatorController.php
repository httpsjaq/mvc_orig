<?php
require_once __DIR__ . '/../../Core/Controller.php';
require_once __DIR__ . '/../../Models/coordinator/StudentRoster.php';
require_once __DIR__ . '/../../Models/courses/CourseCatalog.php';

// Handles the coordinator dashboard, student activities, sports, and practice schedule.

class CoordinatorController extends Controller {
    public function show(string $page = 'home'): void {

        // Load the coordinator workspace, handle its form actions, and pass the selected page data to the view.

        $user = $this->requireUser();
        if (
            ($user['role'] ?? '') !== 'teacher' ||
            !in_array(($user['teacher_approval_status'] ?? ''), ['', 'approved'], true)
        ) {
            redirect('login.php');
        }

        // Accept only the coordinator sections supported by the workspace view.

        $validPages = ['home', 'athletes', 'dance', 'sports', 'schedule', 'reports'];
        if (!in_array($page, $validPages, true)) $page = 'home';

        $model = new StudentRoster();
        $notice = '';

        // All coordinator form actions are handled here before the refreshed page is rendered.

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            try {
                if (isset($_POST['update_student'])) {
                    $imageFile = $_FILES['profile_image'] ?? null;
                    $imageError = $this->validateStudentPhoto($imageFile);
                    if ($imageError !== null) {
                        $ok = false;
                        $notice = $imageError;
                    } else {
                    $student = [
                        'student_id' => trim($_POST['student_id'] ?? ''),
                        'full_name' => trim($_POST['full_name'] ?? ''),
                        'course' => trim($_POST['course'] ?? ''),
                        'year_level' => trim($_POST['year_level'] ?? ''),
                        'enrollment_year' => trim($_POST['enrollment_year'] ?? ''),
                        'jersey_number' => trim($_POST['jersey_number'] ?? ''),
                        'sport_id' => $_POST['sport_id'] ?? '',
                        'dance_member' => !empty($_POST['dance_member']) ? '1' : ''
                    ];
                    $studentId = (int) ($_POST['roster_id'] ?? 0);
                    $ok = $studentId > 0 && $student['student_id'] !== '' && $student['full_name'] !== ''
                        && $model->update($studentId, $student);
                    $hasNewPhoto = is_array($imageFile) && ($imageFile['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_OK;
                    if ($ok && $hasNewPhoto) {
                        $filename = $this->storeStudentPhoto($imageFile);
                        if ($filename === null) {
                            $ok = false;
                            $notice = 'Could not save the student photo. Check that the uploads folder is writable.';
                        } elseif (!$model->updateProfileImage($studentId, $student['student_id'], $filename)) {
                            @unlink($this->studentPhotoPath($filename));
                            $ok = false;
                            $notice = 'Could not save the student photo to the profile.';
                        }
                    }
                    }
                } elseif (isset($_POST['add_student'])) {
                    $student = [
                        'student_id' => trim($_POST['student_id'] ?? ''),
                        'full_name' => trim($_POST['full_name'] ?? ''),
                        'course' => trim($_POST['course'] ?? ''),
                        'year_level' => trim($_POST['year_level'] ?? ''),
                        'enrollment_year' => trim($_POST['enrollment_year'] ?? ''),
                        'jersey_number' => trim($_POST['jersey_number'] ?? ''),
                        'sport_id' => $_POST['sport_id'] ?? '',
                        'dance_member' => ($page === 'dance' || !empty($_POST['dance_member'])) ? '1' : ''
                    ];
                    $ok = $student['student_id'] !== '' && $student['full_name'] !== ''
                        && $model->add($student, (int) $user['id']);
                } elseif (isset($_POST['add_sport'])) {
                    $ok = $model->addSport(trim($_POST['sport_name'] ?? ''));
                } elseif (isset($_POST['add_schedule'])) {
                    $schedule = [
                        'group_type' => $_POST['group_type'] ?? '',
                        'group_name' => trim($_POST['group_name'] ?? ''),
                        'practice_date' => $_POST['practice_date'] ?? '',
                        'practice_time' => $_POST['practice_time'] ?? '',
                        'location' => trim($_POST['location'] ?? '')
                    ];
                    $ok = in_array($schedule['group_type'], ['Sport', 'Dance Troupe'], true)
                        && $schedule['group_name'] !== '' && $schedule['location'] !== ''
                        && $schedule['practice_date'] !== '' && $schedule['practice_time'] !== ''
                        && $model->addSchedule($schedule);
                } elseif (isset($_POST['cancel_schedule'])) {
                    $ok = $model->cancelSchedule((int) ($_POST['schedule_id'] ?? 0));
                } else {
                    $ok = false;
                }
                if ($notice === '') {
                    $notice = $ok ? 'Saved successfully.' : 'Could not save this record. Check required fields and try again.';
                }
            } catch (Throwable $error) {
                $notice = 'Could not save this record. Check for duplicate IDs or names.';
            }
        }

        // Build the view data from the chosen section, filters, and current roster records.
        
        $category = in_array($page, ['athletes', 'dance'], true) ? $page : '';
        $selectedStudent = isset($_GET['student']) ? $model->student((int) $_GET['student']) : null;
        $this->renderApp('coordinator/page', [
            'pageTitle' => ucfirst(str_replace('_', ' ', $page)),
            'currentUser' => $user,
            'section' => $page,
            'stats' => $model->stats(),
            'sports' => $model->sports(),
            'courses' => (new CourseCatalog())->all(),
            'students' => $model->students($category, trim($_GET['q'] ?? ''), trim($_GET['sport'] ?? ''), trim($_GET['year'] ?? '')),
            'schedules' => $model->schedules(),
            'selectedStudent' => $selectedStudent,
            'notice' => $notice
        ]);
    }

    private function validateStudentPhoto(?array $file): ?string {
        // Check that an uploaded student photo is a valid JPG, PNG, or WebP file under 5 MB.
        if ($file === null || ($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
            return null;
        }
        if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            return 'The student photo upload failed. Please try again.';
        }
        if (($file['size'] ?? 0) > 5 * 1024 * 1024 || !is_uploaded_file($file['tmp_name'] ?? '')) {
            return 'Choose an image smaller than 5 MB.';
        }
        $image = @getimagesize($file['tmp_name']);
        if (!in_array($image['mime'] ?? '', ['image/jpeg', 'image/png', 'image/webp'], true)) {
            return 'Use a JPG, PNG, or WebP image.';
        }
        return null;
    }

    private function storeStudentPhoto(array $file): ?string {
        // Save a checked photo using a generated filename in the profile uploads folder.
        $image = @getimagesize($file['tmp_name']);
        $extensions = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
        $extension = $extensions[$image['mime'] ?? ''] ?? null;
        if ($extension === null) {
            return null;
        }
        $filename = bin2hex(random_bytes(16)) . '.' . $extension;
        $directory = dirname(__DIR__, 3) . '/public/uploads/profiles';
        if (!is_dir($directory) && !mkdir($directory, 0755, true) && !is_dir($directory)) {
            return null;
        }
        return move_uploaded_file($file['tmp_name'], $directory . '/' . $filename) ? $filename : null;
    }

    private function studentPhotoPath(string $filename): string {
        // Build the local path used when a saved student photo must be removed.
        return dirname(__DIR__, 3) . '/public/uploads/profiles/' . basename($filename);
    }
}



