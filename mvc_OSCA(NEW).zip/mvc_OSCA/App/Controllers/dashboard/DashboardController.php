<?php
/**
 * Handles the authenticated dashboard home page.
 */
require_once __DIR__ . '/../../Core/Controller.php';

class DashboardController extends Controller {

    /**
     * Render the dashboard home page.
     */

    public function show(): void {

        // Load the signed-in user's dashboard information and display the home page.
        
        $currentUser = $this->requireUser();

        $data = [
            'pageTitle' => 'Home',
            'currentUser' => $currentUser,
            'messageError' => flash_get('auth_error'),
            'messageSuccess' => flash_get('auth_success')
        ];

        $this->renderApp('dashboard/home', $data);
    }
}
