<?php
/** Shared application settings and database connection. */

// Path and database constants tell the rest of the app where files and MySQL are located.

if (!defined('BASE_PATH')) define('BASE_PATH', dirname(__DIR__));
if (!defined('PUBLIC_PATH')) define('PUBLIC_PATH', dirname(__DIR__, 2) . DIRECTORY_SEPARATOR . 'public');
if (!defined('DB_HOST')) define('DB_HOST', 'localhost');
if (!defined('DB_NAME')) define('DB_NAME', 'users_db');
if (!defined('DB_USER')) define('DB_USER', 'root');
if (!defined('DB_PASS')) define('DB_PASS', '');
if (!defined('DB_CHARSET')) define('DB_CHARSET', 'utf8mb4');

/**
 * Application-wide configuration values.
 * Replace the placeholder secrets with your real credentials.
 */

// Shared application name used in page titles, headers, and email messages.

define('APP_NAME', 'Office of Sports, Culture, and Arts');

// These public and private keys control the optional anti-bot check on guest forms.
// Google reCAPTCHA v2 keys

define('RECAPTCHA_SITE_KEY', '6Lec9WksAAAAAGrezQR5SNp2krow4u0L_LTBNq2G');
define('RECAPTCHA_SECRET_KEY', '6Lec9WksAAAAAHEmnJQVB_I9dInOYz_iFvWdgAdM');

// SMTP settings are used when the app sends account verification and password codes.
// Mail configuration used by PHPMailer

define('MAIL_FROM_ADDRESS', 'PHPMailerTest96@gmail.com');
define('MAIL_FROM_NAME', 'Quiz System');
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'PHPMailerTest96@gmail.com');
define('SMTP_PASSWORD', 'lvaclmsldrklbesl');
define('SMTP_SECURE', 'tls');

/** Return the shared database connection, opening it on first use. */
function db_connection(): mysqli {

    // Create the shared MySQL connection once and reuse it wherever a model needs the database.
    
    static $connection = null;
    if ($connection instanceof mysqli) {
        return $connection;
    }

    $connection = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if ($connection->connect_error) {
        die('Connection failed: ' . $connection->connect_error);
    }
    $connection->set_charset(DB_CHARSET);
    return $connection;
}
