-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 24, 2026 at 12:18 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `users_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(80) DEFAULT NULL,
  `middle_initial` varchar(10) DEFAULT NULL,
  `last_name` varchar(80) DEFAULT NULL,
  `suffix` varchar(20) DEFAULT NULL,
  `full_name` varchar(180) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `student_id` varchar(50) DEFAULT NULL,
  `teacher_id` varchar(50) DEFAULT NULL,
  `year_level` varchar(30) DEFAULT NULL,
  `section` varchar(30) DEFAULT NULL,
  `academic_role` varchar(30) NOT NULL DEFAULT 'Student',
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','student','teacher') NOT NULL DEFAULT 'student',
  `otp_code` varchar(6) DEFAULT NULL,
  `otp_expiry` datetime DEFAULT NULL,
  `password_reset_pending` tinyint(1) NOT NULL DEFAULT 0,
  `status` enum('pending','verified','banned') NOT NULL DEFAULT 'pending',
  `profile_completed` tinyint(1) NOT NULL DEFAULT 0,
  `teacher_approval_status` varchar(30) DEFAULT NULL,
  `teacher_otp_requested_at` datetime DEFAULT NULL,
  `teacher_approved_at` datetime DEFAULT NULL,
  `teacher_declined_at` datetime DEFAULT NULL,
  `pending_expires_at` datetime DEFAULT NULL,
  `profile_image` varchar(255) DEFAULT 'default.png',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `student_id` (`student_id`),
  UNIQUE KEY `teacher_id` (`teacher_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `middle_initial`, `last_name`, `suffix`, `full_name`, `username`, `student_id`, `teacher_id`, `year_level`, `section`, `academic_role`, `email`, `password`, `role`, `otp_code`, `otp_expiry`, `password_reset_pending`, `status`, `profile_completed`, `teacher_approval_status`, `teacher_otp_requested_at`, `teacher_approved_at`, `teacher_declined_at`, `pending_expires_at`, `profile_image`, `created_at`) VALUES
(1, 'Admin', NULL, 'User', NULL, 'Admin User', 'admin', 'ADMIN-001', NULL, 'N/A', 'N/A', 'Administrator', 'admin@gmail.com', '$2y$12$NEeHVxv3GvvJjpDKofS9SOf3yTr3jLWNjYQzopMgMvHQ8zUeepfhy', 'admin', NULL, NULL, 0, 'verified', 1, NULL, NULL, NULL, NULL, NULL, 'default.png', '2026-03-25 20:09:14');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
