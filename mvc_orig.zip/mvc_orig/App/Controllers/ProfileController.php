<?php
/**
 * Handles profile display and profile editing for logged-in users.
 */
require_once __DIR__ . '/../Core/Controller.php';

class ProfileController extends Controller {
    /**
     * Display the current user's profile.
     */
    public function show(): void {
        $currentUser = $this->requireUser();

        $this->renderApp('profile/profile', [
            'pageTitle' => 'Profile',
            'currentUser' => $currentUser,
            'changeSuccess' => flash_get('change_success')
        ]);
    }

    /**
     * Render and process the edit profile form.
     */
    public function edit(): void {
        $currentUser = $this->requireUser();
        $error = null;
        $success = null;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $formData = [
                'first_name' => trim($_POST['first_name'] ?? ''),
                'middle_initial' => trim($_POST['middle_initial'] ?? ''),
                'last_name' => trim($_POST['last_name'] ?? ''),
                'suffix' => trim($_POST['suffix'] ?? ''),
                'username' => trim($_POST['username'] ?? ''),
                'teacher_id' => trim($_POST['teacher_id'] ?? ''),
                'student_id' => trim($_POST['student_id'] ?? ''),
                'year_level' => trim($_POST['year_level'] ?? ''),
                'section' => trim($_POST['section'] ?? '')
            ];

            $isCoordinator = ($currentUser['role'] ?? '') === 'teacher';
            $missingFields =
                $formData['first_name'] === '' ||
                $formData['last_name'] === '' ||
                $formData['username'] === '' ||
                ($isCoordinator
                    ? $formData['teacher_id'] === ''
                    : ($formData['student_id'] === '' || $formData['year_level'] === '' || $formData['section'] === ''));

            if ($missingFields) {
                $error = 'Please fill in all required fields.';
            } elseif (
                $isCoordinator
                    ? $this->userModel->coordinatorIdentityExists($formData['username'], $formData['teacher_id'], (int) $currentUser['id'])
                    : $this->userModel->profileIdentityExists($formData['username'], $formData['student_id'], (int) $currentUser['id'])
            ) {
                $error = $isCoordinator ? 'Username or Coordinator ID already exists.' : 'Username or Student ID already exists.';
            } else {
                $formData['middle_initial'] = $formData['middle_initial'] !== '' ? strtoupper(substr($formData['middle_initial'], 0, 1)) : null;

                if ($this->userModel->updateProfile((int) $currentUser['id'], $formData)) {
                    $currentUser = $this->userModel->findById((int) $currentUser['id']);
                    $success = 'Profile updated successfully.';
                } else {
                    $error = 'Failed to update profile.';
                }
            }
        }

        $this->renderApp('profile/edit_profile', [
            'pageTitle' => 'Edit Profile',
            'currentUser' => $currentUser,
            'editError' => $error,
            'editSuccess' => $success
        ]);
    }
}
