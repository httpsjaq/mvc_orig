<?php
/**
 * Admin controller.
 * Handles the Student Management System admin dashboard:
 * - view students
 * - edit a student's status on a separate page
 * - delete students
 */
require_once __DIR__ . '/../Core/Controller.php';
require_once __DIR__ . '/../Models/StudentRoster.php';

class AdminController extends Controller {
    /**
     * Render the admin dashboard and delete users.
     */
    public function dashboard(): void {
        $currentUser = $this->requireUser(false);

        if (($currentUser['role'] ?? '') !== 'admin') {
            redirect('index.php?url=home');
        }

        $adminError = flash_get('admin_error') ?? '';
        $adminSuccess = flash_get('admin_success') ?? '';

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (isset($_POST['review_coordinator'])) {
                $userId = (int) ($_POST['user_id'] ?? 0);
                $decision = $_POST['review_coordinator'];

                if ($this->userModel->reviewCoordinatorRequest($userId, $decision)) {
                    $adminSuccess = $decision === 'approve'
                        ? 'Coordinator account approved.'
                        : 'Coordinator account declined.';
                } else {
                    $adminError = 'This Coordinator request could not be updated. Refresh and try again.';
                }

                flash_set('admin_error', $adminError);
                flash_set('admin_success', $adminSuccess);
                redirect('index.php?url=admin_dashboard');
            } elseif (isset($_POST['delete_user'])) {
                $userId = (int) ($_POST['user_id'] ?? 0);

                if ($this->userModel->adminDeleteUser($userId)) {
                    $adminSuccess = 'User deleted successfully.';
                } else {
                    $adminError = 'Failed to delete user.';
                }
            }
        }

        $stats = $this->userModel->adminStats();
        $users = $this->userModel->getManageableUsers();
        $coordinators = $this->userModel->getManageableCoordinators();
        $rosterStudents = (new StudentRoster())->all();

        extract([
            'pageTitle' => 'Admin Dashboard',
            'currentUser' => $currentUser,
            'adminError' => $adminError,
            'adminSuccess' => $adminSuccess,
            'stats' => $stats,
            'users' => $users,
            'coordinators' => $coordinators,
            'rosterStudents' => $rosterStudents
        ]);

        include __DIR__ . '/../Views/layout/header.php';
        include __DIR__ . '/../Views/layout/admin_sidebar.php';
        include __DIR__ . '/../Views/admin/dashboard.php';
        include __DIR__ . '/../Views/layout/footer.php';
    }

    /**
     * Edit a single student's status on a dedicated page.
     */
    public function editUser(): void {
        $currentUser = $this->requireUser(false);

        if (($currentUser['role'] ?? '') !== 'admin') {
            redirect('index.php?url=home');
        }

        $userId = (int) ($_GET['id'] ?? 0);
        $editableUser = $this->userModel->getManageableUserById($userId);

        if (!$editableUser) {
            flash_set('admin_error', 'User not found.');
            redirect('index.php?url=admin_dashboard');
        }

        $adminError = '';
        $adminSuccess = '';

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_user'])) {
            $status = trim($_POST['status'] ?? '');

            $allowedStatus = ['verified', 'banned'];

            if (!in_array($status, $allowedStatus, true)) {
                $adminError = 'Invalid status selected.';
            } elseif ($this->userModel->adminUpdateUser($userId, $status)) {
                flash_set('admin_success', 'User updated successfully.');
                redirect('index.php?url=admin_dashboard');
            } else {
                $adminError = 'Failed to update user.';
            }
        }

        extract([
            'pageTitle' => 'Edit User',
            'currentUser' => $currentUser,
            'editableUser' => $editableUser,
            'adminError' => $adminError,
            'adminSuccess' => $adminSuccess
        ]);

        include __DIR__ . '/../Views/layout/header.php';
        include __DIR__ . '/../Views/layout/admin_sidebar.php';
        include __DIR__ . '/../Views/admin/edit_user.php';
        include __DIR__ . '/../Views/layout/footer.php';
    }
}
