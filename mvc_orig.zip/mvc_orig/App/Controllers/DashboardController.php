<?php
/**
 * Handles the authenticated dashboard home page.
 */
require_once __DIR__ . '/../Core/Controller.php';

class DashboardController extends Controller {
    /**
     * Render the dashboard home page.
     */
    public function show(string $page = 'home'): void {
        $currentUser = $this->requireUser();

        $data = [
            'pageTitle' => 'Home',
            'currentUser' => $currentUser,
            'extraCss' => [],
            'extraJs' => [],
            'messageError' => flash_get('auth_error'),
            'messageSuccess' => flash_get('auth_success')
        ];

        $this->renderApp('dashboard/home', $data);
    }
}
