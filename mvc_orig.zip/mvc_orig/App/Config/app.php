<?php
/**
 * Application-wide configuration values.
 * Replace the placeholder secrets with your real credentials.
 */
define('APP_NAME', 'Office of Sports, Culture, and Arts');

// Google reCAPTCHA v2 keys
define('RECAPTCHA_SITE_KEY', '6Lec9WksAAAAAGrezQR5SNp2krow4u0L_LTBNq2G');
define('RECAPTCHA_SECRET_KEY', '6Lec9WksAAAAAHEmnJQVB_I9dInOYz_iFvWdgAdM');

// Mail configuration used by PHPMailer
define('MAIL_FROM_ADDRESS', 'PHPMailerTest96@gmail.com');
define('MAIL_FROM_NAME', 'Quiz System');
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'PHPMailerTest96@gmail.com');
define('SMTP_PASSWORD', 'lvaclmsldrklbesl');
define('SMTP_SECURE', 'tls');
