<?php
/**
 * Database connection used by the application models.
 * Update these values when moving the project to another environment.
 */
$conn = new mysqli("localhost", "root", "", "users_db");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");
