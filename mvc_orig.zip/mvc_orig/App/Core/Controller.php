<?php
/**
 * Base controller with shared rendering and authentication helpers.
 */
require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/../Models/User.php';

class Controller {
    /** @var User Central model used by most controllers. */
    protected User $userModel;

    public function __construct() {
        $this->userModel = new User();
    }

    /**
     * Render an authenticated application page using the shared layout.
     */
    protected function renderApp(string $viewPath, array $data = []): void {
        extract($data);
        include __DIR__ . '/../Views/layout/header.php';
        include __DIR__ . '/../Views/layout/sidebar.php';
        include __DIR__ . '/../Views/' . $viewPath . '.php';
        include __DIR__ . '/../Views/layout/footer.php';
    }

    /**
     * Render a guest/auth page using the auth layout.
     */
    protected function renderAuth(string $viewPath, array $data = []): void {
        extract($data);
        include __DIR__ . '/../Views/layout/auth_header.php';
        include __DIR__ . '/../Views/' . $viewPath . '.php';
        include __DIR__ . '/../Views/layout/auth_footer.php';
    }

    /**
     * Block access to guest pages when a user is already logged in.
     */
    protected function requireGuest(): void {
        if (!empty($_SESSION['email'])) {
            redirect('index.php?url=home');
        }
    }

    /**
     * Get the current user from the session or redirect to the login page.
     * By default this also forces verified and completed profiles.
     */
    protected function requireUser(bool $requireProfileComplete = true): array {
        if (empty($_SESSION['email'])) {
            redirect('login.php');
        }

        $user = $this->userModel->findByEmail($_SESSION['email']);

        if (!$user) {
            session_unset();
            session_destroy();
            redirect('login.php');
        }

        if (($user['status'] ?? '') !== 'verified') {
            $_SESSION['pending_email'] = $user['email'];
            redirect('verify_otp.php');
        }

        if ($requireProfileComplete && empty($user['profile_completed'])) {
            $_SESSION['setup_email'] = $user['email'];
            redirect('setup_account.php');
        }

        return $user;
    }
}
