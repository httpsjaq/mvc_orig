<?php
/**
 * Backward-compatibility wrapper.
 * The old project used auth_helper.php; the new modular MVC now centralizes helpers in helpers.php.
 */
require_once __DIR__ . '/helpers.php';
