<?php
/**
 * Logged-in page used after OTP verification to set a new password.
 */
?>
<div class="main-content profile-page">
    <div class="profile-container">
        <div class="profile-header">
            <div>
                <h1>Set New Password</h1>
            </div>

            <a href="index.php?url=profile" class="edit-btn">
                <i class="bi bi-arrow-left"></i> Back
            </a>
        </div>

        <?php if (!empty($changeError)): ?>
            <div class="error-box"><?php echo e($changeError); ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="profile-section single-form-block">
                <h3>New Password</h3>
                <div class="info-grid">
                    <div class="info-item">
                        <label>Password</label>
                        <div class="password-wrap"><input id="set_new_password" type="password" name="password" required><button type="button" class="password-toggle" data-target="set_new_password" aria-label="Show password"><i class="bi bi-eye-fill"></i></button></div>
                    </div>

                    <div class="info-item">
                        <label>Confirm Password</label>
                        <div class="password-wrap"><input id="set_new_confirm_password" type="password" name="confirm_password" required><button type="button" class="password-toggle" data-target="set_new_confirm_password" aria-label="Show password"><i class="bi bi-eye-fill"></i></button></div>
                    </div>
                </div>

                <div class="action-row">
                    <button type="submit" class="edit-btn">
                        <i class="bi bi-save2-fill"></i> Update Password
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
