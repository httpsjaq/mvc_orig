<?php
/**
 * Shared sidebar for authenticated application pages.
 * Uses the $currentUser array passed by the controller.
 */
$user = isset($currentUser) && is_array($currentUser) ? $currentUser : [];
$displayName = !empty($user['username'])
    ? $user['username']
    : (!empty($user['full_name']) ? $user['full_name'] : ($user['email'] ?? 'User'));
$activePage = $_GET['url'] ?? 'home';
$sidebarTitle = $displayName;
?>
<div class="side-bar">
    <div class="close-btn">
        <i class="bi bi-x-circle-fill"></i>
    </div>

    <div class="menu-top">
        <div class="top-section">
            <header>
                <div class="sidebar-user-row">
                    <h1><?php echo e($sidebarTitle); ?></h1>
                </div>
                <hr>
            </header>

            <div class="menu">
                <?php if (($user['role'] ?? '') === 'teacher'): ?>
                    <div class="items"><a class="<?php echo $activePage === 'home' ? 'active-link' : ''; ?>" href="index.php?url=home"><i class="bi bi-house-door-fill"></i> Dashboard</a></div>
                    <div class="items"><a class="<?php echo $activePage === 'athletes' ? 'active-link' : ''; ?>" href="index.php?url=athletes"><i class="bi bi-trophy"></i> Athletes</a></div>
                    <div class="items"><a class="<?php echo $activePage === 'sports' ? 'active-link' : ''; ?>" href="index.php?url=sports"><i class="bi bi-dribbble"></i> Sports Categories</a></div>
                    <div class="items"><a class="<?php echo $activePage === 'dance' ? 'active-link' : ''; ?>" href="index.php?url=dance"><i class="bi bi-music-note-beamed"></i> Dance Troupe</a></div>
                    <div class="items"><a class="<?php echo $activePage === 'schedule' ? 'active-link' : ''; ?>" href="index.php?url=schedule"><i class="bi bi-calendar3"></i> Practice Schedule</a></div>
                    <div class="items"><a class="<?php echo $activePage === 'reports' ? 'active-link' : ''; ?>" href="index.php?url=reports"><i class="bi bi-file-earmark-bar-graph"></i> Reports</a></div>
                    <div class="items"><a class="<?php echo $activePage === 'profile' ? 'active-link' : ''; ?>" href="index.php?url=profile"><i class="bi bi-person-circle"></i> Profile</a></div>
                    <div class="items">
                        <a href="#" class="sub-btn"><i class="bi bi-gear-fill"></i> Settings <i class="bi bi-caret-down-fill"></i></a>
                        <div class="sub-menu">
                            <div class="sub-items"><a href="index.php?url=edit_profile" class="sub-item-2">Update Details</a></div>
                            <div class="sub-items"><a href="index.php?url=change_password" class="sub-item-2">Change Password</a></div>
                        </div>
                    </div>
                <?php else: ?>
                <div class="items"><a class="<?php echo $activePage === 'home' ? 'active-link' : ''; ?>" href="index.php?url=home"><i class="bi bi-house-door-fill"></i> Home</a></div>
                <div class="items"><a class="<?php echo $activePage === 'profile' ? 'active-link' : ''; ?>" href="index.php?url=profile"><i class="bi bi-person-circle"></i> Profile</a></div>

                <div class="items">
                    <a href="#" class="sub-btn">
                        <i class="bi bi-gear-fill"></i>
                        Settings
                        <i class="bi bi-caret-down-fill"></i>
                    </a>
                    <div class="sub-menu">
                        <div class="sub-items">
                            <a href="index.php?url=edit_profile" class="sub-item-2">Update Details</a>
                        </div>
                        <div class="sub-items">
                            <a href="index.php?url=change_password" class="sub-item-2">Change Password</a>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="menu-down">
        <div class="items">
            <a href="logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a>
        </div>
    </div>
</div>
