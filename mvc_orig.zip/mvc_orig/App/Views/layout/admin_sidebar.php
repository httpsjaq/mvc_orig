<?php
/**
 * Admin sidebar.
 * Minimal sidebar: title + logout only.
 */
?>
<div class="side-bar">

    <div class="close-btn">
        <i class="bi bi-x-circle-fill"></i>
    </div>

    <div class="menu-top">
        <div class="top-section">
            <header>
                <h1>Administrator</h1>
                <hr>
            </header>

            <div class="menu">
                <!-- Admin sidebar intentionally kept minimal -->
            </div>
        </div>
    </div>

    <div class="menu-down">
        <div class="items">
            <a href="logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a>
        </div>
    </div>

</div>
