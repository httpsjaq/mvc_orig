    <script src="bootstrap-5.0.2/bootstrap-5.0.2-dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/script.js"></script>
<?php if (!empty($extraJs) && is_array($extraJs)): ?>
<?php foreach ($extraJs as $jsFile): ?>
    <script src="<?php echo e($jsFile); ?>"></script>
<?php endforeach; ?>
<?php endif; ?>
</div>
</body>
</html>
