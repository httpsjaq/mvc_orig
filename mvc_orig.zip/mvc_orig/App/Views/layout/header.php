<?php
/**
 * Shared header for authenticated application pages.
 * Expects $pageTitle and $currentUser to be available.
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e(($pageTitle ?? APP_NAME) . ' - ' . APP_NAME); ?></title>
    <link rel="stylesheet" href="bootstrap-5.0.2/bootstrap-5.0.2-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
    <link rel="stylesheet" href="css/app.css">
<?php if (!empty($extraCss) && is_array($extraCss)): ?>
<?php foreach ($extraCss as $cssFile): ?>
    <link rel="stylesheet" href="<?php echo e($cssFile); ?>">
<?php endforeach; ?>
<?php endif; ?>
</head>
<body class="app-body">
<div class="frame">
    <button type="button" class="menu-btn btn btn-primary" aria-label="Open navigation">
        <i class="bi bi-list"></i>
    </button>
