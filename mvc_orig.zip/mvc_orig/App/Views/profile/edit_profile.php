<?php
/**
 * Edit profile view.
 */
$isCoordinator = ($currentUser['role'] ?? '') === 'teacher';
?>

<div class="main-content profile-page">
    <div class="profile-container">
        <div class="profile-header">
            <div>
                <h1>Edit Profile</h1>
            </div>

            <a href="index.php?url=profile" class="edit-btn">
                <i class="bi bi-arrow-left"></i> Back to Profile
            </a>
        </div>

        <?php if (!empty($editError)): ?>
            <div class="error-box"><?php echo e($editError); ?></div>
        <?php endif; ?>

        <?php if (!empty($editSuccess)): ?>
            <div class="success-box"><?php echo e($editSuccess); ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="profile-section single-form-block">
                <h3>Account Information</h3>

                <div class="info-grid">
                    <div class="info-item">
                        <label>First Name</label>
                        <input type="text" name="first_name" value="<?php echo e($currentUser['first_name'] ?? ''); ?>" required>
                    </div>

                    <div class="info-item">
                        <label>Middle Initial</label>
                        <input type="text" name="middle_initial" value="<?php echo e($currentUser['middle_initial'] ?? ''); ?>" maxlength="1">
                    </div>

                    <div class="info-item">
                        <label>Last Name</label>
                        <input type="text" name="last_name" value="<?php echo e($currentUser['last_name'] ?? ''); ?>" required>
                    </div>

                    <div class="info-item">
                        <label>Suffix</label>
                        <select name="suffix">
                            <option value="">Select Suffix</option>
                            <?php foreach (['Jr.','Sr.','II','III','IV'] as $suffixOption): ?>
                                <option value="<?php echo e($suffixOption); ?>" <?php echo (($currentUser['suffix'] ?? '') === $suffixOption) ? 'selected' : ''; ?>>
                                    <?php echo e($suffixOption); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="info-item">
                        <label>Username</label>
                        <input type="text" name="username" value="<?php echo e($currentUser['username'] ?? ''); ?>" required>
                    </div>

                    <div class="info-item">
                        <label><?php echo $isCoordinator ? 'Coordinator ID' : 'Student ID'; ?></label>
                        <input type="text" name="<?php echo $isCoordinator ? 'teacher_id' : 'student_id'; ?>" value="<?php echo e($isCoordinator ? ($currentUser['teacher_id'] ?? '') : ($currentUser['student_id'] ?? '')); ?>" required>
                    </div>
                </div>

                <hr class="inner-divider">

                <h3>Academic Information</h3>

                <?php if (!$isCoordinator): ?>
                <div class="info-grid">
                    <div class="info-item">
                        <label>Year Level</label>
                        <select name="year_level" required>
                            <option value="">Select Year Level</option>
                            <?php foreach (['1st Year','2nd Year','3rd Year','4th Year'] as $year): ?>
                                <option value="<?php echo e($year); ?>" <?php echo (($currentUser['year_level'] ?? '') === $year) ? 'selected' : ''; ?>>
                                    <?php echo e($year); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="info-item">
                        <label>Section</label>
                        <input type="text" name="section" value="<?php echo e($currentUser['section'] ?? ''); ?>" required>
                    </div>
                </div>
                <?php else: ?>
                    <p class="profile-readonly-note">Coordinator accounts do not have student year or section details.</p>
                <?php endif; ?>

                <div class="action-row">
                    <button type="submit" class="edit-btn">
                        <i class="bi bi-save2-fill"></i> Save Changes
                    </button>

                    <a href="index.php?url=profile" class="edit-btn">Cancel</a>
                </div>
            </div>
        </form>
    </div>
</div>
