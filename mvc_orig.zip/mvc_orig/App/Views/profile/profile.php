<?php
/**
 * Profile display view.
 */
$fullName = !empty($currentUser['full_name']) ? $currentUser['full_name'] : 'No Name';
$isCoordinator = ($currentUser['role'] ?? '') === 'teacher';
$identityId = $isCoordinator ? ($currentUser['teacher_id'] ?? '') : ($currentUser['student_id'] ?? '');
$identityId = $identityId !== '' ? $identityId : (string) $currentUser['id'];
$username = !empty($currentUser['username']) ? $currentUser['username'] : 'No Username';
$statusText = (($currentUser['status'] ?? '') === 'verified') ? 'Active' : ucfirst((string) ($currentUser['status'] ?? 'unknown'));
$dateCreated = !empty($currentUser['created_at']) ? date('Y-m-d', strtotime($currentUser['created_at'])) : 'N/A';
?>
<div class="main-content profile-page">
    <div class="profile-container">
        <div class="profile-header">
            <div class="profile-title-row">
                <h1><?php echo e($fullName); ?></h1>
                <span class="profile-role-badge"><?php echo e($currentUser['academic_role'] ?? ($isCoordinator ? 'Coordinator' : 'Student')); ?></span>
            </div>

            <a href="index.php?url=edit_profile" class="edit-btn">
                <i class="bi bi-pencil-square"></i> Edit Profile
            </a>
        </div>

        <?php if (!empty($changeSuccess)): ?>
            <div class="success-box"><?php echo e($changeSuccess); ?></div>
        <?php endif; ?>

        <div class="profile-section">
            <h3>Account Information</h3>

            <div class="info-grid">
                <div class="info-item"><label><?php echo $isCoordinator ? 'Coordinator ID' : 'Student ID'; ?></label><p><?php echo e($identityId); ?></p></div>
                <div class="info-item"><label>Username</label><p><?php echo e($username); ?></p></div>
                <div class="info-item"><label>Email</label><p><?php echo e($currentUser['email'] ?? 'No Email'); ?></p></div>
                <div class="info-item"><label>Status</label><p><?php echo e($statusText); ?></p></div>
            </div>
        </div>

        <div class="profile-section">
            <h3>Academic Information</h3>

            <div class="info-grid">
                <div class="info-item"><label>Year</label><p><?php echo e($currentUser['year_level'] ?? 'Not Set'); ?></p></div>
                <div class="info-item"><label>Section</label><p><?php echo e($currentUser['section'] ?? 'Not Set'); ?></p></div>
                <div class="info-item"><label>Role</label><p><?php echo e($currentUser['academic_role'] ?? 'Student'); ?></p></div>
            </div>
        </div>

        <div class="profile-section">
            <h3>System Information</h3>

            <div class="info-grid">
                <div class="info-item"><label>Date Created</label><p><?php echo e($dateCreated); ?></p></div>
            </div>
        </div>
    </div>
</div>
