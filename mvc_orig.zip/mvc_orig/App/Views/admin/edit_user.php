<?php
/**
 * Admin edit user view.
 * Admin can change role and status on a dedicated page.
 */
$editableUser = $editableUser ?? [];
?>
<div class="main-content profile-page">
    <div class="profile-container">
        <div class="profile-header">
            <div>
                <h1>Edit User</h1>
            </div>

            <a href="index.php?url=admin_dashboard" class="edit-btn">
                <i class="bi bi-arrow-left"></i> Back to Dashboard
            </a>
        </div>

        <?php if (!empty($adminError)): ?>
            <div class="error-box"><?php echo e($adminError); ?></div>
        <?php endif; ?>

        <?php if (!empty($adminSuccess)): ?>
            <div class="success-box"><?php echo e($adminSuccess); ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="profile-section single-form-block">
                <h3>User Information</h3>

                <div class="info-grid">
                    <div class="info-item">
                        <label>Email</label>
                        <input type="text" value="<?php echo e($editableUser['email'] ?? 'N/A'); ?>" readonly>
                    </div>

                    <div class="info-item">
                        <label>Username</label>
                        <input type="text" value="<?php echo e($editableUser['username'] ?? 'N/A'); ?>" readonly>
                    </div>

                    <div class="info-item">
                        <label>Role</label>
                        <input type="text" value="Student" readonly>
                    </div>

                    <div class="info-item">
                        <label>Status</label>
                        <select name="status" required>
                            <option value="verified" <?php echo (($editableUser['status'] ?? '') !== 'banned') ? 'selected' : ''; ?>>Active</option>
                            <option value="banned" <?php echo (($editableUser['status'] ?? '') === 'banned') ? 'selected' : ''; ?>>Banned</option>
                        </select>
                    </div>
                </div>

                <div class="action-row">
                    <button type="submit" name="save_user" class="edit-btn" style="border:none; cursor:pointer;">
                        <i class="bi bi-save2-fill"></i> Save Changes
                    </button>

                    <a href="index.php?url=admin_dashboard" class="edit-btn">Cancel</a>
                </div>
            </div>
        </form>
    </div>
</div>
