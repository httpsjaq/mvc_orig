<?php
/**
 * Forgot-password request view.
 */
?>
<div class="auth-shell">
    <section class="auth-hero glass-panel">
        <span class="welcome-tag"><?php echo e($heroTag ?? 'Account recovery'); ?></span>
        <h1><?php echo e($heroTitle ?? 'Forgot password'); ?></h1>
        <p><?php echo e($heroDescription ?? 'Recover access to your account securely.'); ?></p>
    </section>

    <section class="auth-panel glass-panel">
        <div class="brand"><i class="bi bi-unlock-fill"></i> <?php echo e(APP_NAME); ?></div>
        <h2><?php echo e($formTitle ?? 'Forgot password'); ?></h2>
        <p class="auth-subtext">Enter your email address and we will send a reset OTP.</p>

        <?php if (!empty($messageError)): ?>
            <div class="error-box"><?php echo e($messageError); ?></div>
        <?php endif; ?>

        <?php if (!empty($messageSuccess)): ?>
            <div class="success-box"><?php echo e($messageSuccess); ?></div>
        <?php endif; ?>

        <form method="POST" class="auth-form">
            <div class="field">
                <label>Email</label>
                <input type="email" name="email" placeholder="Enter your email" required>
            </div>

            <?php if (!empty($showRecaptcha)): ?>
                <div class="captcha-wrap">
                    <div class="g-recaptcha" data-sitekey="<?php echo e(RECAPTCHA_SITE_KEY); ?>"></div>
                </div>
            <?php endif; ?>

            <button class="glass-btn auth-submit" type="submit">Send OTP <i class="bi bi-arrow-right"></i></button>
        </form>

        <div class="auth-links">
            <a href="login.php">Back to login</a>
        </div>
    </section>
</div>
