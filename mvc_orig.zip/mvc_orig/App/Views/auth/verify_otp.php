<?php
/**
 * Registration OTP verification view.
 */
?>
<div class="auth-shell">
    <section class="auth-hero glass-panel">
        <span class="welcome-tag"><?php echo e($heroTag ?? ''); ?></span>
        <h1><?php echo e($heroTitle ?? ''); ?></h1>
        <p><?php echo e($heroDescription ?? ''); ?></p>
        <div class="auth-email-pill">
            <i class="bi bi-envelope-paper-fill"></i>
            <span><?php echo e($currentEmail ?? ''); ?></span>
        </div>
    </section>

    <section class="auth-panel glass-panel">
        <div class="brand"><i class="bi bi-shield-check"></i> <?php echo e(APP_NAME); ?></div>
        <h2><?php echo e($formTitle ?? ''); ?></h2>
        <p class="auth-subtext">Enter the six-digit OTP we sent to your inbox.</p>

        <?php if (!empty($messageError)): ?>
            <div class="error-box"><?php echo e($messageError); ?></div>
        <?php endif; ?>

        <?php if (!empty($messageSuccess)): ?>
            <div class="success-box"><?php echo e($messageSuccess); ?></div>
        <?php endif; ?>

        <form method="POST" class="auth-form">
            <div class="field">
                <label>OTP Code</label>
                <input type="text" name="otp" placeholder="Enter 6-digit OTP" maxlength="6" required>
            </div>

            <button class="glass-btn auth-submit" type="submit">Verify OTP <i class="bi bi-arrow-right"></i></button>
        </form>

        <div class="auth-links">
            <a href="verify_otp.php?resend=1">Resend OTP</a>
            <a href="login.php">Back to login</a>
        </div>
    </section>
</div>
