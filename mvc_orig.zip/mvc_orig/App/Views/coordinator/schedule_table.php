<div class="table-wrap">
  <table class="simple-table">
    <thead><tr><th>Group</th><th>Date</th><th>Time</th><th>Location</th><?php if (!empty($showCancel)): ?><th></th><?php endif; ?></tr></thead>
    <tbody>
      <?php if (!$schedules): ?><tr><td colspan="5" class="empty-state">No upcoming practices scheduled.</td></tr><?php endif; ?>
      <?php foreach ($schedules as $practice): ?>
        <tr>
          <td><?php echo e($practice['group_name']); ?><small class="sub-label"><?php echo e($practice['group_type']); ?></small></td>
          <td><?php echo e(date('M j, Y', strtotime($practice['practice_date']))); ?></td>
          <td><?php echo e(date('g:i A', strtotime($practice['practice_time']))); ?></td>
          <td><?php echo e($practice['location']); ?></td>
          <?php if (!empty($showCancel)): ?>
            <td><form method="post" onsubmit="return confirm('Cancel this practice?')"><input type="hidden" name="schedule_id" value="<?php echo (int) $practice['id']; ?>"><button class="text-button" name="cancel_schedule" value="1">Cancel</button></form></td>
          <?php endif; ?>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
