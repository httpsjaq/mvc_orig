<?php
/**
 * Public entry point for logout.
 */
session_start();
require_once "../App/Controllers/AuthController.php";
(new AuthController())->logout();
