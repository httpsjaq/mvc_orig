<?php
/**
 * Public entry point for forgot-password OTP verification.
 */
session_start();
require_once "../App/Controllers/PasswordController.php";
(new PasswordController())->verifyForgotOtp();
