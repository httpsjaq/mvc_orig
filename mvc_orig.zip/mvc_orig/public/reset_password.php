<?php
/**
 * Public entry point for saving a new password after forgot-password OTP verification.
 */
session_start();
require_once "../App/Controllers/PasswordController.php";
(new PasswordController())->resetPassword();
