<?php
/**
 * Public entry point for the post-verification profile setup page.
 */
session_start();
require_once "../App/Controllers/AuthController.php";
(new AuthController())->setupAccount();
