<?php
/**
 * Public entry point for forgot-password requests.
 */
session_start();
require_once "../App/Controllers/PasswordController.php";
(new PasswordController())->forgotPassword();
