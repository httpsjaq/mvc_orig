(function () {
  const AppModule = (function () {
    const s = {
      selectors: {
        sidebar: '.side-bar',
        openSidebarButton: '.menu-btn',
        closeSidebarButton: '.close-btn',
        submenuButton: '.sub-btn',
        passwordToggle: '.password-toggle'
      },
      sidebarStorageKey: 'sidebar'
    };

    let sidebar;
    let openSidebarButton;
    let closeSidebarButton;

    function init() {
      cacheElements();
      bindEvents();
      restoreSidebarState();
    }

    function cacheElements() {
      sidebar = document.querySelector(s.selectors.sidebar);
      openSidebarButton = document.querySelector(s.selectors.openSidebarButton);
      closeSidebarButton = document.querySelector(s.selectors.closeSidebarButton);
    }

    function bindEvents() {
      if (openSidebarButton) {
        openSidebarButton.addEventListener('click', openSidebar);
      }

      if (closeSidebarButton) {
        closeSidebarButton.addEventListener('click', closeSidebar);
      }

      document.querySelectorAll(s.selectors.submenuButton).forEach(function (button) {
        button.addEventListener('click', toggleSubmenu);
      });

      document.querySelectorAll(s.selectors.passwordToggle).forEach(function (button) {
        button.addEventListener('click', togglePassword);
      });
    }

    function restoreSidebarState() {
      if (!sidebar) return;
      setSidebarOpen(localStorage.getItem(s.sidebarStorageKey) === 'open');
    }

    function openSidebar() {
      setSidebarOpen(true);
    }

    function closeSidebar() {
      setSidebarOpen(false);
    }

    function setSidebarOpen(isOpen) {
      if (!sidebar) return;

      sidebar.classList.toggle('active', isOpen);

      if (openSidebarButton) {
        openSidebarButton.classList.toggle('hidden', isOpen);
      }

      localStorage.setItem(s.sidebarStorageKey, isOpen ? 'open' : 'closed');
    }

    function toggleSubmenu(event) {
      event.preventDefault();

      const submenu = event.currentTarget.nextElementSibling;
      if (!submenu) return;

      submenu.style.display =
        submenu.style.display === 'block' ? 'none' : 'block';
    }

    function togglePassword(event) {
      const button = event.currentTarget;
      const input = document.getElementById(button.dataset.target);
      if (!input) return;

      const showPassword = input.type === 'password';
      input.type = showPassword ? 'text' : 'password';

      const icon = button.querySelector('i');
      if (icon) {
        icon.classList.toggle('bi-eye-fill', !showPassword);
        icon.classList.toggle('bi-eye-slash-fill', showPassword);
      }
    }

    return {
      init: init
    };
  })();

  document.addEventListener('DOMContentLoaded', AppModule.init);
})();