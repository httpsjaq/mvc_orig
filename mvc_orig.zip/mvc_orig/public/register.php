<?php
/**
 * Public entry point for registration.
 */
session_start();
require_once "../App/Controllers/AuthController.php";
(new AuthController())->register();
