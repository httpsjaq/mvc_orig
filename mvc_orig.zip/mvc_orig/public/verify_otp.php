<?php
/**
 * Public entry point for registration OTP verification.
 */
session_start();
require_once "../App/Controllers/AuthController.php";
(new AuthController())->verifyOtp();
